﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAddCustomer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.txtN1F = New System.Windows.Forms.TextBox
        Me.txtN2F = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.txtN1L = New System.Windows.Forms.TextBox
        Me.txtN2L = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtcolor = New System.Windows.Forms.TextBox
        Me.txtyear = New System.Windows.Forms.TextBox
        Me.txtProv = New System.Windows.Forms.TextBox
        Me.Label38 = New System.Windows.Forms.Label
        Me.Txtphone2 = New System.Windows.Forms.TextBox
        Me.Label39 = New System.Windows.Forms.Label
        Me.Txtemail = New System.Windows.Forms.TextBox
        Me.txtphone1 = New System.Windows.Forms.TextBox
        Me.txtpostal = New System.Windows.Forms.TextBox
        Me.txtmotorserial = New System.Windows.Forms.TextBox
        Me.txtBoatSerial = New System.Windows.Forms.TextBox
        Me.txttrailerserial = New System.Windows.Forms.TextBox
        Me.txtmotormodel = New System.Windows.Forms.TextBox
        Me.txtboatmodel = New System.Windows.Forms.TextBox
        Me.txttrailermodel = New System.Windows.Forms.TextBox
        Me.txtmotormake = New System.Windows.Forms.TextBox
        Me.TxtBoatMake = New System.Windows.Forms.TextBox
        Me.TxtCity = New System.Windows.Forms.TextBox
        Me.txtAddress = New System.Windows.Forms.TextBox
        Me.txttrailermake = New System.Windows.Forms.TextBox
        Me.Label24 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.BtnCustData = New System.Windows.Forms.Button
        Me.txtName = New System.Windows.Forms.TextBox
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.txtN1F)
        Me.Panel1.Controls.Add(Me.txtN2F)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.txtN1L)
        Me.Panel1.Controls.Add(Me.txtN2L)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.txtcolor)
        Me.Panel1.Controls.Add(Me.txtyear)
        Me.Panel1.Controls.Add(Me.txtProv)
        Me.Panel1.Controls.Add(Me.Label38)
        Me.Panel1.Controls.Add(Me.Txtphone2)
        Me.Panel1.Controls.Add(Me.Label39)
        Me.Panel1.Controls.Add(Me.Txtemail)
        Me.Panel1.Controls.Add(Me.txtphone1)
        Me.Panel1.Controls.Add(Me.txtpostal)
        Me.Panel1.Controls.Add(Me.txtmotorserial)
        Me.Panel1.Controls.Add(Me.txtBoatSerial)
        Me.Panel1.Controls.Add(Me.txttrailerserial)
        Me.Panel1.Controls.Add(Me.txtmotormodel)
        Me.Panel1.Controls.Add(Me.txtboatmodel)
        Me.Panel1.Controls.Add(Me.txttrailermodel)
        Me.Panel1.Controls.Add(Me.txtmotormake)
        Me.Panel1.Controls.Add(Me.TxtBoatMake)
        Me.Panel1.Controls.Add(Me.TxtCity)
        Me.Panel1.Controls.Add(Me.txtAddress)
        Me.Panel1.Controls.Add(Me.txttrailermake)
        Me.Panel1.Controls.Add(Me.Label24)
        Me.Panel1.Controls.Add(Me.Label25)
        Me.Panel1.Controls.Add(Me.Label26)
        Me.Panel1.Controls.Add(Me.Label22)
        Me.Panel1.Controls.Add(Me.Label23)
        Me.Panel1.Controls.Add(Me.Label20)
        Me.Panel1.Controls.Add(Me.Label21)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.Label19)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(3, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(789, 266)
        Me.Panel1.TabIndex = 0
        '
        'txtN1F
        '
        Me.txtN1F.Location = New System.Drawing.Point(345, 43)
        Me.txtN1F.Name = "txtN1F"
        Me.txtN1F.Size = New System.Drawing.Size(99, 20)
        Me.txtN1F.TabIndex = 1
        '
        'txtN2F
        '
        Me.txtN2F.Location = New System.Drawing.Point(345, 66)
        Me.txtN2F.Name = "txtN2F"
        Me.txtN2F.Size = New System.Drawing.Size(99, 20)
        Me.txtN2F.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(248, 65)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(85, 18)
        Me.Label3.TabIndex = 49
        Me.Label3.Text = "First Name:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(248, 42)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(85, 18)
        Me.Label12.TabIndex = 48
        Me.Label12.Text = "First Name:"
        '
        'txtN1L
        '
        Me.txtN1L.Location = New System.Drawing.Point(143, 43)
        Me.txtN1L.Name = "txtN1L"
        Me.txtN1L.Size = New System.Drawing.Size(99, 20)
        Me.txtN1L.TabIndex = 0
        '
        'txtN2L
        '
        Me.txtN2L.Location = New System.Drawing.Point(143, 66)
        Me.txtN2L.Name = "txtN2L"
        Me.txtN2L.Size = New System.Drawing.Size(99, 20)
        Me.txtN2L.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(46, 65)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(84, 18)
        Me.Label2.TabIndex = 45
        Me.Label2.Text = "Last Name:"
        '
        'txtcolor
        '
        Me.txtcolor.Location = New System.Drawing.Point(143, 159)
        Me.txtcolor.Name = "txtcolor"
        Me.txtcolor.Size = New System.Drawing.Size(99, 20)
        Me.txtcolor.TabIndex = 14
        '
        'txtyear
        '
        Me.txtyear.Location = New System.Drawing.Point(342, 159)
        Me.txtyear.Name = "txtyear"
        Me.txtyear.Size = New System.Drawing.Size(99, 20)
        Me.txtyear.TabIndex = 15
        '
        'txtProv
        '
        Me.txtProv.Location = New System.Drawing.Point(330, 112)
        Me.txtProv.Name = "txtProv"
        Me.txtProv.Size = New System.Drawing.Size(47, 20)
        Me.txtProv.TabIndex = 6
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(294, 159)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(42, 18)
        Me.Label38.TabIndex = 44
        Me.Label38.Text = "Year:"
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Txtphone2
        '
        Me.Txtphone2.Location = New System.Drawing.Point(610, 66)
        Me.Txtphone2.Name = "Txtphone2"
        Me.Txtphone2.Size = New System.Drawing.Size(99, 20)
        Me.Txtphone2.TabIndex = 9
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(54, 161)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(84, 18)
        Me.Label39.TabIndex = 43
        Me.Label39.Text = "Boat Color:"
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Txtemail
        '
        Me.Txtemail.Location = New System.Drawing.Point(538, 88)
        Me.Txtemail.Name = "Txtemail"
        Me.Txtemail.Size = New System.Drawing.Size(171, 20)
        Me.Txtemail.TabIndex = 10
        '
        'txtphone1
        '
        Me.txtphone1.Location = New System.Drawing.Point(610, 40)
        Me.txtphone1.Name = "txtphone1"
        Me.txtphone1.Size = New System.Drawing.Size(99, 20)
        Me.txtphone1.TabIndex = 8
        '
        'txtpostal
        '
        Me.txtpostal.Location = New System.Drawing.Point(538, 111)
        Me.txtpostal.Name = "txtpostal"
        Me.txtpostal.Size = New System.Drawing.Size(99, 20)
        Me.txtpostal.TabIndex = 7
        '
        'txtmotorserial
        '
        Me.txtmotorserial.Location = New System.Drawing.Point(538, 186)
        Me.txtmotorserial.Name = "txtmotorserial"
        Me.txtmotorserial.Size = New System.Drawing.Size(171, 20)
        Me.txtmotorserial.TabIndex = 18
        '
        'txtBoatSerial
        '
        Me.txtBoatSerial.Location = New System.Drawing.Point(538, 137)
        Me.txtBoatSerial.Name = "txtBoatSerial"
        Me.txtBoatSerial.Size = New System.Drawing.Size(171, 20)
        Me.txtBoatSerial.TabIndex = 13
        '
        'txttrailerserial
        '
        Me.txttrailerserial.Location = New System.Drawing.Point(538, 209)
        Me.txttrailerserial.Name = "txttrailerserial"
        Me.txttrailerserial.Size = New System.Drawing.Size(171, 20)
        Me.txttrailerserial.TabIndex = 21
        '
        'txtmotormodel
        '
        Me.txtmotormodel.Location = New System.Drawing.Point(342, 184)
        Me.txtmotormodel.Name = "txtmotormodel"
        Me.txtmotormodel.Size = New System.Drawing.Size(99, 20)
        Me.txtmotormodel.TabIndex = 17
        '
        'txtboatmodel
        '
        Me.txtboatmodel.Location = New System.Drawing.Point(342, 135)
        Me.txtboatmodel.Name = "txtboatmodel"
        Me.txtboatmodel.Size = New System.Drawing.Size(99, 20)
        Me.txtboatmodel.TabIndex = 12
        '
        'txttrailermodel
        '
        Me.txttrailermodel.Location = New System.Drawing.Point(342, 207)
        Me.txttrailermodel.Name = "txttrailermodel"
        Me.txttrailermodel.Size = New System.Drawing.Size(99, 20)
        Me.txttrailermodel.TabIndex = 20
        '
        'txtmotormake
        '
        Me.txtmotormake.Location = New System.Drawing.Point(143, 184)
        Me.txtmotormake.Name = "txtmotormake"
        Me.txtmotormake.Size = New System.Drawing.Size(99, 20)
        Me.txtmotormake.TabIndex = 16
        '
        'TxtBoatMake
        '
        Me.TxtBoatMake.Location = New System.Drawing.Point(143, 135)
        Me.TxtBoatMake.Name = "TxtBoatMake"
        Me.TxtBoatMake.Size = New System.Drawing.Size(99, 20)
        Me.TxtBoatMake.TabIndex = 11
        '
        'TxtCity
        '
        Me.TxtCity.Location = New System.Drawing.Point(114, 112)
        Me.TxtCity.Name = "TxtCity"
        Me.TxtCity.Size = New System.Drawing.Size(128, 20)
        Me.TxtCity.TabIndex = 5
        '
        'txtAddress
        '
        Me.txtAddress.Location = New System.Drawing.Point(114, 88)
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(263, 20)
        Me.txtAddress.TabIndex = 4
        '
        'txttrailermake
        '
        Me.txttrailermake.Location = New System.Drawing.Point(143, 207)
        Me.txttrailermake.Name = "txttrailermake"
        Me.txttrailermake.Size = New System.Drawing.Size(99, 20)
        Me.txttrailermake.TabIndex = 19
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(447, 208)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(94, 18)
        Me.Label24.TabIndex = 17
        Me.Label24.Text = "Trailer Serial:"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(248, 208)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(98, 18)
        Me.Label25.TabIndex = 16
        Me.Label25.Text = "Trailer Model:"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(50, 208)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(94, 18)
        Me.Label26.TabIndex = 15
        Me.Label26.Text = "Trailer Make:"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(456, 137)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(84, 18)
        Me.Label22.TabIndex = 13
        Me.Label22.Text = "Boat Serial:"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(446, 186)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(93, 18)
        Me.Label23.TabIndex = 14
        Me.Label23.Text = "Motor Serial:"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(248, 137)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(88, 18)
        Me.Label20.TabIndex = 11
        Me.Label20.Text = "Boat Model:"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(247, 186)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(97, 18)
        Me.Label21.TabIndex = 12
        Me.Label21.Text = "Motor Model:"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(50, 137)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(84, 18)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "Boat Make:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(248, 111)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(70, 18)
        Me.Label9.TabIndex = 7
        Me.Label9.Text = "Province:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(533, 68)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(75, 18)
        Me.Label10.TabIndex = 6
        Me.Label10.Text = "Phone #2:"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(536, 42)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(67, 18)
        Me.Label11.TabIndex = 5
        Me.Label11.Text = "Phone #:"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(420, 90)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(112, 18)
        Me.Label15.TabIndex = 9
        Me.Label15.Text = "E-mail Address:"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(49, 186)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(93, 18)
        Me.Label19.TabIndex = 10
        Me.Label19.Text = "Motor Make:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(438, 111)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(94, 18)
        Me.Label7.TabIndex = 4
        Me.Label7.Text = "Postal Code:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(50, 111)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(37, 18)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "City:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(50, 90)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(66, 18)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Address:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(46, 42)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(84, 18)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Last Name:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(9, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(153, 24)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Customer Profile:"
        '
        'BtnCustData
        '
        Me.BtnCustData.Location = New System.Drawing.Point(581, 284)
        Me.BtnCustData.Name = "BtnCustData"
        Me.BtnCustData.Size = New System.Drawing.Size(199, 35)
        Me.BtnCustData.TabIndex = 1
        Me.BtnCustData.Text = "Save New Customer Profile"
        Me.BtnCustData.UseVisualStyleBackColor = True
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(47, 292)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(263, 20)
        Me.txtName.TabIndex = 0
        Me.txtName.Visible = False
        '
        'frmAddCustomer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(792, 331)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.BtnCustData)
        Me.Controls.Add(Me.txtName)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmAddCustomer"
        Me.Text = "Create a new customer profile"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txtProv As System.Windows.Forms.TextBox
    Friend WithEvents Txtphone2 As System.Windows.Forms.TextBox
    Friend WithEvents Txtemail As System.Windows.Forms.TextBox
    Friend WithEvents txtphone1 As System.Windows.Forms.TextBox
    Friend WithEvents txtpostal As System.Windows.Forms.TextBox
    Friend WithEvents txtmotorserial As System.Windows.Forms.TextBox
    Friend WithEvents txtBoatSerial As System.Windows.Forms.TextBox
    Friend WithEvents txttrailerserial As System.Windows.Forms.TextBox
    Friend WithEvents txtmotormodel As System.Windows.Forms.TextBox
    Friend WithEvents txtboatmodel As System.Windows.Forms.TextBox
    Friend WithEvents txttrailermodel As System.Windows.Forms.TextBox
    Friend WithEvents txtmotormake As System.Windows.Forms.TextBox
    Friend WithEvents TxtBoatMake As System.Windows.Forms.TextBox
    Friend WithEvents TxtCity As System.Windows.Forms.TextBox
    Friend WithEvents txtAddress As System.Windows.Forms.TextBox
    Friend WithEvents txttrailermake As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents BtnCustData As System.Windows.Forms.Button
    Friend WithEvents txtcolor As System.Windows.Forms.TextBox
    Friend WithEvents txtyear As System.Windows.Forms.TextBox
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents txtN1F As System.Windows.Forms.TextBox
    Friend WithEvents txtN2F As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtN1L As System.Windows.Forms.TextBox
    Friend WithEvents txtN2L As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtName As System.Windows.Forms.TextBox
End Class
