﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmIssue
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.txtworkdone = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.CmbApprovalStatus = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Cmbpaymenttype = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.CmbTypeOfWork = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmbStatus = New System.Windows.Forms.ComboBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtDesc = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.pnlWarrantyHours = New System.Windows.Forms.Panel()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.txtApprovedAmt = New System.Windows.Forms.TextBox()
        Me.txtApprovedHrs = New System.Windows.Forms.TextBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.txtRequestedAmt = New System.Windows.Forms.TextBox()
        Me.txtRequestedHrs = New System.Windows.Forms.TextBox()
        Me.Btnreactivate = New System.Windows.Forms.Button()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.CopyActualtoBilled = New System.Windows.Forms.Button()
        Me.CmbBillCustomer = New System.Windows.Forms.ComboBox()
        Me.labelMessage = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtbilledhrs = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtbillablehrs = New System.Windows.Forms.TextBox()
        Me.btncompleted = New System.Windows.Forms.Button()
        Me.btnAssign = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtAssignedTo = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtQuoteRate = New System.Windows.Forms.TextBox()
        Me.btnLogCall = New System.Windows.Forms.Button()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.tbQuote = New System.Windows.Forms.TabPage()
        Me.quotepanel = New System.Windows.Forms.Panel()
        Me.btnFillFromParts = New System.Windows.Forms.Button()
        Me.btnPrintQuote = New System.Windows.Forms.Button()
        Me.txtQuoteDetailing = New System.Windows.Forms.TextBox()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.txtQuoteShipping = New System.Windows.Forms.TextBox()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.txtshopsupplies = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.BtnquoteDeclined = New System.Windows.Forms.Button()
        Me.btnquoteapproved = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtQuoteTotal = New System.Windows.Forms.TextBox()
        Me.txtQuoteSublet = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtQuoteParts = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtQuoteLabour = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtQuoteHours = New System.Windows.Forms.TextBox()
        Me.tbWarranty = New System.Windows.Forms.TabPage()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.txtClaimNum = New System.Windows.Forms.TextBox()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.txtCreditNum = New System.Windows.Forms.TextBox()
        Me.cboWarrantyType = New System.Windows.Forms.ComboBox()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.BtnSubmitted = New System.Windows.Forms.Button()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.txtwarrantynotes = New System.Windows.Forms.TextBox()
        Me.BtnWarrantyDeclined = New System.Windows.Forms.Button()
        Me.BtnWarrantyApproved = New System.Windows.Forms.Button()
        Me.tbService = New System.Windows.Forms.TabPage()
        Me.cboQuantity = New System.Windows.Forms.ComboBox()
        Me.lblQuantity = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.CmbPkgType = New System.Windows.Forms.ComboBox()
        Me.txtservicepackage = New System.Windows.Forms.TextBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.txtstdServiceParts = New System.Windows.Forms.TextBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.txtstdservicesupplies = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.txtsrdservicetotal = New System.Windows.Forms.TextBox()
        Me.txtservicepackageprice = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.DVServicePkg = New System.Windows.Forms.DataGridView()
        Me.Col1 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.tbWork = New System.Windows.Forms.TabPage()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.DVWorkDone = New System.Windows.Forms.DataGridView()
        Me.View = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.tbParts = New System.Windows.Forms.TabPage()
        Me.btnOrderPart = New System.Windows.Forms.Button()
        Me.txtpartsclone = New System.Windows.Forms.TextBox()
        Me.btnaddpart = New System.Windows.Forms.Button()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.DVParts = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.Edit = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.tbSublet = New System.Windows.Forms.TabPage()
        Me.pnlWarantySublet = New System.Windows.Forms.Panel()
        Me.txtWSubletInv = New System.Windows.Forms.TextBox()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.txtWSubletAppr = New System.Windows.Forms.TextBox()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.txtWSubletEst = New System.Windows.Forms.TextBox()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.txtWSubletName = New System.Windows.Forms.TextBox()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.txtsubletcost = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtsubletmarkup = New System.Windows.Forms.TextBox()
        Me.txtsubletbilled = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.tbPics = New System.Windows.Forms.TabPage()
        Me.btnUploadNewPics = New System.Windows.Forms.Button()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.DVPictures = New System.Windows.Forms.DataGridView()
        Me.RP = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.VP = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.tbBilling = New System.Windows.Forms.TabPage()
        Me.txtbillingshopsupplies = New System.Windows.Forms.TextBox()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.txtsublettotal = New System.Windows.Forms.TextBox()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.txtpartstotal = New System.Windows.Forms.TextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.txtlabourtotal = New System.Windows.Forms.TextBox()
        Me.label993 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.DVpayments = New System.Windows.Forms.DataGridView()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtbill = New System.Windows.Forms.TextBox()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.pnlWarrantyHours.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.tbQuote.SuspendLayout()
        Me.quotepanel.SuspendLayout()
        Me.tbWarranty.SuspendLayout()
        Me.tbService.SuspendLayout()
        CType(Me.DVServicePkg, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tbWork.SuspendLayout()
        CType(Me.DVWorkDone, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tbParts.SuspendLayout()
        CType(Me.DVParts, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tbSublet.SuspendLayout()
        Me.pnlWarantySublet.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.tbPics.SuspendLayout()
        CType(Me.DVPictures, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tbBilling.SuspendLayout()
        CType(Me.DVpayments, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.BackColor = System.Drawing.Color.White
        Me.SplitContainer1.Panel1.Controls.Add(Me.Label43)
        Me.SplitContainer1.Panel1.Controls.Add(Me.txtworkdone)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Button2)
        Me.SplitContainer1.Panel1.Controls.Add(Me.CmbApprovalStatus)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Label3)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Cmbpaymenttype)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Label4)
        Me.SplitContainer1.Panel1.Controls.Add(Me.CmbTypeOfWork)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Label2)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Label1)
        Me.SplitContainer1.Panel1.Controls.Add(Me.cmbStatus)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Label14)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Label16)
        Me.SplitContainer1.Panel1.Controls.Add(Me.txtDesc)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.Panel1)
        Me.SplitContainer1.Panel2.Controls.Add(Me.TabControl1)
        Me.SplitContainer1.Size = New System.Drawing.Size(965, 600)
        Me.SplitContainer1.SplitterDistance = 162
        Me.SplitContainer1.TabIndex = 0
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(528, 16)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(208, 18)
        Me.Label43.TabIndex = 90
        Me.Label43.Text = "Summary of Work Performed:"
        '
        'txtworkdone
        '
        Me.txtworkdone.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtworkdone.Location = New System.Drawing.Point(531, 43)
        Me.txtworkdone.Multiline = True
        Me.txtworkdone.Name = "txtworkdone"
        Me.txtworkdone.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtworkdone.Size = New System.Drawing.Size(422, 103)
        Me.txtworkdone.TabIndex = 89
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(198, 15)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(76, 22)
        Me.Button2.TabIndex = 88
        Me.Button2.Text = "View WO"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'CmbApprovalStatus
        '
        Me.CmbApprovalStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbApprovalStatus.Enabled = False
        Me.CmbApprovalStatus.FormattingEnabled = True
        Me.CmbApprovalStatus.Items.AddRange(New Object() {"N/A", "Pending", "Approved", "Submited", "Denied"})
        Me.CmbApprovalStatus.Location = New System.Drawing.Point(153, 124)
        Me.CmbApprovalStatus.Name = "CmbApprovalStatus"
        Me.CmbApprovalStatus.Size = New System.Drawing.Size(121, 21)
        Me.CmbApprovalStatus.TabIndex = 69
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(31, 127)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(115, 18)
        Me.Label3.TabIndex = 70
        Me.Label3.Text = "Approval Status:"
        '
        'Cmbpaymenttype
        '
        Me.Cmbpaymenttype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmbpaymenttype.Enabled = False
        Me.Cmbpaymenttype.FormattingEnabled = True
        Me.Cmbpaymenttype.Items.AddRange(New Object() {"RIG", "Standard Service", "No Quote Requested", "Quote Requested", "Quote Approved", "WARRANTY"})
        Me.Cmbpaymenttype.Location = New System.Drawing.Point(153, 97)
        Me.Cmbpaymenttype.Name = "Cmbpaymenttype"
        Me.Cmbpaymenttype.Size = New System.Drawing.Size(121, 21)
        Me.Cmbpaymenttype.TabIndex = 67
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(40, 100)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(106, 18)
        Me.Label4.TabIndex = 68
        Me.Label4.Text = "Payment Type:"
        '
        'CmbTypeOfWork
        '
        Me.CmbTypeOfWork.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbTypeOfWork.Enabled = False
        Me.CmbTypeOfWork.FormattingEnabled = True
        Me.CmbTypeOfWork.Items.AddRange(New Object() {"Standard Service", "Standard Service (PREPAID)", "Rig - Sterndrive", "Rig - Outboard", "Rig - Jet", "Rig - V-Drive", "Gelcoat", "Major Mechanical", "Minor Mechanical", "Electronic", "Tower Install", "Other", "SUBLET", "Insurance", "Storage", "Upholstery", "Metal Work"})
        Me.CmbTypeOfWork.Location = New System.Drawing.Point(153, 43)
        Me.CmbTypeOfWork.Name = "CmbTypeOfWork"
        Me.CmbTypeOfWork.Size = New System.Drawing.Size(121, 21)
        Me.CmbTypeOfWork.TabIndex = 65
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(42, 46)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(105, 18)
        Me.Label2.TabIndex = 66
        Me.Label2.Text = "Type Of Work:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(120, 24)
        Me.Label1.TabIndex = 64
        Me.Label1.Text = "Issue Report:"
        '
        'cmbStatus
        '
        Me.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStatus.Enabled = False
        Me.cmbStatus.FormattingEnabled = True
        Me.cmbStatus.Items.AddRange(New Object() {"Reported", "To Be Assigned", "To Be Quoted", "Waiting on Warranty", "Waiting for Pickup", "Assigned", "In Progress", "Completed", "Not Completed"})
        Me.cmbStatus.Location = New System.Drawing.Point(153, 70)
        Me.cmbStatus.Name = "cmbStatus"
        Me.cmbStatus.Size = New System.Drawing.Size(121, 21)
        Me.cmbStatus.TabIndex = 62
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(92, 74)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(54, 18)
        Me.Label14.TabIndex = 63
        Me.Label14.Text = "Status:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(277, 16)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(164, 18)
        Me.Label16.TabIndex = 61
        Me.Label16.Text = "Description of Problem:"
        '
        'txtDesc
        '
        Me.txtDesc.Location = New System.Drawing.Point(280, 43)
        Me.txtDesc.Multiline = True
        Me.txtDesc.Name = "txtDesc"
        Me.txtDesc.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtDesc.Size = New System.Drawing.Size(245, 103)
        Me.txtDesc.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.SystemColors.Window
        Me.Panel1.Controls.Add(Me.btnClose)
        Me.Panel1.Controls.Add(Me.pnlWarrantyHours)
        Me.Panel1.Controls.Add(Me.Btnreactivate)
        Me.Panel1.Controls.Add(Me.Label38)
        Me.Panel1.Controls.Add(Me.CopyActualtoBilled)
        Me.Panel1.Controls.Add(Me.CmbBillCustomer)
        Me.Panel1.Controls.Add(Me.labelMessage)
        Me.Panel1.Controls.Add(Me.Label25)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.txtbilledhrs)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.txtbillablehrs)
        Me.Panel1.Controls.Add(Me.btncompleted)
        Me.Panel1.Controls.Add(Me.btnAssign)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.txtAssignedTo)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.txtQuoteRate)
        Me.Panel1.Controls.Add(Me.btnLogCall)
        Me.Panel1.Location = New System.Drawing.Point(696, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(267, 426)
        Me.Panel1.TabIndex = 1
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(12, 381)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(114, 33)
        Me.btnClose.TabIndex = 110
        Me.btnClose.Text = "Close Form"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'pnlWarrantyHours
        '
        Me.pnlWarrantyHours.Controls.Add(Me.Label51)
        Me.pnlWarrantyHours.Controls.Add(Me.Label52)
        Me.pnlWarrantyHours.Controls.Add(Me.txtApprovedAmt)
        Me.pnlWarrantyHours.Controls.Add(Me.txtApprovedHrs)
        Me.pnlWarrantyHours.Controls.Add(Me.Label44)
        Me.pnlWarrantyHours.Controls.Add(Me.Label46)
        Me.pnlWarrantyHours.Controls.Add(Me.txtRequestedAmt)
        Me.pnlWarrantyHours.Controls.Add(Me.txtRequestedHrs)
        Me.pnlWarrantyHours.Location = New System.Drawing.Point(3, 179)
        Me.pnlWarrantyHours.Name = "pnlWarrantyHours"
        Me.pnlWarrantyHours.Size = New System.Drawing.Size(254, 118)
        Me.pnlWarrantyHours.TabIndex = 109
        Me.pnlWarrantyHours.Visible = False
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.Location = New System.Drawing.Point(4, 59)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(129, 18)
        Me.Label51.TabIndex = 110
        Me.Label51.Text = "Approved Amount:"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.Location = New System.Drawing.Point(4, 85)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(119, 18)
        Me.Label52.TabIndex = 112
        Me.Label52.Text = "Approved Hours:"
        '
        'txtApprovedAmt
        '
        Me.txtApprovedAmt.Enabled = False
        Me.txtApprovedAmt.Location = New System.Drawing.Point(157, 57)
        Me.txtApprovedAmt.Name = "txtApprovedAmt"
        Me.txtApprovedAmt.Size = New System.Drawing.Size(62, 20)
        Me.txtApprovedAmt.TabIndex = 109
        '
        'txtApprovedHrs
        '
        Me.txtApprovedHrs.Enabled = False
        Me.txtApprovedHrs.Location = New System.Drawing.Point(157, 83)
        Me.txtApprovedHrs.Name = "txtApprovedHrs"
        Me.txtApprovedHrs.Size = New System.Drawing.Size(62, 20)
        Me.txtApprovedHrs.TabIndex = 111
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(4, 7)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(138, 18)
        Me.Label44.TabIndex = 106
        Me.Label44.Text = "Requested Amount:"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(4, 33)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(128, 18)
        Me.Label46.TabIndex = 108
        Me.Label46.Text = "Requested Hours:"
        '
        'txtRequestedAmt
        '
        Me.txtRequestedAmt.Enabled = False
        Me.txtRequestedAmt.Location = New System.Drawing.Point(157, 5)
        Me.txtRequestedAmt.Name = "txtRequestedAmt"
        Me.txtRequestedAmt.Size = New System.Drawing.Size(62, 20)
        Me.txtRequestedAmt.TabIndex = 105
        '
        'txtRequestedHrs
        '
        Me.txtRequestedHrs.Enabled = False
        Me.txtRequestedHrs.Location = New System.Drawing.Point(157, 31)
        Me.txtRequestedHrs.Name = "txtRequestedHrs"
        Me.txtRequestedHrs.Size = New System.Drawing.Size(62, 20)
        Me.txtRequestedHrs.TabIndex = 107
        '
        'Btnreactivate
        '
        Me.Btnreactivate.Location = New System.Drawing.Point(12, 342)
        Me.Btnreactivate.Name = "Btnreactivate"
        Me.Btnreactivate.Size = New System.Drawing.Size(114, 33)
        Me.Btnreactivate.TabIndex = 104
        Me.Btnreactivate.Text = "Reactivate Issue"
        Me.Btnreactivate.UseVisualStyleBackColor = True
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(7, 157)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(101, 18)
        Me.Label38.TabIndex = 103
        Me.Label38.Text = "Bill Customer:"
        '
        'CopyActualtoBilled
        '
        Me.CopyActualtoBilled.Location = New System.Drawing.Point(227, 100)
        Me.CopyActualtoBilled.Name = "CopyActualtoBilled"
        Me.CopyActualtoBilled.Size = New System.Drawing.Size(24, 23)
        Me.CopyActualtoBilled.TabIndex = 88
        Me.CopyActualtoBilled.UseVisualStyleBackColor = True
        '
        'CmbBillCustomer
        '
        Me.CmbBillCustomer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbBillCustomer.FormattingEnabled = True
        Me.CmbBillCustomer.Items.AddRange(New Object() {"YES", "NO"})
        Me.CmbBillCustomer.Location = New System.Drawing.Point(156, 154)
        Me.CmbBillCustomer.Name = "CmbBillCustomer"
        Me.CmbBillCustomer.Size = New System.Drawing.Size(66, 21)
        Me.CmbBillCustomer.TabIndex = 102
        '
        'labelMessage
        '
        Me.labelMessage.AutoSize = True
        Me.labelMessage.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labelMessage.ForeColor = System.Drawing.Color.Red
        Me.labelMessage.Location = New System.Drawing.Point(7, 300)
        Me.labelMessage.Name = "labelMessage"
        Me.labelMessage.Size = New System.Drawing.Size(248, 39)
        Me.labelMessage.TabIndex = 87
        Me.labelMessage.Text = "Work Stopped"
        Me.labelMessage.Visible = False
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(7, 78)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(93, 18)
        Me.Label25.TabIndex = 86
        Me.Label25.Text = "Labour Rate:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(7, 130)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(93, 18)
        Me.Label13.TabIndex = 83
        Me.Label13.Text = "Actual Time :"
        '
        'txtbilledhrs
        '
        Me.txtbilledhrs.Enabled = False
        Me.txtbilledhrs.Location = New System.Drawing.Point(160, 128)
        Me.txtbilledhrs.Name = "txtbilledhrs"
        Me.txtbilledhrs.Size = New System.Drawing.Size(62, 20)
        Me.txtbilledhrs.TabIndex = 82
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(7, 104)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(103, 18)
        Me.Label12.TabIndex = 81
        Me.Label12.Text = "Billable Hours:"
        '
        'txtbillablehrs
        '
        Me.txtbillablehrs.Enabled = False
        Me.txtbillablehrs.Location = New System.Drawing.Point(160, 102)
        Me.txtbillablehrs.Name = "txtbillablehrs"
        Me.txtbillablehrs.Size = New System.Drawing.Size(62, 20)
        Me.txtbillablehrs.TabIndex = 80
        '
        'btncompleted
        '
        Me.btncompleted.Location = New System.Drawing.Point(141, 381)
        Me.btncompleted.Name = "btncompleted"
        Me.btncompleted.Size = New System.Drawing.Size(114, 33)
        Me.btncompleted.TabIndex = 78
        Me.btncompleted.Text = "Work Is Complete"
        Me.btncompleted.UseVisualStyleBackColor = True
        '
        'btnAssign
        '
        Me.btnAssign.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAssign.Location = New System.Drawing.Point(115, 48)
        Me.btnAssign.Name = "btnAssign"
        Me.btnAssign.Size = New System.Drawing.Size(140, 22)
        Me.btnAssign.TabIndex = 65
        Me.btnAssign.Text = "Select a Tech"
        Me.btnAssign.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(6, 27)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(94, 18)
        Me.Label5.TabIndex = 64
        Me.Label5.Text = "Assigned To:"
        '
        'txtAssignedTo
        '
        Me.txtAssignedTo.Enabled = False
        Me.txtAssignedTo.Location = New System.Drawing.Point(115, 25)
        Me.txtAssignedTo.Name = "txtAssignedTo"
        Me.txtAssignedTo.Size = New System.Drawing.Size(140, 20)
        Me.txtAssignedTo.TabIndex = 0
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(228, 78)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(28, 18)
        Me.Label8.TabIndex = 69
        Me.Label8.Text = "/Hr"
        '
        'txtQuoteRate
        '
        Me.txtQuoteRate.Enabled = False
        Me.txtQuoteRate.Location = New System.Drawing.Point(160, 76)
        Me.txtQuoteRate.Name = "txtQuoteRate"
        Me.txtQuoteRate.Size = New System.Drawing.Size(62, 20)
        Me.txtQuoteRate.TabIndex = 68
        Me.txtQuoteRate.Text = "120"
        '
        'btnLogCall
        '
        Me.btnLogCall.Location = New System.Drawing.Point(141, 342)
        Me.btnLogCall.Name = "btnLogCall"
        Me.btnLogCall.Size = New System.Drawing.Size(114, 33)
        Me.btnLogCall.TabIndex = 77
        Me.btnLogCall.Text = "Log A Call"
        Me.btnLogCall.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.tbQuote)
        Me.TabControl1.Controls.Add(Me.tbWarranty)
        Me.TabControl1.Controls.Add(Me.tbService)
        Me.TabControl1.Controls.Add(Me.tbWork)
        Me.TabControl1.Controls.Add(Me.tbParts)
        Me.TabControl1.Controls.Add(Me.tbSublet)
        Me.TabControl1.Controls.Add(Me.tbPics)
        Me.TabControl1.Controls.Add(Me.tbBilling)
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(697, 426)
        Me.TabControl1.TabIndex = 0
        '
        'tbQuote
        '
        Me.tbQuote.Controls.Add(Me.quotepanel)
        Me.tbQuote.Location = New System.Drawing.Point(4, 22)
        Me.tbQuote.Name = "tbQuote"
        Me.tbQuote.Padding = New System.Windows.Forms.Padding(3)
        Me.tbQuote.Size = New System.Drawing.Size(689, 400)
        Me.tbQuote.TabIndex = 4
        Me.tbQuote.Text = "Quote"
        Me.tbQuote.UseVisualStyleBackColor = True
        '
        'quotepanel
        '
        Me.quotepanel.Controls.Add(Me.btnFillFromParts)
        Me.quotepanel.Controls.Add(Me.btnPrintQuote)
        Me.quotepanel.Controls.Add(Me.txtQuoteDetailing)
        Me.quotepanel.Controls.Add(Me.Label56)
        Me.quotepanel.Controls.Add(Me.txtQuoteShipping)
        Me.quotepanel.Controls.Add(Me.Label55)
        Me.quotepanel.Controls.Add(Me.Label27)
        Me.quotepanel.Controls.Add(Me.txtshopsupplies)
        Me.quotepanel.Controls.Add(Me.Label26)
        Me.quotepanel.Controls.Add(Me.Label17)
        Me.quotepanel.Controls.Add(Me.Label15)
        Me.quotepanel.Controls.Add(Me.BtnquoteDeclined)
        Me.quotepanel.Controls.Add(Me.btnquoteapproved)
        Me.quotepanel.Controls.Add(Me.Label11)
        Me.quotepanel.Controls.Add(Me.txtQuoteTotal)
        Me.quotepanel.Controls.Add(Me.txtQuoteSublet)
        Me.quotepanel.Controls.Add(Me.Label10)
        Me.quotepanel.Controls.Add(Me.txtQuoteParts)
        Me.quotepanel.Controls.Add(Me.Label9)
        Me.quotepanel.Controls.Add(Me.txtQuoteLabour)
        Me.quotepanel.Controls.Add(Me.Label7)
        Me.quotepanel.Controls.Add(Me.Label6)
        Me.quotepanel.Controls.Add(Me.txtQuoteHours)
        Me.quotepanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.quotepanel.Location = New System.Drawing.Point(3, 3)
        Me.quotepanel.Name = "quotepanel"
        Me.quotepanel.Size = New System.Drawing.Size(683, 394)
        Me.quotepanel.TabIndex = 0
        '
        'btnFillFromParts
        '
        Me.btnFillFromParts.Location = New System.Drawing.Point(509, 95)
        Me.btnFillFromParts.Name = "btnFillFromParts"
        Me.btnFillFromParts.Size = New System.Drawing.Size(117, 23)
        Me.btnFillFromParts.TabIndex = 108
        Me.btnFillFromParts.Text = "Fill From Parts Tab"
        Me.btnFillFromParts.UseVisualStyleBackColor = True
        '
        'btnPrintQuote
        '
        Me.btnPrintQuote.Location = New System.Drawing.Point(404, 260)
        Me.btnPrintQuote.Name = "btnPrintQuote"
        Me.btnPrintQuote.Size = New System.Drawing.Size(83, 23)
        Me.btnPrintQuote.TabIndex = 107
        Me.btnPrintQuote.Text = "Print Quote"
        Me.btnPrintQuote.UseVisualStyleBackColor = True
        '
        'txtQuoteDetailing
        '
        Me.txtQuoteDetailing.Location = New System.Drawing.Point(407, 177)
        Me.txtQuoteDetailing.Name = "txtQuoteDetailing"
        Me.txtQuoteDetailing.Size = New System.Drawing.Size(80, 20)
        Me.txtQuoteDetailing.TabIndex = 6
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label56.Location = New System.Drawing.Point(42, 176)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(68, 18)
        Me.Label56.TabIndex = 106
        Me.Label56.Text = "Detailing:"
        '
        'txtQuoteShipping
        '
        Me.txtQuoteShipping.Location = New System.Drawing.Point(407, 151)
        Me.txtQuoteShipping.Name = "txtQuoteShipping"
        Me.txtQuoteShipping.Size = New System.Drawing.Size(80, 20)
        Me.txtQuoteShipping.TabIndex = 5
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.Location = New System.Drawing.Point(42, 150)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(68, 18)
        Me.Label55.TabIndex = 104
        Me.Label55.Text = "Shipping:"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(129, 236)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(61, 13)
        Me.Label27.TabIndex = 103
        Me.Label27.Text = "(Before tax)"
        '
        'txtshopsupplies
        '
        Me.txtshopsupplies.Enabled = False
        Me.txtshopsupplies.Location = New System.Drawing.Point(407, 203)
        Me.txtshopsupplies.Name = "txtshopsupplies"
        Me.txtshopsupplies.Size = New System.Drawing.Size(80, 20)
        Me.txtshopsupplies.TabIndex = 7
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(42, 202)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(107, 18)
        Me.Label26.TabIndex = 101
        Me.Label26.Text = "Shop Supplies:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(14, 15)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(67, 24)
        Me.Label17.TabIndex = 100
        Me.Label17.Text = "Quote:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(48, 260)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(218, 13)
        Me.Label15.TabIndex = 99
        Me.Label15.Text = "Please log all converstions with the customer"
        '
        'BtnquoteDeclined
        '
        Me.BtnquoteDeclined.Location = New System.Drawing.Point(404, 346)
        Me.BtnquoteDeclined.Name = "BtnquoteDeclined"
        Me.BtnquoteDeclined.Size = New System.Drawing.Size(83, 23)
        Me.BtnquoteDeclined.TabIndex = 10
        Me.BtnquoteDeclined.Text = "Declined"
        Me.BtnquoteDeclined.UseVisualStyleBackColor = True
        Me.BtnquoteDeclined.Visible = False
        '
        'btnquoteapproved
        '
        Me.btnquoteapproved.Location = New System.Drawing.Point(404, 317)
        Me.btnquoteapproved.Name = "btnquoteapproved"
        Me.btnquoteapproved.Size = New System.Drawing.Size(83, 23)
        Me.btnquoteapproved.TabIndex = 9
        Me.btnquoteapproved.Text = "Approved"
        Me.btnquoteapproved.UseVisualStyleBackColor = True
        Me.btnquoteapproved.Visible = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(42, 231)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(90, 18)
        Me.Label11.TabIndex = 96
        Me.Label11.Text = "Total Quote:"
        '
        'txtQuoteTotal
        '
        Me.txtQuoteTotal.Enabled = False
        Me.txtQuoteTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtQuoteTotal.Location = New System.Drawing.Point(407, 229)
        Me.txtQuoteTotal.Name = "txtQuoteTotal"
        Me.txtQuoteTotal.Size = New System.Drawing.Size(80, 20)
        Me.txtQuoteTotal.TabIndex = 8
        '
        'txtQuoteSublet
        '
        Me.txtQuoteSublet.Location = New System.Drawing.Point(407, 125)
        Me.txtQuoteSublet.Name = "txtQuoteSublet"
        Me.txtQuoteSublet.Size = New System.Drawing.Size(80, 20)
        Me.txtQuoteSublet.TabIndex = 4
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(42, 124)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(168, 18)
        Me.Label10.TabIndex = 93
        Me.Label10.Text = "Estimated Sublet (retail):"
        '
        'txtQuoteParts
        '
        Me.txtQuoteParts.Location = New System.Drawing.Point(407, 95)
        Me.txtQuoteParts.Name = "txtQuoteParts"
        Me.txtQuoteParts.Size = New System.Drawing.Size(80, 20)
        Me.txtQuoteParts.TabIndex = 3
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(42, 94)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(162, 18)
        Me.Label9.TabIndex = 91
        Me.Label9.Text = "Estimated Parts (retail):"
        '
        'txtQuoteLabour
        '
        Me.txtQuoteLabour.Enabled = False
        Me.txtQuoteLabour.Location = New System.Drawing.Point(407, 64)
        Me.txtQuoteLabour.Name = "txtQuoteLabour"
        Me.txtQuoteLabour.Size = New System.Drawing.Size(80, 20)
        Me.txtQuoteLabour.TabIndex = 2
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(213, 66)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(49, 18)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "Hours"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(42, 66)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(120, 18)
        Me.Label6.TabIndex = 88
        Me.Label6.Text = "Estimated Labor:"
        '
        'txtQuoteHours
        '
        Me.txtQuoteHours.Location = New System.Drawing.Point(170, 64)
        Me.txtQuoteHours.Name = "txtQuoteHours"
        Me.txtQuoteHours.Size = New System.Drawing.Size(37, 20)
        Me.txtQuoteHours.TabIndex = 0
        '
        'tbWarranty
        '
        Me.tbWarranty.Controls.Add(Me.Label54)
        Me.tbWarranty.Controls.Add(Me.txtClaimNum)
        Me.tbWarranty.Controls.Add(Me.Label53)
        Me.tbWarranty.Controls.Add(Me.txtCreditNum)
        Me.tbWarranty.Controls.Add(Me.cboWarrantyType)
        Me.tbWarranty.Controls.Add(Me.Label42)
        Me.tbWarranty.Controls.Add(Me.BtnSubmitted)
        Me.tbWarranty.Controls.Add(Me.Label28)
        Me.tbWarranty.Controls.Add(Me.txtwarrantynotes)
        Me.tbWarranty.Controls.Add(Me.BtnWarrantyDeclined)
        Me.tbWarranty.Controls.Add(Me.BtnWarrantyApproved)
        Me.tbWarranty.Location = New System.Drawing.Point(4, 22)
        Me.tbWarranty.Name = "tbWarranty"
        Me.tbWarranty.Size = New System.Drawing.Size(689, 400)
        Me.tbWarranty.TabIndex = 5
        Me.tbWarranty.Text = "Warranty"
        Me.tbWarranty.UseVisualStyleBackColor = True
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label54.Location = New System.Drawing.Point(390, 49)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(62, 18)
        Me.Label54.TabIndex = 110
        Me.Label54.Text = "Claim #:"
        '
        'txtClaimNum
        '
        Me.txtClaimNum.Location = New System.Drawing.Point(459, 49)
        Me.txtClaimNum.Name = "txtClaimNum"
        Me.txtClaimNum.Size = New System.Drawing.Size(146, 20)
        Me.txtClaimNum.TabIndex = 109
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.Location = New System.Drawing.Point(390, 23)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(63, 18)
        Me.Label53.TabIndex = 108
        Me.Label53.Text = "Credit #:"
        '
        'txtCreditNum
        '
        Me.txtCreditNum.Location = New System.Drawing.Point(459, 23)
        Me.txtCreditNum.Name = "txtCreditNum"
        Me.txtCreditNum.Size = New System.Drawing.Size(146, 20)
        Me.txtCreditNum.TabIndex = 107
        '
        'cboWarrantyType
        '
        Me.cboWarrantyType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboWarrantyType.FormattingEnabled = True
        Me.cboWarrantyType.Items.AddRange(New Object() {"Bayliner", "Centurion", "Ez Loader", "Four Winns", "Glastron", "Hewescraft", "Jensen Electronics", "Karavan", "Mercury", "Monterey", "Mid West", "PCM", "Pro Tech/Diamond Coat", "Prospec Electronics", "Sea Ray", "Shipwreck", "Sylvan/Smoker", "Volvo", "Yamaha", "Other"})
        Me.cboWarrantyType.Location = New System.Drawing.Point(154, 21)
        Me.cboWarrantyType.Name = "cboWarrantyType"
        Me.cboWarrantyType.Size = New System.Drawing.Size(207, 21)
        Me.cboWarrantyType.TabIndex = 92
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(20, 20)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(128, 18)
        Me.Label42.TabIndex = 93
        Me.Label42.Text = "Type Of Warranty:"
        '
        'BtnSubmitted
        '
        Me.BtnSubmitted.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BtnSubmitted.Location = New System.Drawing.Point(574, 301)
        Me.BtnSubmitted.Name = "BtnSubmitted"
        Me.BtnSubmitted.Size = New System.Drawing.Size(100, 23)
        Me.BtnSubmitted.TabIndex = 91
        Me.BtnSubmitted.Text = "Submitted"
        Me.BtnSubmitted.UseVisualStyleBackColor = True
        Me.BtnSubmitted.Visible = False
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(9, 68)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(52, 18)
        Me.Label28.TabIndex = 90
        Me.Label28.Text = "Notes:"
        '
        'txtwarrantynotes
        '
        Me.txtwarrantynotes.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtwarrantynotes.Location = New System.Drawing.Point(12, 103)
        Me.txtwarrantynotes.Multiline = True
        Me.txtwarrantynotes.Name = "txtwarrantynotes"
        Me.txtwarrantynotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtwarrantynotes.Size = New System.Drawing.Size(662, 192)
        Me.txtwarrantynotes.TabIndex = 89
        '
        'BtnWarrantyDeclined
        '
        Me.BtnWarrantyDeclined.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BtnWarrantyDeclined.Location = New System.Drawing.Point(574, 359)
        Me.BtnWarrantyDeclined.Name = "BtnWarrantyDeclined"
        Me.BtnWarrantyDeclined.Size = New System.Drawing.Size(100, 23)
        Me.BtnWarrantyDeclined.TabIndex = 88
        Me.BtnWarrantyDeclined.Text = "Declined"
        Me.BtnWarrantyDeclined.UseVisualStyleBackColor = True
        Me.BtnWarrantyDeclined.Visible = False
        '
        'BtnWarrantyApproved
        '
        Me.BtnWarrantyApproved.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BtnWarrantyApproved.Location = New System.Drawing.Point(574, 330)
        Me.BtnWarrantyApproved.Name = "BtnWarrantyApproved"
        Me.BtnWarrantyApproved.Size = New System.Drawing.Size(100, 23)
        Me.BtnWarrantyApproved.TabIndex = 87
        Me.BtnWarrantyApproved.Text = "Approved"
        Me.BtnWarrantyApproved.UseVisualStyleBackColor = True
        Me.BtnWarrantyApproved.Visible = False
        '
        'tbService
        '
        Me.tbService.Controls.Add(Me.cboQuantity)
        Me.tbService.Controls.Add(Me.lblQuantity)
        Me.tbService.Controls.Add(Me.Label31)
        Me.tbService.Controls.Add(Me.CmbPkgType)
        Me.tbService.Controls.Add(Me.txtservicepackage)
        Me.tbService.Controls.Add(Me.Label34)
        Me.tbService.Controls.Add(Me.Label37)
        Me.tbService.Controls.Add(Me.txtstdServiceParts)
        Me.tbService.Controls.Add(Me.Label45)
        Me.tbService.Controls.Add(Me.txtstdservicesupplies)
        Me.tbService.Controls.Add(Me.Label35)
        Me.tbService.Controls.Add(Me.Label36)
        Me.tbService.Controls.Add(Me.txtsrdservicetotal)
        Me.tbService.Controls.Add(Me.txtservicepackageprice)
        Me.tbService.Controls.Add(Me.Label30)
        Me.tbService.Controls.Add(Me.Label29)
        Me.tbService.Controls.Add(Me.DVServicePkg)
        Me.tbService.Location = New System.Drawing.Point(4, 22)
        Me.tbService.Name = "tbService"
        Me.tbService.Size = New System.Drawing.Size(689, 400)
        Me.tbService.TabIndex = 6
        Me.tbService.Text = "Standard Service"
        Me.tbService.UseVisualStyleBackColor = True
        '
        'cboQuantity
        '
        Me.cboQuantity.FormattingEnabled = True
        Me.cboQuantity.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9"})
        Me.cboQuantity.Location = New System.Drawing.Point(102, 330)
        Me.cboQuantity.Name = "cboQuantity"
        Me.cboQuantity.Size = New System.Drawing.Size(80, 21)
        Me.cboQuantity.TabIndex = 106
        Me.cboQuantity.Text = "1"
        Me.cboQuantity.Visible = False
        '
        'lblQuantity
        '
        Me.lblQuantity.AutoSize = True
        Me.lblQuantity.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuantity.Location = New System.Drawing.Point(30, 329)
        Me.lblQuantity.Name = "lblQuantity"
        Me.lblQuantity.Size = New System.Drawing.Size(66, 18)
        Me.lblQuantity.TabIndex = 105
        Me.lblQuantity.Text = "Quantity:"
        Me.lblQuantity.Visible = False
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(52, 278)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(44, 18)
        Me.Label31.TabIndex = 103
        Me.Label31.Text = "Type:"
        '
        'CmbPkgType
        '
        Me.CmbPkgType.FormattingEnabled = True
        Me.CmbPkgType.Items.AddRange(New Object() {"Detail", "Shrink Wrap", "Sterndrive 3.0L", "Sterndrive V6 - V8", "2 Stroke OB", "4 Stroke OB", "Trailer", "V - Drive"})
        Me.CmbPkgType.Location = New System.Drawing.Point(102, 276)
        Me.CmbPkgType.Name = "CmbPkgType"
        Me.CmbPkgType.Size = New System.Drawing.Size(238, 21)
        Me.CmbPkgType.TabIndex = 102
        '
        'txtservicepackage
        '
        Me.txtservicepackage.Enabled = False
        Me.txtservicepackage.Location = New System.Drawing.Point(102, 304)
        Me.txtservicepackage.Name = "txtservicepackage"
        Me.txtservicepackage.Size = New System.Drawing.Size(238, 20)
        Me.txtservicepackage.TabIndex = 87
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(460, 360)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(61, 13)
        Me.Label34.TabIndex = 98
        Me.Label34.Text = "(Before tax)"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(474, 329)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(47, 18)
        Me.Label37.TabIndex = 101
        Me.Label37.Text = "Parts:"
        '
        'txtstdServiceParts
        '
        Me.txtstdServiceParts.Enabled = False
        Me.txtstdServiceParts.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtstdServiceParts.Location = New System.Drawing.Point(527, 327)
        Me.txtstdServiceParts.Name = "txtstdServiceParts"
        Me.txtstdServiceParts.Size = New System.Drawing.Size(71, 20)
        Me.txtstdServiceParts.TabIndex = 100
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.Location = New System.Drawing.Point(398, 278)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(123, 18)
        Me.Label45.TabIndex = 99
        Me.Label45.Text = "Service Package:"
        '
        'txtstdservicesupplies
        '
        Me.txtstdservicesupplies.Enabled = False
        Me.txtstdservicesupplies.Location = New System.Drawing.Point(527, 301)
        Me.txtstdservicesupplies.Name = "txtstdservicesupplies"
        Me.txtstdservicesupplies.Size = New System.Drawing.Size(71, 20)
        Me.txtstdservicesupplies.TabIndex = 97
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(414, 303)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(107, 18)
        Me.Label35.TabIndex = 96
        Me.Label35.Text = "Shop Supplies:"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(414, 356)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(51, 18)
        Me.Label36.TabIndex = 95
        Me.Label36.Text = "Total:"
        '
        'txtsrdservicetotal
        '
        Me.txtsrdservicetotal.Enabled = False
        Me.txtsrdservicetotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsrdservicetotal.Location = New System.Drawing.Point(527, 353)
        Me.txtsrdservicetotal.Name = "txtsrdservicetotal"
        Me.txtsrdservicetotal.Size = New System.Drawing.Size(71, 20)
        Me.txtsrdservicetotal.TabIndex = 94
        '
        'txtservicepackageprice
        '
        Me.txtservicepackageprice.Enabled = False
        Me.txtservicepackageprice.Location = New System.Drawing.Point(527, 276)
        Me.txtservicepackageprice.Name = "txtservicepackageprice"
        Me.txtservicepackageprice.Size = New System.Drawing.Size(71, 20)
        Me.txtservicepackageprice.TabIndex = 90
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(27, 303)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(69, 18)
        Me.Label30.TabIndex = 89
        Me.Label30.Text = "Selected:"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(26, 29)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(156, 24)
        Me.Label29.TabIndex = 88
        Me.Label29.Text = "Service Package:"
        '
        'DVServicePkg
        '
        Me.DVServicePkg.AllowUserToAddRows = False
        Me.DVServicePkg.AllowUserToDeleteRows = False
        Me.DVServicePkg.AllowUserToResizeRows = False
        Me.DVServicePkg.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DVServicePkg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DVServicePkg.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Col1})
        Me.DVServicePkg.Location = New System.Drawing.Point(39, 60)
        Me.DVServicePkg.Name = "DVServicePkg"
        Me.DVServicePkg.ReadOnly = True
        Me.DVServicePkg.RowHeadersVisible = False
        Me.DVServicePkg.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DVServicePkg.Size = New System.Drawing.Size(610, 184)
        Me.DVServicePkg.TabIndex = 87
        '
        'Col1
        '
        Me.Col1.HeaderText = "Select"
        Me.Col1.Name = "Col1"
        Me.Col1.ReadOnly = True
        Me.Col1.Width = 60
        '
        'tbWork
        '
        Me.tbWork.Controls.Add(Me.Button4)
        Me.tbWork.Controls.Add(Me.Label18)
        Me.tbWork.Controls.Add(Me.DVWorkDone)
        Me.tbWork.Location = New System.Drawing.Point(4, 22)
        Me.tbWork.Name = "tbWork"
        Me.tbWork.Padding = New System.Windows.Forms.Padding(3)
        Me.tbWork.Size = New System.Drawing.Size(689, 400)
        Me.tbWork.TabIndex = 0
        Me.tbWork.Text = "Work Performed"
        Me.tbWork.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(569, 321)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(114, 31)
        Me.Button4.TabIndex = 66
        Me.Button4.Text = "Log Work"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(8, 20)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(152, 24)
        Me.Label18.TabIndex = 65
        Me.Label18.Text = "Work Performed:"
        '
        'DVWorkDone
        '
        Me.DVWorkDone.AllowUserToAddRows = False
        Me.DVWorkDone.AllowUserToDeleteRows = False
        Me.DVWorkDone.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DVWorkDone.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DVWorkDone.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.View})
        Me.DVWorkDone.Location = New System.Drawing.Point(8, 57)
        Me.DVWorkDone.Name = "DVWorkDone"
        Me.DVWorkDone.ReadOnly = True
        Me.DVWorkDone.RowHeadersVisible = False
        Me.DVWorkDone.Size = New System.Drawing.Size(675, 241)
        Me.DVWorkDone.TabIndex = 0
        '
        'View
        '
        Me.View.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.View.HeaderText = "View"
        Me.View.MinimumWidth = 40
        Me.View.Name = "View"
        Me.View.ReadOnly = True
        Me.View.Width = 40
        '
        'tbParts
        '
        Me.tbParts.Controls.Add(Me.btnOrderPart)
        Me.tbParts.Controls.Add(Me.txtpartsclone)
        Me.tbParts.Controls.Add(Me.btnaddpart)
        Me.tbParts.Controls.Add(Me.Label19)
        Me.tbParts.Controls.Add(Me.DVParts)
        Me.tbParts.Location = New System.Drawing.Point(4, 22)
        Me.tbParts.Name = "tbParts"
        Me.tbParts.Padding = New System.Windows.Forms.Padding(3)
        Me.tbParts.Size = New System.Drawing.Size(689, 400)
        Me.tbParts.TabIndex = 1
        Me.tbParts.Text = "Parts"
        Me.tbParts.UseVisualStyleBackColor = True
        '
        'btnOrderPart
        '
        Me.btnOrderPart.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOrderPart.Location = New System.Drawing.Point(129, 310)
        Me.btnOrderPart.Name = "btnOrderPart"
        Me.btnOrderPart.Size = New System.Drawing.Size(114, 31)
        Me.btnOrderPart.TabIndex = 92
        Me.btnOrderPart.Text = "Order Part"
        Me.btnOrderPart.UseVisualStyleBackColor = True
        '
        'txtpartsclone
        '
        Me.txtpartsclone.Enabled = False
        Me.txtpartsclone.Location = New System.Drawing.Point(437, 316)
        Me.txtpartsclone.Name = "txtpartsclone"
        Me.txtpartsclone.Size = New System.Drawing.Size(71, 20)
        Me.txtpartsclone.TabIndex = 91
        '
        'btnaddpart
        '
        Me.btnaddpart.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnaddpart.Location = New System.Drawing.Point(9, 310)
        Me.btnaddpart.Name = "btnaddpart"
        Me.btnaddpart.Size = New System.Drawing.Size(114, 31)
        Me.btnaddpart.TabIndex = 69
        Me.btnaddpart.Text = "Add Part"
        Me.btnaddpart.UseVisualStyleBackColor = True
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(9, 26)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(56, 24)
        Me.Label19.TabIndex = 68
        Me.Label19.Text = "Parts:"
        '
        'DVParts
        '
        Me.DVParts.AllowUserToAddRows = False
        Me.DVParts.AllowUserToDeleteRows = False
        Me.DVParts.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DVParts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DVParts.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Edit})
        Me.DVParts.Location = New System.Drawing.Point(9, 63)
        Me.DVParts.Name = "DVParts"
        Me.DVParts.ReadOnly = True
        Me.DVParts.RowHeadersVisible = False
        Me.DVParts.Size = New System.Drawing.Size(674, 241)
        Me.DVParts.TabIndex = 67
        '
        'Column1
        '
        Me.Column1.HeaderText = "Remove"
        Me.Column1.MinimumWidth = 50
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column1.Width = 50
        '
        'Edit
        '
        Me.Edit.HeaderText = "Edit"
        Me.Edit.Name = "Edit"
        Me.Edit.ReadOnly = True
        Me.Edit.Width = 50
        '
        'tbSublet
        '
        Me.tbSublet.Controls.Add(Me.pnlWarantySublet)
        Me.tbSublet.Controls.Add(Me.Panel2)
        Me.tbSublet.Controls.Add(Me.Label20)
        Me.tbSublet.Location = New System.Drawing.Point(4, 22)
        Me.tbSublet.Name = "tbSublet"
        Me.tbSublet.Size = New System.Drawing.Size(689, 400)
        Me.tbSublet.TabIndex = 2
        Me.tbSublet.Text = "Sublet"
        Me.tbSublet.UseVisualStyleBackColor = True
        '
        'pnlWarantySublet
        '
        Me.pnlWarantySublet.Controls.Add(Me.txtWSubletInv)
        Me.pnlWarantySublet.Controls.Add(Me.Label50)
        Me.pnlWarantySublet.Controls.Add(Me.txtWSubletAppr)
        Me.pnlWarantySublet.Controls.Add(Me.Label49)
        Me.pnlWarantySublet.Controls.Add(Me.txtWSubletEst)
        Me.pnlWarantySublet.Controls.Add(Me.Label48)
        Me.pnlWarantySublet.Controls.Add(Me.txtWSubletName)
        Me.pnlWarantySublet.Controls.Add(Me.Label47)
        Me.pnlWarantySublet.Location = New System.Drawing.Point(103, 55)
        Me.pnlWarantySublet.Name = "pnlWarantySublet"
        Me.pnlWarantySublet.Size = New System.Drawing.Size(431, 138)
        Me.pnlWarantySublet.TabIndex = 95
        Me.pnlWarantySublet.Visible = False
        '
        'txtWSubletInv
        '
        Me.txtWSubletInv.Location = New System.Drawing.Point(215, 92)
        Me.txtWSubletInv.Name = "txtWSubletInv"
        Me.txtWSubletInv.Size = New System.Drawing.Size(186, 20)
        Me.txtWSubletInv.TabIndex = 99
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.Location = New System.Drawing.Point(6, 92)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(70, 18)
        Me.Label50.TabIndex = 100
        Me.Label50.Text = "Invoice #:"
        '
        'txtWSubletAppr
        '
        Me.txtWSubletAppr.Location = New System.Drawing.Point(215, 63)
        Me.txtWSubletAppr.Name = "txtWSubletAppr"
        Me.txtWSubletAppr.Size = New System.Drawing.Size(186, 20)
        Me.txtWSubletAppr.TabIndex = 97
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.Location = New System.Drawing.Point(6, 63)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(200, 18)
        Me.Label49.TabIndex = 98
        Me.Label49.Text = "Approved from Manufacturer:"
        '
        'txtWSubletEst
        '
        Me.txtWSubletEst.Location = New System.Drawing.Point(215, 34)
        Me.txtWSubletEst.Name = "txtWSubletEst"
        Me.txtWSubletEst.Size = New System.Drawing.Size(186, 20)
        Me.txtWSubletEst.TabIndex = 95
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.Location = New System.Drawing.Point(6, 34)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(125, 18)
        Me.Label48.TabIndex = 96
        Me.Label48.Text = "Estimate Amount:"
        '
        'txtWSubletName
        '
        Me.txtWSubletName.Location = New System.Drawing.Point(215, 5)
        Me.txtWSubletName.Name = "txtWSubletName"
        Me.txtWSubletName.Size = New System.Drawing.Size(186, 20)
        Me.txtWSubletName.TabIndex = 93
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(6, 5)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(97, 18)
        Me.Label47.TabIndex = 94
        Me.Label47.Text = "Sublet Name:"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.txtsubletcost)
        Me.Panel2.Controls.Add(Me.Label24)
        Me.Panel2.Controls.Add(Me.Label23)
        Me.Panel2.Controls.Add(Me.Label21)
        Me.Panel2.Controls.Add(Me.txtsubletmarkup)
        Me.Panel2.Controls.Add(Me.txtsubletbilled)
        Me.Panel2.Location = New System.Drawing.Point(91, 54)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(255, 128)
        Me.Panel2.TabIndex = 96
        '
        'txtsubletcost
        '
        Me.txtsubletcost.Location = New System.Drawing.Point(138, 12)
        Me.txtsubletcost.Name = "txtsubletcost"
        Me.txtsubletcost.Size = New System.Drawing.Size(83, 20)
        Me.txtsubletcost.TabIndex = 84
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(12, 14)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(89, 18)
        Me.Label24.TabIndex = 85
        Me.Label24.Text = "Sublet Cost:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(12, 43)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(79, 18)
        Me.Label23.TabIndex = 86
        Me.Label23.Text = "Markup %:"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(12, 70)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(103, 18)
        Me.Label21.TabIndex = 91
        Me.Label21.Text = "Sublet Billable:"
        '
        'txtsubletmarkup
        '
        Me.txtsubletmarkup.Location = New System.Drawing.Point(138, 41)
        Me.txtsubletmarkup.Name = "txtsubletmarkup"
        Me.txtsubletmarkup.Size = New System.Drawing.Size(83, 20)
        Me.txtsubletmarkup.TabIndex = 87
        '
        'txtsubletbilled
        '
        Me.txtsubletbilled.Enabled = False
        Me.txtsubletbilled.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsubletbilled.Location = New System.Drawing.Point(138, 71)
        Me.txtsubletbilled.Name = "txtsubletbilled"
        Me.txtsubletbilled.Size = New System.Drawing.Size(83, 20)
        Me.txtsubletbilled.TabIndex = 90
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(8, 17)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(67, 24)
        Me.Label20.TabIndex = 92
        Me.Label20.Text = "Quote:"
        '
        'tbPics
        '
        Me.tbPics.Controls.Add(Me.btnUploadNewPics)
        Me.tbPics.Controls.Add(Me.Label32)
        Me.tbPics.Controls.Add(Me.DVPictures)
        Me.tbPics.Location = New System.Drawing.Point(4, 22)
        Me.tbPics.Name = "tbPics"
        Me.tbPics.Size = New System.Drawing.Size(689, 400)
        Me.tbPics.TabIndex = 3
        Me.tbPics.Text = "Pictures"
        Me.tbPics.UseVisualStyleBackColor = True
        '
        'btnUploadNewPics
        '
        Me.btnUploadNewPics.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnUploadNewPics.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUploadNewPics.Location = New System.Drawing.Point(562, 339)
        Me.btnUploadNewPics.Name = "btnUploadNewPics"
        Me.btnUploadNewPics.Size = New System.Drawing.Size(114, 31)
        Me.btnUploadNewPics.TabIndex = 69
        Me.btnUploadNewPics.Text = "Upload New"
        Me.btnUploadNewPics.UseVisualStyleBackColor = True
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(9, 33)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(82, 24)
        Me.Label32.TabIndex = 68
        Me.Label32.Text = "Pictures:"
        '
        'DVPictures
        '
        Me.DVPictures.AllowUserToAddRows = False
        Me.DVPictures.AllowUserToDeleteRows = False
        Me.DVPictures.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DVPictures.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DVPictures.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.RP, Me.VP})
        Me.DVPictures.Location = New System.Drawing.Point(9, 70)
        Me.DVPictures.Name = "DVPictures"
        Me.DVPictures.RowHeadersVisible = False
        Me.DVPictures.Size = New System.Drawing.Size(667, 241)
        Me.DVPictures.TabIndex = 67
        '
        'RP
        '
        Me.RP.HeaderText = "Remove"
        Me.RP.MinimumWidth = 50
        Me.RP.Name = "RP"
        Me.RP.Width = 50
        '
        'VP
        '
        Me.VP.HeaderText = "View"
        Me.VP.MinimumWidth = 40
        Me.VP.Name = "VP"
        Me.VP.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.VP.Width = 40
        '
        'tbBilling
        '
        Me.tbBilling.Controls.Add(Me.txtbillingshopsupplies)
        Me.tbBilling.Controls.Add(Me.Label41)
        Me.tbBilling.Controls.Add(Me.txtsublettotal)
        Me.tbBilling.Controls.Add(Me.Label40)
        Me.tbBilling.Controls.Add(Me.txtpartstotal)
        Me.tbBilling.Controls.Add(Me.Label39)
        Me.tbBilling.Controls.Add(Me.txtlabourtotal)
        Me.tbBilling.Controls.Add(Me.label993)
        Me.tbBilling.Controls.Add(Me.Label33)
        Me.tbBilling.Controls.Add(Me.DVpayments)
        Me.tbBilling.Controls.Add(Me.Label22)
        Me.tbBilling.Controls.Add(Me.txtbill)
        Me.tbBilling.Location = New System.Drawing.Point(4, 22)
        Me.tbBilling.Name = "tbBilling"
        Me.tbBilling.Padding = New System.Windows.Forms.Padding(3)
        Me.tbBilling.Size = New System.Drawing.Size(689, 400)
        Me.tbBilling.TabIndex = 7
        Me.tbBilling.Text = "Billing"
        Me.tbBilling.UseVisualStyleBackColor = True
        '
        'txtbillingshopsupplies
        '
        Me.txtbillingshopsupplies.Enabled = False
        Me.txtbillingshopsupplies.Location = New System.Drawing.Point(149, 239)
        Me.txtbillingshopsupplies.Name = "txtbillingshopsupplies"
        Me.txtbillingshopsupplies.Size = New System.Drawing.Size(71, 20)
        Me.txtbillingshopsupplies.TabIndex = 86
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(52, 187)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(90, 18)
        Me.Label41.TabIndex = 93
        Me.Label41.Text = "Sublet Total:"
        '
        'txtsublettotal
        '
        Me.txtsublettotal.Enabled = False
        Me.txtsublettotal.Location = New System.Drawing.Point(150, 185)
        Me.txtsublettotal.Name = "txtsublettotal"
        Me.txtsublettotal.Size = New System.Drawing.Size(71, 20)
        Me.txtsublettotal.TabIndex = 92
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(60, 161)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(84, 18)
        Me.Label40.TabIndex = 91
        Me.Label40.Text = "Parts Total:"
        '
        'txtpartstotal
        '
        Me.txtpartstotal.Enabled = False
        Me.txtpartstotal.Location = New System.Drawing.Point(150, 159)
        Me.txtpartstotal.Name = "txtpartstotal"
        Me.txtpartstotal.Size = New System.Drawing.Size(71, 20)
        Me.txtpartstotal.TabIndex = 90
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(47, 213)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(95, 18)
        Me.Label39.TabIndex = 89
        Me.Label39.Text = "Labour Total:"
        '
        'txtlabourtotal
        '
        Me.txtlabourtotal.Enabled = False
        Me.txtlabourtotal.Location = New System.Drawing.Point(150, 211)
        Me.txtlabourtotal.Name = "txtlabourtotal"
        Me.txtlabourtotal.Size = New System.Drawing.Size(71, 20)
        Me.txtlabourtotal.TabIndex = 88
        '
        'label993
        '
        Me.label993.AutoSize = True
        Me.label993.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label993.Location = New System.Drawing.Point(35, 241)
        Me.label993.Name = "label993"
        Me.label993.Size = New System.Drawing.Size(107, 18)
        Me.label993.TabIndex = 87
        Me.label993.Text = "Shop Supplies:"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(253, 39)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(172, 24)
        Me.Label33.TabIndex = 68
        Me.Label33.Text = "Payment Collected:"
        Me.Label33.Visible = False
        '
        'DVpayments
        '
        Me.DVpayments.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DVpayments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DVpayments.Location = New System.Drawing.Point(257, 70)
        Me.DVpayments.Name = "DVpayments"
        Me.DVpayments.Size = New System.Drawing.Size(414, 241)
        Me.DVpayments.TabIndex = 67
        Me.DVpayments.Visible = False
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(60, 281)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(79, 18)
        Me.Label22.TabIndex = 85
        Me.Label22.Text = "Total Bill:"
        '
        'txtbill
        '
        Me.txtbill.Enabled = False
        Me.txtbill.Location = New System.Drawing.Point(150, 279)
        Me.txtbill.Name = "txtbill"
        Me.txtbill.Size = New System.Drawing.Size(71, 20)
        Me.txtbill.TabIndex = 84
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'FrmIssue
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(965, 600)
        Me.ControlBox = False
        Me.Controls.Add(Me.SplitContainer1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmIssue"
        Me.Text = "Issue Report"
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.PerformLayout()
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.pnlWarrantyHours.ResumeLayout(False)
        Me.pnlWarrantyHours.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.tbQuote.ResumeLayout(False)
        Me.quotepanel.ResumeLayout(False)
        Me.quotepanel.PerformLayout()
        Me.tbWarranty.ResumeLayout(False)
        Me.tbWarranty.PerformLayout()
        Me.tbService.ResumeLayout(False)
        Me.tbService.PerformLayout()
        CType(Me.DVServicePkg, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tbWork.ResumeLayout(False)
        Me.tbWork.PerformLayout()
        CType(Me.DVWorkDone, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tbParts.ResumeLayout(False)
        Me.tbParts.PerformLayout()
        CType(Me.DVParts, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tbSublet.ResumeLayout(False)
        Me.tbSublet.PerformLayout()
        Me.pnlWarantySublet.ResumeLayout(False)
        Me.pnlWarantySublet.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.tbPics.ResumeLayout(False)
        Me.tbPics.PerformLayout()
        CType(Me.DVPictures, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tbBilling.ResumeLayout(False)
        Me.tbBilling.PerformLayout()
        CType(Me.DVpayments, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents txtDesc As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents cmbStatus As System.Windows.Forms.ComboBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents CmbApprovalStatus As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Cmbpaymenttype As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents CmbTypeOfWork As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tbWork As System.Windows.Forms.TabPage
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents tbQuote As System.Windows.Forms.TabPage
    Friend WithEvents tbParts As System.Windows.Forms.TabPage
    Friend WithEvents tbSublet As System.Windows.Forms.TabPage
    Friend WithEvents tbPics As System.Windows.Forms.TabPage
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtAssignedTo As System.Windows.Forms.TextBox
    Friend WithEvents btnAssign As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtQuoteRate As System.Windows.Forms.TextBox
    Friend WithEvents btnLogCall As System.Windows.Forms.Button
    Friend WithEvents DVWorkDone As System.Windows.Forms.DataGridView
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents btnaddpart As System.Windows.Forms.Button
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents DVParts As System.Windows.Forms.DataGridView
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txtsubletbilled As System.Windows.Forms.TextBox
    Friend WithEvents txtsubletmarkup As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents txtsubletcost As System.Windows.Forms.TextBox
    Friend WithEvents btncompleted As System.Windows.Forms.Button
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txtbill As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtbilledhrs As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtbillablehrs As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents tbWarranty As System.Windows.Forms.TabPage
    Friend WithEvents tbService As System.Windows.Forms.TabPage
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents txtwarrantynotes As System.Windows.Forms.TextBox
    Friend WithEvents BtnWarrantyDeclined As System.Windows.Forms.Button
    Friend WithEvents BtnWarrantyApproved As System.Windows.Forms.Button
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents DVServicePkg As System.Windows.Forms.DataGridView
    Friend WithEvents txtservicepackageprice As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents txtservicepackage As System.Windows.Forms.TextBox
    Friend WithEvents btnUploadNewPics As System.Windows.Forms.Button
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents DVPictures As System.Windows.Forms.DataGridView
    Friend WithEvents tbBilling As System.Windows.Forms.TabPage
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents DVpayments As System.Windows.Forms.DataGridView
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents txtstdservicesupplies As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents txtsrdservicetotal As System.Windows.Forms.TextBox
    Friend WithEvents label993 As System.Windows.Forms.Label
    Friend WithEvents txtbillingshopsupplies As System.Windows.Forms.TextBox
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents txtsublettotal As System.Windows.Forms.TextBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents txtpartstotal As System.Windows.Forms.TextBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents txtlabourtotal As System.Windows.Forms.TextBox
    Friend WithEvents txtpartsclone As System.Windows.Forms.TextBox
    Friend WithEvents quotepanel As System.Windows.Forms.Panel
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents txtshopsupplies As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents BtnquoteDeclined As System.Windows.Forms.Button
    Friend WithEvents btnquoteapproved As System.Windows.Forms.Button
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtQuoteTotal As System.Windows.Forms.TextBox
    Friend WithEvents txtQuoteSublet As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtQuoteParts As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtQuoteLabour As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtQuoteHours As System.Windows.Forms.TextBox
    Friend WithEvents labelMessage As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents BtnSubmitted As System.Windows.Forms.Button
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents txtworkdone As System.Windows.Forms.TextBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents txtstdServiceParts As System.Windows.Forms.TextBox
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Col1 As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents View As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents CmbPkgType As System.Windows.Forms.ComboBox
    Friend WithEvents CopyActualtoBilled As System.Windows.Forms.Button
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents CmbBillCustomer As System.Windows.Forms.ComboBox
    Friend WithEvents Btnreactivate As System.Windows.Forms.Button
    Friend WithEvents btnOrderPart As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents Edit As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents RP As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents VP As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents txtRequestedHrs As System.Windows.Forms.TextBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents txtRequestedAmt As System.Windows.Forms.TextBox
    Friend WithEvents cboWarrantyType As System.Windows.Forms.ComboBox
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents pnlWarrantyHours As System.Windows.Forms.Panel
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents txtWSubletName As System.Windows.Forms.TextBox
    Friend WithEvents pnlWarantySublet As System.Windows.Forms.Panel
    Friend WithEvents txtWSubletAppr As System.Windows.Forms.TextBox
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents txtWSubletEst As System.Windows.Forms.TextBox
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents txtWSubletInv As System.Windows.Forms.TextBox
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents txtApprovedAmt As System.Windows.Forms.TextBox
    Friend WithEvents txtApprovedHrs As System.Windows.Forms.TextBox
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents txtCreditNum As System.Windows.Forms.TextBox
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents txtClaimNum As System.Windows.Forms.TextBox
    Friend WithEvents txtQuoteDetailing As System.Windows.Forms.TextBox
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents txtQuoteShipping As System.Windows.Forms.TextBox
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents btnPrintQuote As System.Windows.Forms.Button
    Friend WithEvents btnFillFromParts As System.Windows.Forms.Button
    Friend WithEvents lblQuantity As System.Windows.Forms.Label
    Friend WithEvents cboQuantity As System.Windows.Forms.ComboBox
End Class
