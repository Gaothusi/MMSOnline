<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmeditinv
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.btnviewdeal = New System.Windows.Forms.Button
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label48 = New System.Windows.Forms.Label
        Me.txtboatunit = New System.Windows.Forms.TextBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.txttplateyear = New System.Windows.Forms.TextBox
        Me.txttplateserial = New System.Windows.Forms.TextBox
        Me.txttplatemodel = New System.Windows.Forms.TextBox
        Me.txttplatemake = New System.Windows.Forms.TextBox
        Me.txtdriveyear = New System.Windows.Forms.TextBox
        Me.txtdriveserial = New System.Windows.Forms.TextBox
        Me.txtdrivemodel = New System.Windows.Forms.TextBox
        Me.txtdrivemake = New System.Windows.Forms.TextBox
        Me.txttraileryear = New System.Windows.Forms.TextBox
        Me.txttrailerserial = New System.Windows.Forms.TextBox
        Me.txttrailermodel = New System.Windows.Forms.TextBox
        Me.txttrailermake = New System.Windows.Forms.TextBox
        Me.txtmotoryear = New System.Windows.Forms.TextBox
        Me.txtmotorserial = New System.Windows.Forms.TextBox
        Me.txtmotormodel = New System.Windows.Forms.TextBox
        Me.txtmotormake = New System.Windows.Forms.TextBox
        Me.txtboatyear = New System.Windows.Forms.TextBox
        Me.txtboathin = New System.Windows.Forms.TextBox
        Me.txtboatmodel = New System.Windows.Forms.TextBox
        Me.txtboatmake = New System.Windows.Forms.TextBox
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.cmbStatus = New System.Windows.Forms.ComboBox
        Me.Label46 = New System.Windows.Forms.Label
        Me.txtDiscount = New System.Windows.Forms.TextBox
        Me.txtPrice = New System.Windows.Forms.TextBox
        Me.txttrailer_color = New System.Windows.Forms.TextBox
        Me.txtequipment = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.txtcomments = New System.Windows.Forms.TextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.datearrival = New System.Windows.Forms.DateTimePicker
        Me.Label11 = New System.Windows.Forms.Label
        Me.listequip = New System.Windows.Forms.ListBox
        Me.chknothere = New System.Windows.Forms.CheckBox
        Me.chkhere = New System.Windows.Forms.CheckBox
        Me.cmbLocation = New System.Windows.Forms.ComboBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.txtboat_color = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtdiscount_reason = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.datematurity = New System.Windows.Forms.DateTimePicker
        Me.datefreeinterest = New System.Windows.Forms.DateTimePicker
        Me.chkMaturitydate = New System.Windows.Forms.CheckBox
        Me.chkfree_interest = New System.Windows.Forms.CheckBox
        Me.Label45 = New System.Windows.Forms.Label
        Me.txtnotes = New System.Windows.Forms.TextBox
        Me.txtLoadNumber = New System.Windows.Forms.TextBox
        Me.txtGEowing = New System.Windows.Forms.TextBox
        Me.txtGE_paid = New System.Windows.Forms.TextBox
        Me.txtGE_AMT_financed = New System.Windows.Forms.TextBox
        Me.txtremaining_CDN_Cost = New System.Windows.Forms.TextBox
        Me.TxtInv_Moved_to_COGS = New System.Windows.Forms.TextBox
        Me.txtCDNcost = New System.Windows.Forms.TextBox
        Me.txtEST_CDN_Cost = New System.Windows.Forms.TextBox
        Me.TXTGE_X_Rate = New System.Windows.Forms.TextBox
        Me.txttotal_us_cost = New System.Windows.Forms.TextBox
        Me.txtfrt_us_cost = New System.Windows.Forms.TextBox
        Me.txttrl_us_cost = New System.Windows.Forms.TextBox
        Me.txtInvoicenumber = New System.Windows.Forms.TextBox
        Me.txtboat_us_cost = New System.Windows.Forms.TextBox
        Me.txtPLA = New System.Windows.Forms.TextBox
        Me.txtRebate = New System.Windows.Forms.TextBox
        Me.Label44 = New System.Windows.Forms.Label
        Me.Label36 = New System.Windows.Forms.Label
        Me.Label37 = New System.Windows.Forms.Label
        Me.Label38 = New System.Windows.Forms.Label
        Me.Label39 = New System.Windows.Forms.Label
        Me.Label40 = New System.Windows.Forms.Label
        Me.Label41 = New System.Windows.Forms.Label
        Me.Label42 = New System.Windows.Forms.Label
        Me.Label43 = New System.Windows.Forms.Label
        Me.cmbFinancedCompany = New System.Windows.Forms.ComboBox
        Me.dateInvoice = New System.Windows.Forms.DateTimePicker
        Me.dateGEpaid = New System.Windows.Forms.DateTimePicker
        Me.Label31 = New System.Windows.Forms.Label
        Me.Label30 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.Label28 = New System.Windows.Forms.Label
        Me.Label27 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.TabPage4 = New System.Windows.Forms.TabPage
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.chkmotorreg = New System.Windows.Forms.CheckBox
        Me.chkboatreg = New System.Windows.Forms.CheckBox
        Me.dateboatreg = New System.Windows.Forms.DateTimePicker
        Me.datemotorreg = New System.Windows.Forms.DateTimePicker
        Me.Label34 = New System.Windows.Forms.Label
        Me.Label35 = New System.Windows.Forms.Label
        Me.Label33 = New System.Windows.Forms.Label
        Me.Label32 = New System.Windows.Forms.Label
        Me.cmdselect = New System.Windows.Forms.Button
        Me.txtControl_number = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.cmdReset = New System.Windows.Forms.Button
        Me.CmdClose = New System.Windows.Forms.Button
        Me.Cmdsave = New System.Windows.Forms.Button
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel2
        Me.SplitContainer1.IsSplitterFixed = True
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.TabControl1)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdselect)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtControl_number)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Label1)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cmdReset)
        Me.SplitContainer1.Panel2.Controls.Add(Me.CmdClose)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Cmdsave)
        Me.SplitContainer1.Size = New System.Drawing.Size(627, 358)
        Me.SplitContainer1.SplitterDistance = 324
        Me.SplitContainer1.TabIndex = 0
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(627, 324)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Panel1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(619, 295)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Serials"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnviewdeal)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label48)
        Me.Panel1.Controls.Add(Me.txtboatunit)
        Me.Panel1.Controls.Add(Me.Label19)
        Me.Panel1.Controls.Add(Me.Label18)
        Me.Panel1.Controls.Add(Me.Label17)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.txttplateyear)
        Me.Panel1.Controls.Add(Me.txttplateserial)
        Me.Panel1.Controls.Add(Me.txttplatemodel)
        Me.Panel1.Controls.Add(Me.txttplatemake)
        Me.Panel1.Controls.Add(Me.txtdriveyear)
        Me.Panel1.Controls.Add(Me.txtdriveserial)
        Me.Panel1.Controls.Add(Me.txtdrivemodel)
        Me.Panel1.Controls.Add(Me.txtdrivemake)
        Me.Panel1.Controls.Add(Me.txttraileryear)
        Me.Panel1.Controls.Add(Me.txttrailerserial)
        Me.Panel1.Controls.Add(Me.txttrailermodel)
        Me.Panel1.Controls.Add(Me.txttrailermake)
        Me.Panel1.Controls.Add(Me.txtmotoryear)
        Me.Panel1.Controls.Add(Me.txtmotorserial)
        Me.Panel1.Controls.Add(Me.txtmotormodel)
        Me.Panel1.Controls.Add(Me.txtmotormake)
        Me.Panel1.Controls.Add(Me.txtboatyear)
        Me.Panel1.Controls.Add(Me.txtboathin)
        Me.Panel1.Controls.Add(Me.txtboatmodel)
        Me.Panel1.Controls.Add(Me.txtboatmake)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(613, 289)
        Me.Panel1.TabIndex = 0
        '
        'btnviewdeal
        '
        Me.btnviewdeal.Location = New System.Drawing.Point(483, 242)
        Me.btnviewdeal.Name = "btnviewdeal"
        Me.btnviewdeal.Size = New System.Drawing.Size(121, 26)
        Me.btnviewdeal.TabIndex = 6
        Me.btnviewdeal.Text = "View Deal"
        Me.btnviewdeal.UseVisualStyleBackColor = True
        Me.btnviewdeal.Visible = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(33, 154)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(59, 18)
        Me.Label6.TabIndex = 197
        Me.Label6.Text = "T-Plate:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(46, 126)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(46, 18)
        Me.Label2.TabIndex = 196
        Me.Label2.Text = "Drive:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(39, 98)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 18)
        Me.Label3.TabIndex = 195
        Me.Label3.Text = "Trailer:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(40, 70)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 18)
        Me.Label4.TabIndex = 194
        Me.Label4.Text = "Motor:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(49, 42)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(43, 18)
        Me.Label5.TabIndex = 193
        Me.Label5.Text = "Boat:"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.Location = New System.Drawing.Point(526, 18)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(42, 18)
        Me.Label48.TabIndex = 192
        Me.Label48.Text = "Year:"
        '
        'txtboatunit
        '
        Me.txtboatunit.Location = New System.Drawing.Point(98, 190)
        Me.txtboatunit.Name = "txtboatunit"
        Me.txtboatunit.Size = New System.Drawing.Size(81, 24)
        Me.txtboatunit.TabIndex = 191
        Me.txtboatunit.TabStop = False
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(46, 196)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(50, 18)
        Me.Label19.TabIndex = 189
        Me.Label19.Text = "Unit #:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(349, 18)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(106, 18)
        Me.Label18.TabIndex = 188
        Me.Label18.Text = "Serial Number:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(212, 18)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(53, 18)
        Me.Label17.TabIndex = 187
        Me.Label17.Text = "Model:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(95, 18)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(49, 18)
        Me.Label16.TabIndex = 186
        Me.Label16.Text = "Make:"
        '
        'txttplateyear
        '
        Me.txttplateyear.Enabled = False
        Me.txttplateyear.Location = New System.Drawing.Point(529, 151)
        Me.txttplateyear.Name = "txttplateyear"
        Me.txttplateyear.ReadOnly = True
        Me.txttplateyear.Size = New System.Drawing.Size(59, 24)
        Me.txttplateyear.TabIndex = 184
        Me.txttplateyear.TabStop = False
        Me.txttplateyear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txttplateserial
        '
        Me.txttplateserial.Location = New System.Drawing.Point(352, 151)
        Me.txttplateserial.Name = "txttplateserial"
        Me.txttplateserial.Size = New System.Drawing.Size(171, 24)
        Me.txttplateserial.TabIndex = 14
        Me.txttplateserial.TabStop = False
        '
        'txttplatemodel
        '
        Me.txttplatemodel.Enabled = False
        Me.txttplatemodel.Location = New System.Drawing.Point(215, 151)
        Me.txttplatemodel.Name = "txttplatemodel"
        Me.txttplatemodel.ReadOnly = True
        Me.txttplatemodel.Size = New System.Drawing.Size(131, 24)
        Me.txttplatemodel.TabIndex = 182
        Me.txttplatemodel.TabStop = False
        '
        'txttplatemake
        '
        Me.txttplatemake.Enabled = False
        Me.txttplatemake.Location = New System.Drawing.Point(98, 151)
        Me.txttplatemake.Name = "txttplatemake"
        Me.txttplatemake.ReadOnly = True
        Me.txttplatemake.Size = New System.Drawing.Size(111, 24)
        Me.txttplatemake.TabIndex = 181
        Me.txttplatemake.TabStop = False
        '
        'txtdriveyear
        '
        Me.txtdriveyear.Enabled = False
        Me.txtdriveyear.Location = New System.Drawing.Point(529, 123)
        Me.txtdriveyear.Name = "txtdriveyear"
        Me.txtdriveyear.ReadOnly = True
        Me.txtdriveyear.Size = New System.Drawing.Size(59, 24)
        Me.txtdriveyear.TabIndex = 179
        Me.txtdriveyear.TabStop = False
        Me.txtdriveyear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtdriveserial
        '
        Me.txtdriveserial.Location = New System.Drawing.Point(352, 123)
        Me.txtdriveserial.Name = "txtdriveserial"
        Me.txtdriveserial.Size = New System.Drawing.Size(171, 24)
        Me.txtdriveserial.TabIndex = 13
        Me.txtdriveserial.TabStop = False
        '
        'txtdrivemodel
        '
        Me.txtdrivemodel.Location = New System.Drawing.Point(215, 123)
        Me.txtdrivemodel.Name = "txtdrivemodel"
        Me.txtdrivemodel.Size = New System.Drawing.Size(131, 24)
        Me.txtdrivemodel.TabIndex = 12
        Me.txtdrivemodel.TabStop = False
        '
        'txtdrivemake
        '
        Me.txtdrivemake.Enabled = False
        Me.txtdrivemake.Location = New System.Drawing.Point(98, 123)
        Me.txtdrivemake.Name = "txtdrivemake"
        Me.txtdrivemake.ReadOnly = True
        Me.txtdrivemake.Size = New System.Drawing.Size(111, 24)
        Me.txtdrivemake.TabIndex = 176
        Me.txtdrivemake.TabStop = False
        '
        'txttraileryear
        '
        Me.txttraileryear.Location = New System.Drawing.Point(529, 95)
        Me.txttraileryear.Name = "txttraileryear"
        Me.txttraileryear.Size = New System.Drawing.Size(59, 24)
        Me.txttraileryear.TabIndex = 11
        Me.txttraileryear.TabStop = False
        Me.txttraileryear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txttrailerserial
        '
        Me.txttrailerserial.Location = New System.Drawing.Point(352, 95)
        Me.txttrailerserial.Name = "txttrailerserial"
        Me.txttrailerserial.Size = New System.Drawing.Size(171, 24)
        Me.txttrailerserial.TabIndex = 10
        Me.txttrailerserial.TabStop = False
        '
        'txttrailermodel
        '
        Me.txttrailermodel.Location = New System.Drawing.Point(215, 95)
        Me.txttrailermodel.Name = "txttrailermodel"
        Me.txttrailermodel.Size = New System.Drawing.Size(131, 24)
        Me.txttrailermodel.TabIndex = 9
        Me.txttrailermodel.TabStop = False
        '
        'txttrailermake
        '
        Me.txttrailermake.Location = New System.Drawing.Point(98, 95)
        Me.txttrailermake.Name = "txttrailermake"
        Me.txttrailermake.Size = New System.Drawing.Size(111, 24)
        Me.txttrailermake.TabIndex = 8
        Me.txttrailermake.TabStop = False
        '
        'txtmotoryear
        '
        Me.txtmotoryear.Location = New System.Drawing.Point(529, 67)
        Me.txtmotoryear.Name = "txtmotoryear"
        Me.txtmotoryear.Size = New System.Drawing.Size(59, 24)
        Me.txtmotoryear.TabIndex = 7
        Me.txtmotoryear.TabStop = False
        Me.txtmotoryear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtmotorserial
        '
        Me.txtmotorserial.Location = New System.Drawing.Point(352, 67)
        Me.txtmotorserial.Name = "txtmotorserial"
        Me.txtmotorserial.Size = New System.Drawing.Size(171, 24)
        Me.txtmotorserial.TabIndex = 6
        Me.txtmotorserial.TabStop = False
        '
        'txtmotormodel
        '
        Me.txtmotormodel.Location = New System.Drawing.Point(215, 67)
        Me.txtmotormodel.Name = "txtmotormodel"
        Me.txtmotormodel.Size = New System.Drawing.Size(131, 24)
        Me.txtmotormodel.TabIndex = 5
        Me.txtmotormodel.TabStop = False
        '
        'txtmotormake
        '
        Me.txtmotormake.Location = New System.Drawing.Point(98, 67)
        Me.txtmotormake.Name = "txtmotormake"
        Me.txtmotormake.Size = New System.Drawing.Size(111, 24)
        Me.txtmotormake.TabIndex = 4
        Me.txtmotormake.TabStop = False
        '
        'txtboatyear
        '
        Me.txtboatyear.Location = New System.Drawing.Point(529, 39)
        Me.txtboatyear.Name = "txtboatyear"
        Me.txtboatyear.Size = New System.Drawing.Size(59, 24)
        Me.txtboatyear.TabIndex = 3
        Me.txtboatyear.TabStop = False
        Me.txtboatyear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtboathin
        '
        Me.txtboathin.Location = New System.Drawing.Point(352, 39)
        Me.txtboathin.Name = "txtboathin"
        Me.txtboathin.Size = New System.Drawing.Size(171, 24)
        Me.txtboathin.TabIndex = 2
        Me.txtboathin.TabStop = False
        '
        'txtboatmodel
        '
        Me.txtboatmodel.Location = New System.Drawing.Point(215, 39)
        Me.txtboatmodel.Name = "txtboatmodel"
        Me.txtboatmodel.Size = New System.Drawing.Size(131, 24)
        Me.txtboatmodel.TabIndex = 1
        Me.txtboatmodel.TabStop = False
        '
        'txtboatmake
        '
        Me.txtboatmake.Location = New System.Drawing.Point(98, 39)
        Me.txtboatmake.Name = "txtboatmake"
        Me.txtboatmake.Size = New System.Drawing.Size(111, 24)
        Me.txtboatmake.TabIndex = 0
        Me.txtboatmake.TabStop = False
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Panel2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(619, 294)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Details"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.cmbStatus)
        Me.Panel2.Controls.Add(Me.Label46)
        Me.Panel2.Controls.Add(Me.txtDiscount)
        Me.Panel2.Controls.Add(Me.txtPrice)
        Me.Panel2.Controls.Add(Me.txttrailer_color)
        Me.Panel2.Controls.Add(Me.txtequipment)
        Me.Panel2.Controls.Add(Me.Label15)
        Me.Panel2.Controls.Add(Me.txtcomments)
        Me.Panel2.Controls.Add(Me.Label14)
        Me.Panel2.Controls.Add(Me.Label13)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.datearrival)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.listequip)
        Me.Panel2.Controls.Add(Me.chknothere)
        Me.Panel2.Controls.Add(Me.chkhere)
        Me.Panel2.Controls.Add(Me.cmbLocation)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.txtboat_color)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.txtdiscount_reason)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 3)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(613, 288)
        Me.Panel2.TabIndex = 0
        '
        'cmbStatus
        '
        Me.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStatus.Enabled = False
        Me.cmbStatus.FormattingEnabled = True
        Me.cmbStatus.Location = New System.Drawing.Point(182, 14)
        Me.cmbStatus.Name = "cmbStatus"
        Me.cmbStatus.Size = New System.Drawing.Size(121, 21)
        Me.cmbStatus.TabIndex = 0
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(110, 13)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(54, 18)
        Me.Label46.TabIndex = 232
        Me.Label46.Text = "Status:"
        '
        'txtDiscount
        '
        Me.txtDiscount.Location = New System.Drawing.Point(182, 170)
        Me.txtDiscount.Name = "txtDiscount"
        Me.txtDiscount.Size = New System.Drawing.Size(123, 20)
        Me.txtDiscount.TabIndex = 6
        Me.txtDiscount.TabStop = False
        '
        'txtPrice
        '
        Me.txtPrice.Location = New System.Drawing.Point(182, 144)
        Me.txtPrice.Name = "txtPrice"
        Me.txtPrice.Size = New System.Drawing.Size(123, 20)
        Me.txtPrice.TabIndex = 5
        Me.txtPrice.TabStop = False
        '
        'txttrailer_color
        '
        Me.txttrailer_color.Location = New System.Drawing.Point(481, 229)
        Me.txttrailer_color.Name = "txttrailer_color"
        Me.txttrailer_color.Size = New System.Drawing.Size(123, 20)
        Me.txttrailer_color.TabIndex = 11
        Me.txttrailer_color.TabStop = False
        '
        'txtequipment
        '
        Me.txtequipment.Location = New System.Drawing.Point(332, 27)
        Me.txtequipment.Name = "txtequipment"
        Me.txtequipment.Size = New System.Drawing.Size(272, 20)
        Me.txtequipment.TabIndex = 8
        Me.txtequipment.TabStop = False
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(13, 223)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(86, 18)
        Me.Label15.TabIndex = 227
        Me.Label15.Text = "Comments:"
        '
        'txtcomments
        '
        Me.txtcomments.Location = New System.Drawing.Point(104, 224)
        Me.txtcomments.Multiline = True
        Me.txtcomments.Name = "txtcomments"
        Me.txtcomments.Size = New System.Drawing.Size(201, 34)
        Me.txtcomments.TabIndex = 5
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(35, 197)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(64, 18)
        Me.Label14.TabIndex = 224
        Me.Label14.Text = "Reason:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(112, 170)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(71, 18)
        Me.Label13.TabIndex = 222
        Me.Label13.Text = "Discount:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(132, 143)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(46, 18)
        Me.Label12.TabIndex = 220
        Me.Label12.Text = "Price:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(28, 66)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(152, 18)
        Me.Label10.TabIndex = 219
        Me.Label10.Text = "Expected Arrival Date:"
        '
        'datearrival
        '
        Me.datearrival.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.datearrival.Location = New System.Drawing.Point(186, 68)
        Me.datearrival.Name = "datearrival"
        Me.datearrival.Size = New System.Drawing.Size(119, 20)
        Me.datearrival.TabIndex = 2
        Me.datearrival.Value = New Date(2006, 10, 6, 0, 0, 0, 0)
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(329, 6)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(82, 18)
        Me.Label11.TabIndex = 216
        Me.Label11.Text = "Equipment:"
        '
        'listequip
        '
        Me.listequip.Enabled = False
        Me.listequip.FormattingEnabled = True
        Me.listequip.Location = New System.Drawing.Point(332, 58)
        Me.listequip.Name = "listequip"
        Me.listequip.Size = New System.Drawing.Size(272, 134)
        Me.listequip.TabIndex = 9
        '
        'chknothere
        '
        Me.chknothere.AutoSize = True
        Me.chknothere.Location = New System.Drawing.Point(184, 117)
        Me.chknothere.Name = "chknothere"
        Me.chknothere.Size = New System.Drawing.Size(138, 17)
        Me.chknothere.TabIndex = 4
        Me.chknothere.Text = "The boat is still on order"
        Me.chknothere.UseVisualStyleBackColor = True
        '
        'chkhere
        '
        Me.chkhere.AutoSize = True
        Me.chkhere.Location = New System.Drawing.Point(184, 94)
        Me.chkhere.Name = "chkhere"
        Me.chkhere.Size = New System.Drawing.Size(124, 17)
        Me.chkhere.TabIndex = 3
        Me.chkhere.Text = "The boat has arrived"
        Me.chkhere.UseVisualStyleBackColor = True
        '
        'cmbLocation
        '
        Me.cmbLocation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbLocation.FormattingEnabled = True
        Me.cmbLocation.Location = New System.Drawing.Point(184, 41)
        Me.cmbLocation.Name = "cmbLocation"
        Me.cmbLocation.Size = New System.Drawing.Size(121, 21)
        Me.cmbLocation.TabIndex = 1
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(112, 40)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(69, 18)
        Me.Label9.TabIndex = 210
        Me.Label9.Text = "Location:"
        '
        'txtboat_color
        '
        Me.txtboat_color.Location = New System.Drawing.Point(481, 201)
        Me.txtboat_color.Name = "txtboat_color"
        Me.txtboat_color.Size = New System.Drawing.Size(123, 20)
        Me.txtboat_color.TabIndex = 10
        Me.txtboat_color.TabStop = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(381, 231)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(94, 18)
        Me.Label8.TabIndex = 208
        Me.Label8.Text = "Trailer Color:"
        '
        'txtdiscount_reason
        '
        Me.txtdiscount_reason.Location = New System.Drawing.Point(105, 198)
        Me.txtdiscount_reason.Name = "txtdiscount_reason"
        Me.txtdiscount_reason.Size = New System.Drawing.Size(200, 20)
        Me.txtdiscount_reason.TabIndex = 7
        Me.txtdiscount_reason.TabStop = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(391, 201)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(84, 18)
        Me.Label7.TabIndex = 206
        Me.Label7.Text = "Boat Color:"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.Panel3)
        Me.TabPage3.Location = New System.Drawing.Point(4, 25)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(619, 294)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Accounting"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.datematurity)
        Me.Panel3.Controls.Add(Me.datefreeinterest)
        Me.Panel3.Controls.Add(Me.chkMaturitydate)
        Me.Panel3.Controls.Add(Me.chkfree_interest)
        Me.Panel3.Controls.Add(Me.Label45)
        Me.Panel3.Controls.Add(Me.txtnotes)
        Me.Panel3.Controls.Add(Me.txtLoadNumber)
        Me.Panel3.Controls.Add(Me.txtGEowing)
        Me.Panel3.Controls.Add(Me.txtGE_paid)
        Me.Panel3.Controls.Add(Me.txtGE_AMT_financed)
        Me.Panel3.Controls.Add(Me.txtremaining_CDN_Cost)
        Me.Panel3.Controls.Add(Me.TxtInv_Moved_to_COGS)
        Me.Panel3.Controls.Add(Me.txtCDNcost)
        Me.Panel3.Controls.Add(Me.txtEST_CDN_Cost)
        Me.Panel3.Controls.Add(Me.TXTGE_X_Rate)
        Me.Panel3.Controls.Add(Me.txttotal_us_cost)
        Me.Panel3.Controls.Add(Me.txtfrt_us_cost)
        Me.Panel3.Controls.Add(Me.txttrl_us_cost)
        Me.Panel3.Controls.Add(Me.txtInvoicenumber)
        Me.Panel3.Controls.Add(Me.txtboat_us_cost)
        Me.Panel3.Controls.Add(Me.txtPLA)
        Me.Panel3.Controls.Add(Me.txtRebate)
        Me.Panel3.Controls.Add(Me.Label44)
        Me.Panel3.Controls.Add(Me.Label36)
        Me.Panel3.Controls.Add(Me.Label37)
        Me.Panel3.Controls.Add(Me.Label38)
        Me.Panel3.Controls.Add(Me.Label39)
        Me.Panel3.Controls.Add(Me.Label40)
        Me.Panel3.Controls.Add(Me.Label41)
        Me.Panel3.Controls.Add(Me.Label42)
        Me.Panel3.Controls.Add(Me.Label43)
        Me.Panel3.Controls.Add(Me.cmbFinancedCompany)
        Me.Panel3.Controls.Add(Me.dateInvoice)
        Me.Panel3.Controls.Add(Me.dateGEpaid)
        Me.Panel3.Controls.Add(Me.Label31)
        Me.Panel3.Controls.Add(Me.Label30)
        Me.Panel3.Controls.Add(Me.Label29)
        Me.Panel3.Controls.Add(Me.Label28)
        Me.Panel3.Controls.Add(Me.Label27)
        Me.Panel3.Controls.Add(Me.Label26)
        Me.Panel3.Controls.Add(Me.Label25)
        Me.Panel3.Controls.Add(Me.Label24)
        Me.Panel3.Controls.Add(Me.Label23)
        Me.Panel3.Controls.Add(Me.Label22)
        Me.Panel3.Controls.Add(Me.Label21)
        Me.Panel3.Controls.Add(Me.Label20)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(3, 3)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(613, 288)
        Me.Panel3.TabIndex = 0
        '
        'datematurity
        '
        Me.datematurity.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.datematurity.Location = New System.Drawing.Point(503, 118)
        Me.datematurity.Name = "datematurity"
        Me.datematurity.Size = New System.Drawing.Size(95, 20)
        Me.datematurity.TabIndex = 19
        '
        'datefreeinterest
        '
        Me.datefreeinterest.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.datefreeinterest.Location = New System.Drawing.Point(503, 94)
        Me.datefreeinterest.Name = "datefreeinterest"
        Me.datefreeinterest.Size = New System.Drawing.Size(95, 20)
        Me.datefreeinterest.TabIndex = 17
        '
        'chkMaturitydate
        '
        Me.chkMaturitydate.AutoSize = True
        Me.chkMaturitydate.Location = New System.Drawing.Point(480, 122)
        Me.chkMaturitydate.Name = "chkMaturitydate"
        Me.chkMaturitydate.Size = New System.Drawing.Size(15, 14)
        Me.chkMaturitydate.TabIndex = 280
        Me.chkMaturitydate.UseVisualStyleBackColor = True
        '
        'chkfree_interest
        '
        Me.chkfree_interest.AutoSize = True
        Me.chkfree_interest.Location = New System.Drawing.Point(480, 99)
        Me.chkfree_interest.Name = "chkfree_interest"
        Me.chkfree_interest.Size = New System.Drawing.Size(15, 14)
        Me.chkfree_interest.TabIndex = 279
        Me.chkfree_interest.UseVisualStyleBackColor = True
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.Location = New System.Drawing.Point(376, 120)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(99, 18)
        Me.Label45.TabIndex = 18
        Me.Label45.Text = "Maturity Date:"
        '
        'txtnotes
        '
        Me.txtnotes.Location = New System.Drawing.Point(342, 159)
        Me.txtnotes.Multiline = True
        Me.txtnotes.Name = "txtnotes"
        Me.txtnotes.Size = New System.Drawing.Size(256, 41)
        Me.txtnotes.TabIndex = 20
        '
        'txtLoadNumber
        '
        Me.txtLoadNumber.Location = New System.Drawing.Point(503, 4)
        Me.txtLoadNumber.Name = "txtLoadNumber"
        Me.txtLoadNumber.Size = New System.Drawing.Size(95, 20)
        Me.txtLoadNumber.TabIndex = 12
        '
        'txtGEowing
        '
        Me.txtGEowing.Location = New System.Drawing.Point(157, 248)
        Me.txtGEowing.Name = "txtGEowing"
        Me.txtGEowing.ReadOnly = True
        Me.txtGEowing.Size = New System.Drawing.Size(121, 20)
        Me.txtGEowing.TabIndex = 11
        '
        'txtGE_paid
        '
        Me.txtGE_paid.Location = New System.Drawing.Point(157, 226)
        Me.txtGE_paid.Name = "txtGE_paid"
        Me.txtGE_paid.Size = New System.Drawing.Size(121, 20)
        Me.txtGE_paid.TabIndex = 10
        '
        'txtGE_AMT_financed
        '
        Me.txtGE_AMT_financed.Location = New System.Drawing.Point(157, 204)
        Me.txtGE_AMT_financed.Name = "txtGE_AMT_financed"
        Me.txtGE_AMT_financed.Size = New System.Drawing.Size(121, 20)
        Me.txtGE_AMT_financed.TabIndex = 9
        '
        'txtremaining_CDN_Cost
        '
        Me.txtremaining_CDN_Cost.Location = New System.Drawing.Point(157, 182)
        Me.txtremaining_CDN_Cost.Name = "txtremaining_CDN_Cost"
        Me.txtremaining_CDN_Cost.ReadOnly = True
        Me.txtremaining_CDN_Cost.Size = New System.Drawing.Size(121, 20)
        Me.txtremaining_CDN_Cost.TabIndex = 8
        '
        'TxtInv_Moved_to_COGS
        '
        Me.TxtInv_Moved_to_COGS.Location = New System.Drawing.Point(157, 160)
        Me.TxtInv_Moved_to_COGS.Name = "TxtInv_Moved_to_COGS"
        Me.TxtInv_Moved_to_COGS.Size = New System.Drawing.Size(121, 20)
        Me.TxtInv_Moved_to_COGS.TabIndex = 7
        '
        'txtCDNcost
        '
        Me.txtCDNcost.Location = New System.Drawing.Point(157, 138)
        Me.txtCDNcost.Name = "txtCDNcost"
        Me.txtCDNcost.Size = New System.Drawing.Size(121, 20)
        Me.txtCDNcost.TabIndex = 6
        '
        'txtEST_CDN_Cost
        '
        Me.txtEST_CDN_Cost.Location = New System.Drawing.Point(157, 116)
        Me.txtEST_CDN_Cost.Name = "txtEST_CDN_Cost"
        Me.txtEST_CDN_Cost.ReadOnly = True
        Me.txtEST_CDN_Cost.Size = New System.Drawing.Size(121, 20)
        Me.txtEST_CDN_Cost.TabIndex = 5
        '
        'TXTGE_X_Rate
        '
        Me.TXTGE_X_Rate.Location = New System.Drawing.Point(157, 94)
        Me.TXTGE_X_Rate.Name = "TXTGE_X_Rate"
        Me.TXTGE_X_Rate.Size = New System.Drawing.Size(121, 20)
        Me.TXTGE_X_Rate.TabIndex = 4
        '
        'txttotal_us_cost
        '
        Me.txttotal_us_cost.Location = New System.Drawing.Point(157, 71)
        Me.txttotal_us_cost.Name = "txttotal_us_cost"
        Me.txttotal_us_cost.ReadOnly = True
        Me.txttotal_us_cost.Size = New System.Drawing.Size(121, 20)
        Me.txttotal_us_cost.TabIndex = 3
        '
        'txtfrt_us_cost
        '
        Me.txtfrt_us_cost.Location = New System.Drawing.Point(157, 48)
        Me.txtfrt_us_cost.Name = "txtfrt_us_cost"
        Me.txtfrt_us_cost.Size = New System.Drawing.Size(121, 20)
        Me.txtfrt_us_cost.TabIndex = 2
        '
        'txttrl_us_cost
        '
        Me.txttrl_us_cost.Location = New System.Drawing.Point(157, 25)
        Me.txttrl_us_cost.Name = "txttrl_us_cost"
        Me.txttrl_us_cost.Size = New System.Drawing.Size(121, 20)
        Me.txttrl_us_cost.TabIndex = 1
        '
        'txtInvoicenumber
        '
        Me.txtInvoicenumber.Location = New System.Drawing.Point(503, 26)
        Me.txtInvoicenumber.Name = "txtInvoicenumber"
        Me.txtInvoicenumber.Size = New System.Drawing.Size(95, 20)
        Me.txtInvoicenumber.TabIndex = 13
        '
        'txtboat_us_cost
        '
        Me.txtboat_us_cost.Location = New System.Drawing.Point(157, 3)
        Me.txtboat_us_cost.Name = "txtboat_us_cost"
        Me.txtboat_us_cost.Size = New System.Drawing.Size(121, 20)
        Me.txtboat_us_cost.TabIndex = 0
        '
        'txtPLA
        '
        Me.txtPLA.Location = New System.Drawing.Point(503, 225)
        Me.txtPLA.Name = "txtPLA"
        Me.txtPLA.Size = New System.Drawing.Size(95, 20)
        Me.txtPLA.TabIndex = 22
        '
        'txtRebate
        '
        Me.txtRebate.Location = New System.Drawing.Point(503, 203)
        Me.txtRebate.Name = "txtRebate"
        Me.txtRebate.Size = New System.Drawing.Size(95, 20)
        Me.txtRebate.TabIndex = 21
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(395, 249)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(102, 18)
        Me.Label44.TabIndex = 259
        Me.Label44.Text = "GE Paid Date:"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(395, 3)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(102, 18)
        Me.Label36.TabIndex = 258
        Me.Label36.Text = "Load Number:"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(359, 71)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(140, 18)
        Me.Label37.TabIndex = 257
        Me.Label37.Text = "Financed Company:"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(385, 26)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(115, 18)
        Me.Label38.TabIndex = 256
        Me.Label38.Text = "Invoice Number:"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(284, 157)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(52, 18)
        Me.Label39.TabIndex = 255
        Me.Label39.Text = "Notes:"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(376, 98)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(94, 18)
        Me.Label40.TabIndex = 16
        Me.Label40.Text = "Free Interest:"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(406, 48)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(93, 18)
        Me.Label41.TabIndex = 253
        Me.Label41.Text = "Invoice Date:"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(438, 205)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(59, 18)
        Me.Label42.TabIndex = 252
        Me.Label42.Text = "Rebate:"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(397, 228)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(100, 18)
        Me.Label43.TabIndex = 251
        Me.Label43.Text = "PLA or Chq #:"
        '
        'cmbFinancedCompany
        '
        Me.cmbFinancedCompany.FormattingEnabled = True
        Me.cmbFinancedCompany.Location = New System.Drawing.Point(503, 71)
        Me.cmbFinancedCompany.Name = "cmbFinancedCompany"
        Me.cmbFinancedCompany.Size = New System.Drawing.Size(95, 21)
        Me.cmbFinancedCompany.TabIndex = 15
        '
        'dateInvoice
        '
        Me.dateInvoice.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dateInvoice.Location = New System.Drawing.Point(503, 48)
        Me.dateInvoice.Name = "dateInvoice"
        Me.dateInvoice.Size = New System.Drawing.Size(95, 20)
        Me.dateInvoice.TabIndex = 14
        '
        'dateGEpaid
        '
        Me.dateGEpaid.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dateGEpaid.Location = New System.Drawing.Point(503, 247)
        Me.dateGEpaid.Name = "dateGEpaid"
        Me.dateGEpaid.Size = New System.Drawing.Size(95, 20)
        Me.dateGEpaid.TabIndex = 23
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(6, 204)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(153, 18)
        Me.Label31.TabIndex = 244
        Me.Label31.Text = "GE Amount Financed:"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(55, 3)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(104, 18)
        Me.Label30.TabIndex = 242
        Me.Label30.Text = "Boat US Cost:"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(53, 71)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(106, 18)
        Me.Label29.TabIndex = 240
        Me.Label29.Text = "Total US Cost:"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(45, 25)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(114, 18)
        Me.Label28.TabIndex = 238
        Me.Label28.Text = "Trailer US Cost:"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(48, 116)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(111, 18)
        Me.Label27.TabIndex = 236
        Me.Label27.Text = "Est. CDN Cost:"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(92, 227)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(67, 18)
        Me.Label26.TabIndex = 234
        Me.Label26.Text = "GE Paid:"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(29, 94)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(130, 18)
        Me.Label25.TabIndex = 232
        Me.Label25.Text = "GE exchange rate:"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(4, 182)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(155, 18)
        Me.Label24.TabIndex = 230
        Me.Label24.Text = "Remaining CDN Cost:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(41, 48)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(118, 18)
        Me.Label23.TabIndex = 228
        Me.Label23.Text = "Freight US Cost:"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(14, 160)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(145, 18)
        Me.Label22.TabIndex = 226
        Me.Label22.Text = "Inv moved to COGS:"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(78, 138)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(81, 18)
        Me.Label21.TabIndex = 224
        Me.Label21.Text = "CDN Cost:"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(24, 250)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(135, 18)
        Me.Label20.TabIndex = 222
        Me.Label20.Text = "GE Amount Owing:"
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.Panel4)
        Me.TabPage4.Location = New System.Drawing.Point(4, 25)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(619, 294)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Registration"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.chkmotorreg)
        Me.Panel4.Controls.Add(Me.chkboatreg)
        Me.Panel4.Controls.Add(Me.dateboatreg)
        Me.Panel4.Controls.Add(Me.datemotorreg)
        Me.Panel4.Controls.Add(Me.Label34)
        Me.Panel4.Controls.Add(Me.Label35)
        Me.Panel4.Controls.Add(Me.Label33)
        Me.Panel4.Controls.Add(Me.Label32)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel4.Location = New System.Drawing.Point(3, 3)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(613, 288)
        Me.Panel4.TabIndex = 0
        '
        'chkmotorreg
        '
        Me.chkmotorreg.AutoSize = True
        Me.chkmotorreg.Location = New System.Drawing.Point(215, 44)
        Me.chkmotorreg.Name = "chkmotorreg"
        Me.chkmotorreg.Size = New System.Drawing.Size(15, 14)
        Me.chkmotorreg.TabIndex = 225
        Me.chkmotorreg.UseVisualStyleBackColor = True
        '
        'chkboatreg
        '
        Me.chkboatreg.AutoSize = True
        Me.chkboatreg.Location = New System.Drawing.Point(215, 18)
        Me.chkboatreg.Name = "chkboatreg"
        Me.chkboatreg.Size = New System.Drawing.Size(15, 14)
        Me.chkboatreg.TabIndex = 224
        Me.chkboatreg.UseVisualStyleBackColor = True
        '
        'dateboatreg
        '
        Me.dateboatreg.Checked = False
        Me.dateboatreg.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dateboatreg.Location = New System.Drawing.Point(434, 12)
        Me.dateboatreg.Name = "dateboatreg"
        Me.dateboatreg.Size = New System.Drawing.Size(119, 20)
        Me.dateboatreg.TabIndex = 1
        Me.dateboatreg.Value = New Date(2006, 10, 6, 0, 0, 0, 0)
        '
        'datemotorreg
        '
        Me.datemotorreg.Checked = False
        Me.datemotorreg.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.datemotorreg.Location = New System.Drawing.Point(434, 38)
        Me.datemotorreg.Name = "datemotorreg"
        Me.datemotorreg.Size = New System.Drawing.Size(119, 20)
        Me.datemotorreg.TabIndex = 3
        Me.datemotorreg.Value = New Date(2006, 10, 6, 0, 0, 0, 0)
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(98, 14)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(118, 18)
        Me.Label34.TabIndex = 0
        Me.Label34.Text = "Boat Registered:"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(89, 40)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(127, 18)
        Me.Label35.TabIndex = 2
        Me.Label35.Text = "Motor Registered:"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(274, 14)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(161, 18)
        Me.Label33.TabIndex = 223
        Me.Label33.Text = "Boat Registration Date:"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(265, 40)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(170, 18)
        Me.Label32.TabIndex = 221
        Me.Label32.Text = "Motor Registration Date:"
        '
        'cmdselect
        '
        Me.cmdselect.Location = New System.Drawing.Point(467, 1)
        Me.cmdselect.Name = "cmdselect"
        Me.cmdselect.Size = New System.Drawing.Size(75, 23)
        Me.cmdselect.TabIndex = 5
        Me.cmdselect.Text = "Select"
        Me.cmdselect.UseVisualStyleBackColor = True
        Me.cmdselect.Visible = False
        '
        'txtControl_number
        '
        Me.txtControl_number.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtControl_number.Location = New System.Drawing.Point(99, 1)
        Me.txtControl_number.Name = "txtControl_number"
        Me.txtControl_number.ReadOnly = True
        Me.txtControl_number.Size = New System.Drawing.Size(78, 29)
        Me.txtControl_number.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 3)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(90, 24)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Control #:"
        '
        'cmdReset
        '
        Me.cmdReset.Location = New System.Drawing.Point(386, 1)
        Me.cmdReset.Name = "cmdReset"
        Me.cmdReset.Size = New System.Drawing.Size(75, 23)
        Me.cmdReset.TabIndex = 2
        Me.cmdReset.Text = "Reset"
        Me.cmdReset.UseVisualStyleBackColor = True
        '
        'CmdClose
        '
        Me.CmdClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.CmdClose.Location = New System.Drawing.Point(548, 1)
        Me.CmdClose.Name = "CmdClose"
        Me.CmdClose.Size = New System.Drawing.Size(75, 23)
        Me.CmdClose.TabIndex = 0
        Me.CmdClose.Text = "Close"
        Me.CmdClose.UseVisualStyleBackColor = True
        '
        'Cmdsave
        '
        Me.Cmdsave.Enabled = False
        Me.Cmdsave.Location = New System.Drawing.Point(467, 1)
        Me.Cmdsave.Name = "Cmdsave"
        Me.Cmdsave.Size = New System.Drawing.Size(75, 23)
        Me.Cmdsave.TabIndex = 0
        Me.Cmdsave.Text = "Save"
        Me.Cmdsave.UseVisualStyleBackColor = True
        '
        'frmeditinv
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.CmdClose
        Me.ClientSize = New System.Drawing.Size(627, 358)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Name = "frmeditinv"
        Me.Text = "frmeditinv"
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.Panel2.PerformLayout()
        Me.SplitContainer1.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents cmdReset As System.Windows.Forms.Button
    Friend WithEvents CmdClose As System.Windows.Forms.Button
    Friend WithEvents Cmdsave As System.Windows.Forms.Button
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtControl_number As System.Windows.Forms.TextBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents txtboatunit As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txttplateyear As System.Windows.Forms.TextBox
    Friend WithEvents txttplateserial As System.Windows.Forms.TextBox
    Friend WithEvents txttplatemodel As System.Windows.Forms.TextBox
    Friend WithEvents txttplatemake As System.Windows.Forms.TextBox
    Friend WithEvents txtdriveyear As System.Windows.Forms.TextBox
    Friend WithEvents txtdriveserial As System.Windows.Forms.TextBox
    Friend WithEvents txtdrivemodel As System.Windows.Forms.TextBox
    Friend WithEvents txtdrivemake As System.Windows.Forms.TextBox
    Friend WithEvents txttraileryear As System.Windows.Forms.TextBox
    Friend WithEvents txttrailerserial As System.Windows.Forms.TextBox
    Friend WithEvents txttrailermodel As System.Windows.Forms.TextBox
    Friend WithEvents txttrailermake As System.Windows.Forms.TextBox
    Friend WithEvents txtmotoryear As System.Windows.Forms.TextBox
    Friend WithEvents txtmotorserial As System.Windows.Forms.TextBox
    Friend WithEvents txtmotormodel As System.Windows.Forms.TextBox
    Friend WithEvents txtmotormake As System.Windows.Forms.TextBox
    Friend WithEvents txtboatyear As System.Windows.Forms.TextBox
    Friend WithEvents txtboathin As System.Windows.Forms.TextBox
    Friend WithEvents txtboatmodel As System.Windows.Forms.TextBox
    Friend WithEvents txtboatmake As System.Windows.Forms.TextBox
    Friend WithEvents chknothere As System.Windows.Forms.CheckBox
    Friend WithEvents chkhere As System.Windows.Forms.CheckBox
    Friend WithEvents cmbLocation As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtboat_color As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtdiscount_reason As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents listequip As System.Windows.Forms.ListBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents datearrival As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtcomments As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents dateboatreg As System.Windows.Forms.DateTimePicker
    Friend WithEvents datemotorreg As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents dateInvoice As System.Windows.Forms.DateTimePicker
    Friend WithEvents dateGEpaid As System.Windows.Forms.DateTimePicker
    Friend WithEvents chkmotorreg As System.Windows.Forms.CheckBox
    Friend WithEvents chkboatreg As System.Windows.Forms.CheckBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents cmbFinancedCompany As System.Windows.Forms.ComboBox
    Friend WithEvents txtDiscount As System.Windows.Forms.TextBox
    Friend WithEvents txtPrice As System.Windows.Forms.TextBox
    Friend WithEvents txttrailer_color As System.Windows.Forms.TextBox
    Friend WithEvents txtequipment As System.Windows.Forms.TextBox
    Friend WithEvents txtCDNcost As System.Windows.Forms.TextBox
    Friend WithEvents txtEST_CDN_Cost As System.Windows.Forms.TextBox
    Friend WithEvents TXTGE_X_Rate As System.Windows.Forms.TextBox
    Friend WithEvents txttotal_us_cost As System.Windows.Forms.TextBox
    Friend WithEvents txtfrt_us_cost As System.Windows.Forms.TextBox
    Friend WithEvents txttrl_us_cost As System.Windows.Forms.TextBox
    Friend WithEvents txtInvoicenumber As System.Windows.Forms.TextBox
    Friend WithEvents txtboat_us_cost As System.Windows.Forms.TextBox
    Friend WithEvents txtPLA As System.Windows.Forms.TextBox
    Friend WithEvents txtRebate As System.Windows.Forms.TextBox
    Friend WithEvents txtLoadNumber As System.Windows.Forms.TextBox
    Friend WithEvents txtGEowing As System.Windows.Forms.TextBox
    Friend WithEvents txtGE_paid As System.Windows.Forms.TextBox
    Friend WithEvents txtGE_AMT_financed As System.Windows.Forms.TextBox
    Friend WithEvents txtremaining_CDN_Cost As System.Windows.Forms.TextBox
    Friend WithEvents TxtInv_Moved_to_COGS As System.Windows.Forms.TextBox
    Friend WithEvents datematurity As System.Windows.Forms.DateTimePicker
    Friend WithEvents datefreeinterest As System.Windows.Forms.DateTimePicker
    Friend WithEvents chkMaturitydate As System.Windows.Forms.CheckBox
    Friend WithEvents chkfree_interest As System.Windows.Forms.CheckBox
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents txtnotes As System.Windows.Forms.TextBox
    Friend WithEvents cmbStatus As System.Windows.Forms.ComboBox
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents cmdselect As System.Windows.Forms.Button
    Friend WithEvents btnviewdeal As System.Windows.Forms.Button
End Class
