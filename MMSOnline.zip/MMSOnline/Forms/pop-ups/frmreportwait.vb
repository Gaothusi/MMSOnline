Public NotInheritable Class frmreportwait

    Private Sub frmreportwait_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

End Class
