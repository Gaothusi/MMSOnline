﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmWO
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtWarnings = New System.Windows.Forms.TextBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.txtcolor = New System.Windows.Forms.TextBox()
        Me.txtyear = New System.Windows.Forms.TextBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.btnEditCust = New System.Windows.Forms.Button()
        Me.txtProv = New System.Windows.Forms.TextBox()
        Me.Txtphone2 = New System.Windows.Forms.TextBox()
        Me.Txtemail = New System.Windows.Forms.TextBox()
        Me.txtphone1 = New System.Windows.Forms.TextBox()
        Me.txtpostal = New System.Windows.Forms.TextBox()
        Me.txtmotorserial = New System.Windows.Forms.TextBox()
        Me.txtBoatSerial = New System.Windows.Forms.TextBox()
        Me.txttrailerserial = New System.Windows.Forms.TextBox()
        Me.txtmotormodel = New System.Windows.Forms.TextBox()
        Me.txtboatmodel = New System.Windows.Forms.TextBox()
        Me.txttrailermodel = New System.Windows.Forms.TextBox()
        Me.txtmotormake = New System.Windows.Forms.TextBox()
        Me.TxtBoatMake = New System.Windows.Forms.TextBox()
        Me.TxtCity = New System.Windows.Forms.TextBox()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txttrailermake = New System.Windows.Forms.TextBox()
        Me.BtnCustData = New System.Windows.Forms.Button()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.btnViewLogByCust = New System.Windows.Forms.Button()
        Me.btnVoid = New System.Windows.Forms.Button()
        Me.btnOrderParts = New System.Windows.Forms.Button()
        Me.btnReactivate = New System.Windows.Forms.Button()
        Me.BtnRePrintCheckin = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.btnreadytogo = New System.Windows.Forms.Button()
        Me.btnviewbos = New System.Windows.Forms.Button()
        Me.DateToBeDropped = New System.Windows.Forms.DateTimePicker()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.cmbstore = New System.Windows.Forms.ComboBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.btnCheckInNotes = New System.Windows.Forms.Button()
        Me.txtWOnum = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.btnCompleted = New System.Windows.Forms.Button()
        Me.BtnDropoff = New System.Windows.Forms.Button()
        Me.btnLogCall = New System.Windows.Forms.Button()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.DVCalls = New System.Windows.Forms.DataGridView()
        Me.View = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.DateDone = New System.Windows.Forms.DateTimePicker()
        Me.DateDropOff = New System.Windows.Forms.DateTimePicker()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.cmbPriority = New System.Windows.Forms.ComboBox()
        Me.cmbStatus = New System.Windows.Forms.ComboBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.DateReqComp = New System.Windows.Forms.DateTimePicker()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.CalDateReqComp = New System.Windows.Forms.MonthCalendar()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.btnCourtesyClean = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtNotes = New System.Windows.Forms.TextBox()
        Me.BtnAddIssue = New System.Windows.Forms.Button()
        Me.DVissues = New System.Windows.Forms.DataGridView()
        Me.RI = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.View2 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.txttotaladjustment2 = New System.Windows.Forms.TextBox()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.txtEnvirofee = New System.Windows.Forms.TextBox()
        Me.CmbEnviro = New System.Windows.Forms.ComboBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.txtBillpretax = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.txtbillpst = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.txtbillgst = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.txtbalance = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.txtpaid = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.txtbill = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.DVpayments = New System.Windows.Forms.DataGridView()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.listpdiforms = New System.Windows.Forms.ListBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.txttotaladjustments = New System.Windows.Forms.TextBox()
        Me.BtnAddAdjustment = New System.Windows.Forms.Button()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.DVadjustments = New System.Windows.Forms.DataGridView()
        Me.Delete = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.Edit = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.DVCalls, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.DVissues, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.DVpayments, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        CType(Me.DVadjustments, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel1)
        Me.FlowLayoutPanel1.Controls.Add(Me.SplitContainer1)
        Me.FlowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(993, 615)
        Me.FlowLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.txtWarnings)
        Me.Panel1.Controls.Add(Me.Label43)
        Me.Panel1.Controls.Add(Me.txtcolor)
        Me.Panel1.Controls.Add(Me.txtyear)
        Me.Panel1.Controls.Add(Me.Label38)
        Me.Panel1.Controls.Add(Me.Label39)
        Me.Panel1.Controls.Add(Me.btnEditCust)
        Me.Panel1.Controls.Add(Me.txtProv)
        Me.Panel1.Controls.Add(Me.Txtphone2)
        Me.Panel1.Controls.Add(Me.Txtemail)
        Me.Panel1.Controls.Add(Me.txtphone1)
        Me.Panel1.Controls.Add(Me.txtpostal)
        Me.Panel1.Controls.Add(Me.txtmotorserial)
        Me.Panel1.Controls.Add(Me.txtBoatSerial)
        Me.Panel1.Controls.Add(Me.txttrailerserial)
        Me.Panel1.Controls.Add(Me.txtmotormodel)
        Me.Panel1.Controls.Add(Me.txtboatmodel)
        Me.Panel1.Controls.Add(Me.txttrailermodel)
        Me.Panel1.Controls.Add(Me.txtmotormake)
        Me.Panel1.Controls.Add(Me.TxtBoatMake)
        Me.Panel1.Controls.Add(Me.TxtCity)
        Me.Panel1.Controls.Add(Me.txtAddress)
        Me.Panel1.Controls.Add(Me.txtName)
        Me.Panel1.Controls.Add(Me.txttrailermake)
        Me.Panel1.Controls.Add(Me.BtnCustData)
        Me.Panel1.Controls.Add(Me.Label24)
        Me.Panel1.Controls.Add(Me.Label25)
        Me.Panel1.Controls.Add(Me.Label26)
        Me.Panel1.Controls.Add(Me.Label22)
        Me.Panel1.Controls.Add(Me.Label23)
        Me.Panel1.Controls.Add(Me.Label20)
        Me.Panel1.Controls.Add(Me.Label21)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.Label19)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(985, 163)
        Me.Panel1.TabIndex = 0
        '
        'txtWarnings
        '
        Me.txtWarnings.Enabled = False
        Me.txtWarnings.Location = New System.Drawing.Point(785, 120)
        Me.txtWarnings.Name = "txtWarnings"
        Me.txtWarnings.Size = New System.Drawing.Size(31, 20)
        Me.txtWarnings.TabIndex = 44
        Me.txtWarnings.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(704, 120)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(75, 18)
        Me.Label43.TabIndex = 43
        Me.Label43.Text = "Warnings:"
        Me.Label43.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'txtcolor
        '
        Me.txtcolor.Enabled = False
        Me.txtcolor.Location = New System.Drawing.Point(513, 118)
        Me.txtcolor.Name = "txtcolor"
        Me.txtcolor.Size = New System.Drawing.Size(99, 20)
        Me.txtcolor.TabIndex = 42
        '
        'txtyear
        '
        Me.txtyear.Enabled = False
        Me.txtyear.Location = New System.Drawing.Point(514, 141)
        Me.txtyear.Name = "txtyear"
        Me.txtyear.Size = New System.Drawing.Size(99, 20)
        Me.txtyear.TabIndex = 41
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(466, 141)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(42, 18)
        Me.Label38.TabIndex = 40
        Me.Label38.Text = "Year:"
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(424, 120)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(84, 18)
        Me.Label39.TabIndex = 39
        Me.Label39.Text = "Boat Color:"
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'btnEditCust
        '
        Me.btnEditCust.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnEditCust.Location = New System.Drawing.Point(862, 85)
        Me.btnEditCust.Name = "btnEditCust"
        Me.btnEditCust.Size = New System.Drawing.Size(119, 34)
        Me.btnEditCust.TabIndex = 38
        Me.btnEditCust.Text = "View/Edit Details"
        Me.btnEditCust.UseVisualStyleBackColor = True
        Me.btnEditCust.Visible = False
        '
        'txtProv
        '
        Me.txtProv.Enabled = False
        Me.txtProv.Location = New System.Drawing.Point(297, 69)
        Me.txtProv.Name = "txtProv"
        Me.txtProv.Size = New System.Drawing.Size(47, 20)
        Me.txtProv.TabIndex = 37
        '
        'Txtphone2
        '
        Me.Txtphone2.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Txtphone2.Enabled = False
        Me.Txtphone2.Location = New System.Drawing.Point(785, 20)
        Me.Txtphone2.Name = "Txtphone2"
        Me.Txtphone2.Size = New System.Drawing.Size(192, 20)
        Me.Txtphone2.TabIndex = 36
        '
        'Txtemail
        '
        Me.Txtemail.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Txtemail.Enabled = False
        Me.Txtemail.Location = New System.Drawing.Point(513, 46)
        Me.Txtemail.Name = "Txtemail"
        Me.Txtemail.Size = New System.Drawing.Size(174, 20)
        Me.Txtemail.TabIndex = 35
        Me.Txtemail.Visible = False
        '
        'txtphone1
        '
        Me.txtphone1.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtphone1.Enabled = False
        Me.txtphone1.Location = New System.Drawing.Point(516, 20)
        Me.txtphone1.Name = "txtphone1"
        Me.txtphone1.Size = New System.Drawing.Size(170, 20)
        Me.txtphone1.TabIndex = 34
        '
        'txtpostal
        '
        Me.txtpostal.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtpostal.Enabled = False
        Me.txtpostal.Location = New System.Drawing.Point(513, 69)
        Me.txtpostal.Name = "txtpostal"
        Me.txtpostal.Size = New System.Drawing.Size(121, 20)
        Me.txtpostal.TabIndex = 33
        Me.txtpostal.Visible = False
        '
        'txtmotorserial
        '
        Me.txtmotorserial.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtmotorserial.Enabled = False
        Me.txtmotorserial.Location = New System.Drawing.Point(785, 43)
        Me.txtmotorserial.Name = "txtmotorserial"
        Me.txtmotorserial.Size = New System.Drawing.Size(192, 20)
        Me.txtmotorserial.TabIndex = 32
        Me.txtmotorserial.Visible = False
        '
        'txtBoatSerial
        '
        Me.txtBoatSerial.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBoatSerial.Enabled = False
        Me.txtBoatSerial.Location = New System.Drawing.Point(513, 95)
        Me.txtBoatSerial.Name = "txtBoatSerial"
        Me.txtBoatSerial.Size = New System.Drawing.Size(174, 20)
        Me.txtBoatSerial.TabIndex = 31
        '
        'txttrailerserial
        '
        Me.txttrailerserial.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txttrailerserial.Enabled = False
        Me.txttrailerserial.Location = New System.Drawing.Point(785, 66)
        Me.txttrailerserial.Name = "txttrailerserial"
        Me.txttrailerserial.Size = New System.Drawing.Size(192, 20)
        Me.txttrailerserial.TabIndex = 30
        Me.txttrailerserial.Visible = False
        '
        'txtmotormodel
        '
        Me.txtmotormodel.Enabled = False
        Me.txtmotormodel.Location = New System.Drawing.Point(317, 115)
        Me.txtmotormodel.Name = "txtmotormodel"
        Me.txtmotormodel.Size = New System.Drawing.Size(99, 20)
        Me.txtmotormodel.TabIndex = 29
        '
        'txtboatmodel
        '
        Me.txtboatmodel.Enabled = False
        Me.txtboatmodel.Location = New System.Drawing.Point(317, 92)
        Me.txtboatmodel.Name = "txtboatmodel"
        Me.txtboatmodel.Size = New System.Drawing.Size(99, 20)
        Me.txtboatmodel.TabIndex = 28
        '
        'txttrailermodel
        '
        Me.txttrailermodel.Enabled = False
        Me.txttrailermodel.Location = New System.Drawing.Point(318, 138)
        Me.txttrailermodel.Name = "txttrailermodel"
        Me.txttrailermodel.Size = New System.Drawing.Size(99, 20)
        Me.txttrailermodel.TabIndex = 27
        '
        'txtmotormake
        '
        Me.txtmotormake.Enabled = False
        Me.txtmotormake.Location = New System.Drawing.Point(110, 115)
        Me.txtmotormake.Name = "txtmotormake"
        Me.txtmotormake.Size = New System.Drawing.Size(99, 20)
        Me.txtmotormake.TabIndex = 26
        '
        'TxtBoatMake
        '
        Me.TxtBoatMake.Enabled = False
        Me.TxtBoatMake.Location = New System.Drawing.Point(110, 92)
        Me.TxtBoatMake.Name = "TxtBoatMake"
        Me.TxtBoatMake.Size = New System.Drawing.Size(99, 20)
        Me.TxtBoatMake.TabIndex = 25
        '
        'TxtCity
        '
        Me.TxtCity.Enabled = False
        Me.TxtCity.Location = New System.Drawing.Point(81, 69)
        Me.TxtCity.Name = "TxtCity"
        Me.TxtCity.Size = New System.Drawing.Size(128, 20)
        Me.TxtCity.TabIndex = 24
        '
        'txtAddress
        '
        Me.txtAddress.Enabled = False
        Me.txtAddress.Location = New System.Drawing.Point(81, 46)
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(263, 20)
        Me.txtAddress.TabIndex = 23
        Me.txtAddress.Visible = False
        '
        'txtName
        '
        Me.txtName.Enabled = False
        Me.txtName.Location = New System.Drawing.Point(81, 22)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(263, 20)
        Me.txtName.TabIndex = 22
        '
        'txttrailermake
        '
        Me.txttrailermake.Enabled = False
        Me.txttrailermake.Location = New System.Drawing.Point(110, 138)
        Me.txttrailermake.Name = "txttrailermake"
        Me.txttrailermake.Size = New System.Drawing.Size(99, 20)
        Me.txttrailermake.TabIndex = 21
        '
        'BtnCustData
        '
        Me.BtnCustData.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BtnCustData.Location = New System.Drawing.Point(862, 123)
        Me.BtnCustData.Name = "BtnCustData"
        Me.BtnCustData.Size = New System.Drawing.Size(119, 35)
        Me.BtnCustData.TabIndex = 0
        Me.BtnCustData.Text = "Select a Customer"
        Me.BtnCustData.UseVisualStyleBackColor = True
        '
        'Label24
        '
        Me.Label24.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(694, 65)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(94, 18)
        Me.Label24.TabIndex = 17
        Me.Label24.Text = "Trailer Serial:"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.Label24.Visible = False
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(213, 140)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(98, 18)
        Me.Label25.TabIndex = 16
        Me.Label25.Text = "Trailer Model:"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(10, 137)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(94, 18)
        Me.Label26.TabIndex = 15
        Me.Label26.Text = "Trailer Make:"
        '
        'Label22
        '
        Me.Label22.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(422, 97)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(84, 18)
        Me.Label22.TabIndex = 13
        Me.Label22.Text = "Boat Serial:"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label23
        '
        Me.Label23.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(693, 43)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(93, 18)
        Me.Label23.TabIndex = 14
        Me.Label23.Text = "Motor Serial:"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.Label23.Visible = False
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(223, 94)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(88, 18)
        Me.Label20.TabIndex = 11
        Me.Label20.Text = "Boat Model:"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(214, 117)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(97, 18)
        Me.Label21.TabIndex = 12
        Me.Label21.Text = "Motor Model:"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(20, 94)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(84, 18)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "Boat Make:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(215, 68)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(70, 18)
        Me.Label9.TabIndex = 7
        Me.Label9.Text = "Province:"
        '
        'Label10
        '
        Me.Label10.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(704, 22)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(75, 18)
        Me.Label10.TabIndex = 6
        Me.Label10.Text = "Phone #2:"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label11
        '
        Me.Label11.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(439, 22)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(67, 18)
        Me.Label11.TabIndex = 5
        Me.Label11.Text = "Phone #:"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label15
        '
        Me.Label15.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(395, 48)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(112, 18)
        Me.Label15.TabIndex = 9
        Me.Label15.Text = "E-mail Address:"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.Label15.Visible = False
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(11, 114)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(93, 18)
        Me.Label19.TabIndex = 10
        Me.Label19.Text = "Motor Make:"
        '
        'Label7
        '
        Me.Label7.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(413, 69)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(94, 18)
        Me.Label7.TabIndex = 4
        Me.Label7.Text = "Postal Code:"
        Me.Label7.Visible = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(17, 68)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(37, 18)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "City:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(17, 48)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(66, 18)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Address:"
        Me.Label5.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(17, 24)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 18)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Name:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(9, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(153, 24)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Customer Profile:"
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Location = New System.Drawing.Point(3, 172)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnViewLogByCust)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnVoid)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnOrderParts)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnReactivate)
        Me.SplitContainer1.Panel1.Controls.Add(Me.BtnRePrintCheckin)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Button2)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnreadytogo)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnviewbos)
        Me.SplitContainer1.Panel1.Controls.Add(Me.DateToBeDropped)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Label30)
        Me.SplitContainer1.Panel1.Controls.Add(Me.cmbstore)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Label17)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnCheckInNotes)
        Me.SplitContainer1.Panel1.Controls.Add(Me.txtWOnum)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Label12)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnCompleted)
        Me.SplitContainer1.Panel1.Controls.Add(Me.BtnDropoff)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnLogCall)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Label28)
        Me.SplitContainer1.Panel1.Controls.Add(Me.DVCalls)
        Me.SplitContainer1.Panel1.Controls.Add(Me.DateDone)
        Me.SplitContainer1.Panel1.Controls.Add(Me.DateDropOff)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Label29)
        Me.SplitContainer1.Panel1.Controls.Add(Me.cmbPriority)
        Me.SplitContainer1.Panel1.Controls.Add(Me.cmbStatus)
        Me.SplitContainer1.Panel1.Controls.Add(Me.GroupBox1)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Label27)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Label2)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Label14)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Label13)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.TabControl1)
        Me.SplitContainer1.Size = New System.Drawing.Size(989, 439)
        Me.SplitContainer1.SplitterDistance = 500
        Me.SplitContainer1.TabIndex = 1
        '
        'btnViewLogByCust
        '
        Me.btnViewLogByCust.Location = New System.Drawing.Point(269, 302)
        Me.btnViewLogByCust.Name = "btnViewLogByCust"
        Me.btnViewLogByCust.Size = New System.Drawing.Size(132, 23)
        Me.btnViewLogByCust.TabIndex = 66
        Me.btnViewLogByCust.Text = "View All Customer Calls"
        Me.btnViewLogByCust.UseVisualStyleBackColor = True
        '
        'btnVoid
        '
        Me.btnVoid.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnVoid.Location = New System.Drawing.Point(407, 245)
        Me.btnVoid.Name = "btnVoid"
        Me.btnVoid.Size = New System.Drawing.Size(83, 23)
        Me.btnVoid.TabIndex = 65
        Me.btnVoid.Text = "Void WO"
        Me.btnVoid.UseVisualStyleBackColor = True
        '
        'btnOrderParts
        '
        Me.btnOrderParts.Location = New System.Drawing.Point(13, 245)
        Me.btnOrderParts.Name = "btnOrderParts"
        Me.btnOrderParts.Size = New System.Drawing.Size(94, 23)
        Me.btnOrderParts.TabIndex = 64
        Me.btnOrderParts.Text = "Order Parts"
        Me.btnOrderParts.UseVisualStyleBackColor = True
        Me.btnOrderParts.Visible = False
        '
        'btnReactivate
        '
        Me.btnReactivate.Location = New System.Drawing.Point(271, 274)
        Me.btnReactivate.Name = "btnReactivate"
        Me.btnReactivate.Size = New System.Drawing.Size(132, 23)
        Me.btnReactivate.TabIndex = 63
        Me.btnReactivate.Text = "Reactivate WO"
        Me.btnReactivate.UseVisualStyleBackColor = True
        Me.btnReactivate.Visible = False
        '
        'BtnRePrintCheckin
        '
        Me.BtnRePrintCheckin.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BtnRePrintCheckin.Location = New System.Drawing.Point(213, 245)
        Me.BtnRePrintCheckin.Name = "BtnRePrintCheckin"
        Me.BtnRePrintCheckin.Size = New System.Drawing.Size(94, 23)
        Me.BtnRePrintCheckin.TabIndex = 62
        Me.BtnRePrintCheckin.Text = "Print Check In"
        Me.BtnRePrintCheckin.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(407, 274)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(83, 23)
        Me.Button2.TabIndex = 61
        Me.Button2.Text = "Print"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'btnreadytogo
        '
        Me.btnreadytogo.Location = New System.Drawing.Point(115, 274)
        Me.btnreadytogo.Name = "btnreadytogo"
        Me.btnreadytogo.Size = New System.Drawing.Size(150, 23)
        Me.btnreadytogo.TabIndex = 59
        Me.btnreadytogo.Text = "Mark as waiting for pick up"
        Me.btnreadytogo.UseVisualStyleBackColor = True
        Me.btnreadytogo.Visible = False
        '
        'btnviewbos
        '
        Me.btnviewbos.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnviewbos.Location = New System.Drawing.Point(316, 245)
        Me.btnviewbos.Name = "btnviewbos"
        Me.btnviewbos.Size = New System.Drawing.Size(82, 23)
        Me.btnviewbos.TabIndex = 56
        Me.btnviewbos.Text = "View BOS"
        Me.btnviewbos.UseVisualStyleBackColor = True
        Me.btnviewbos.Visible = False
        '
        'DateToBeDropped
        '
        Me.DateToBeDropped.Enabled = False
        Me.DateToBeDropped.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateToBeDropped.Location = New System.Drawing.Point(13, 147)
        Me.DateToBeDropped.Name = "DateToBeDropped"
        Me.DateToBeDropped.Size = New System.Drawing.Size(147, 20)
        Me.DateToBeDropped.TabIndex = 55
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(5, 127)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(162, 16)
        Me.Label30.TabIndex = 54
        Me.Label30.Text = "Scheduled Check In Date:"
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'cmbstore
        '
        Me.cmbstore.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbstore.Enabled = False
        Me.cmbstore.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbstore.FormattingEnabled = True
        Me.cmbstore.Location = New System.Drawing.Point(72, 53)
        Me.cmbstore.Name = "cmbstore"
        Me.cmbstore.Size = New System.Drawing.Size(136, 21)
        Me.cmbstore.TabIndex = 53
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(13, 57)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(48, 18)
        Me.Label17.TabIndex = 52
        Me.Label17.Text = "Store:"
        '
        'btnCheckInNotes
        '
        Me.btnCheckInNotes.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCheckInNotes.Location = New System.Drawing.Point(307, 245)
        Me.btnCheckInNotes.Name = "btnCheckInNotes"
        Me.btnCheckInNotes.Size = New System.Drawing.Size(94, 23)
        Me.btnCheckInNotes.TabIndex = 58
        Me.btnCheckInNotes.Text = "View Check In Notes"
        Me.btnCheckInNotes.UseVisualStyleBackColor = True
        Me.btnCheckInNotes.Visible = False
        '
        'txtWOnum
        '
        Me.txtWOnum.Enabled = False
        Me.txtWOnum.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWOnum.Location = New System.Drawing.Point(75, 30)
        Me.txtWOnum.Name = "txtWOnum"
        Me.txtWOnum.Size = New System.Drawing.Size(133, 20)
        Me.txtWOnum.TabIndex = 50
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(7, 32)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(56, 18)
        Me.Label12.TabIndex = 15
        Me.Label12.Text = "WO #:"
        '
        'btnCompleted
        '
        Me.btnCompleted.Location = New System.Drawing.Point(270, 274)
        Me.btnCompleted.Name = "btnCompleted"
        Me.btnCompleted.Size = New System.Drawing.Size(132, 23)
        Me.btnCompleted.TabIndex = 3
        Me.btnCompleted.Text = "Complete Work Order"
        Me.btnCompleted.UseVisualStyleBackColor = True
        Me.btnCompleted.Visible = False
        '
        'BtnDropoff
        '
        Me.BtnDropoff.Location = New System.Drawing.Point(37, 173)
        Me.BtnDropoff.Name = "BtnDropoff"
        Me.BtnDropoff.Size = New System.Drawing.Size(119, 23)
        Me.BtnDropoff.TabIndex = 2
        Me.BtnDropoff.Text = "Check In"
        Me.BtnDropoff.UseVisualStyleBackColor = True
        Me.BtnDropoff.Visible = False
        '
        'btnLogCall
        '
        Me.btnLogCall.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnLogCall.Location = New System.Drawing.Point(407, 303)
        Me.btnLogCall.Name = "btnLogCall"
        Me.btnLogCall.Size = New System.Drawing.Size(83, 23)
        Me.btnLogCall.TabIndex = 4
        Me.btnLogCall.Text = "Log A Call"
        Me.btnLogCall.UseVisualStyleBackColor = True
        Me.btnLogCall.Visible = False
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(13, 302)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(83, 24)
        Me.Label28.TabIndex = 46
        Me.Label28.Text = "Call Log:"
        '
        'DVCalls
        '
        Me.DVCalls.AllowUserToAddRows = False
        Me.DVCalls.AllowUserToDeleteRows = False
        Me.DVCalls.AllowUserToResizeRows = False
        Me.DVCalls.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DVCalls.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DVCalls.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.View})
        Me.DVCalls.Location = New System.Drawing.Point(9, 329)
        Me.DVCalls.Name = "DVCalls"
        Me.DVCalls.ReadOnly = True
        Me.DVCalls.RowHeadersVisible = False
        Me.DVCalls.Size = New System.Drawing.Size(481, 98)
        Me.DVCalls.TabIndex = 45
        '
        'View
        '
        Me.View.HeaderText = "View"
        Me.View.Name = "View"
        Me.View.ReadOnly = True
        Me.View.Text = "View"
        Me.View.Visible = False
        '
        'DateDone
        '
        Me.DateDone.Enabled = False
        Me.DateDone.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateDone.Location = New System.Drawing.Point(112, 274)
        Me.DateDone.Name = "DateDone"
        Me.DateDone.Size = New System.Drawing.Size(147, 20)
        Me.DateDone.TabIndex = 44
        Me.DateDone.Visible = False
        '
        'DateDropOff
        '
        Me.DateDropOff.Enabled = False
        Me.DateDropOff.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateDropOff.Location = New System.Drawing.Point(13, 190)
        Me.DateDropOff.Name = "DateDropOff"
        Me.DateDropOff.Size = New System.Drawing.Size(147, 20)
        Me.DateDropOff.TabIndex = 43
        Me.DateDropOff.Visible = False
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(5, 213)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(109, 16)
        Me.Label29.TabIndex = 42
        Me.Label29.Text = "Date Completed:"
        '
        'cmbPriority
        '
        Me.cmbPriority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbPriority.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbPriority.FormattingEnabled = True
        Me.cmbPriority.Items.AddRange(New Object() {"Normal", "Same Day", "Rush", "Low"})
        Me.cmbPriority.Location = New System.Drawing.Point(72, 102)
        Me.cmbPriority.Name = "cmbPriority"
        Me.cmbPriority.Size = New System.Drawing.Size(136, 21)
        Me.cmbPriority.TabIndex = 1
        '
        'cmbStatus
        '
        Me.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStatus.Enabled = False
        Me.cmbStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStatus.FormattingEnabled = True
        Me.cmbStatus.Items.AddRange(New Object() {"Scheduled", "Requested Rig", "Approved Rig", "Active", "Waiting For Parts", "Waiting For Pickup", "Storage", "Closed", "Void"})
        Me.cmbStatus.Location = New System.Drawing.Point(72, 78)
        Me.cmbStatus.Name = "cmbStatus"
        Me.cmbStatus.Size = New System.Drawing.Size(136, 21)
        Me.cmbStatus.TabIndex = 0
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.DateReqComp)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.CalDateReqComp)
        Me.GroupBox1.Location = New System.Drawing.Point(219, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(228, 228)
        Me.GroupBox1.TabIndex = 39
        Me.GroupBox1.TabStop = False
        '
        'DateReqComp
        '
        Me.DateReqComp.CustomFormat = "M/d/yyyy h:mm tt"
        Me.DateReqComp.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DateReqComp.Location = New System.Drawing.Point(39, 195)
        Me.DateReqComp.Name = "DateReqComp"
        Me.DateReqComp.Size = New System.Drawing.Size(173, 20)
        Me.DateReqComp.TabIndex = 12
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(15, 8)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(169, 13)
        Me.Label18.TabIndex = 11
        Me.Label18.Text = "Requested Completion Date:"
        '
        'CalDateReqComp
        '
        Me.CalDateReqComp.Enabled = False
        Me.CalDateReqComp.Font = New System.Drawing.Font("Lucida Console", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CalDateReqComp.Location = New System.Drawing.Point(1, 21)
        Me.CalDateReqComp.Name = "CalDateReqComp"
        Me.CalDateReqComp.TabIndex = 0
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(5, 170)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(116, 16)
        Me.Label27.TabIndex = 38
        Me.Label27.Text = "Date Dropped Off:"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(9, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(157, 24)
        Me.Label2.TabIndex = 38
        Me.Label2.Text = "Appointment Info:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(11, 82)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(54, 18)
        Me.Label14.TabIndex = 10
        Me.Label14.Text = "Status:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(5, 105)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(58, 18)
        Me.Label13.TabIndex = 11
        Me.Label13.Text = "Priority:"
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Location = New System.Drawing.Point(0, 2)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(485, 439)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.btnCourtesyClean)
        Me.TabPage1.Controls.Add(Me.Button3)
        Me.TabPage1.Controls.Add(Me.Label16)
        Me.TabPage1.Controls.Add(Me.txtNotes)
        Me.TabPage1.Controls.Add(Me.BtnAddIssue)
        Me.TabPage1.Controls.Add(Me.DVissues)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(477, 413)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Work"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'btnCourtesyClean
        '
        Me.btnCourtesyClean.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCourtesyClean.Location = New System.Drawing.Point(184, 374)
        Me.btnCourtesyClean.Name = "btnCourtesyClean"
        Me.btnCourtesyClean.Size = New System.Drawing.Size(124, 31)
        Me.btnCourtesyClean.TabIndex = 62
        Me.btnCourtesyClean.Text = "Courtesy Clean"
        Me.btnCourtesyClean.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(95, 374)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(83, 31)
        Me.Button3.TabIndex = 61
        Me.Button3.Text = "Assign All"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(0, 4)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(52, 18)
        Me.Label16.TabIndex = 60
        Me.Label16.Text = "Notes:"
        '
        'txtNotes
        '
        Me.txtNotes.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtNotes.Location = New System.Drawing.Point(3, 25)
        Me.txtNotes.Multiline = True
        Me.txtNotes.Name = "txtNotes"
        Me.txtNotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtNotes.Size = New System.Drawing.Size(466, 94)
        Me.txtNotes.TabIndex = 55
        '
        'BtnAddIssue
        '
        Me.BtnAddIssue.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnAddIssue.Location = New System.Drawing.Point(6, 374)
        Me.BtnAddIssue.Name = "BtnAddIssue"
        Me.BtnAddIssue.Size = New System.Drawing.Size(83, 31)
        Me.BtnAddIssue.TabIndex = 56
        Me.BtnAddIssue.Text = "Add Issue"
        Me.BtnAddIssue.UseVisualStyleBackColor = True
        '
        'DVissues
        '
        Me.DVissues.AllowUserToAddRows = False
        Me.DVissues.AllowUserToDeleteRows = False
        Me.DVissues.AllowUserToResizeRows = False
        Me.DVissues.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DVissues.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DVissues.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.RI, Me.View2})
        Me.DVissues.Location = New System.Drawing.Point(3, 148)
        Me.DVissues.Name = "DVissues"
        Me.DVissues.ReadOnly = True
        Me.DVissues.RowHeadersVisible = False
        Me.DVissues.Size = New System.Drawing.Size(466, 219)
        Me.DVissues.TabIndex = 59
        '
        'RI
        '
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.Red
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.RI.DefaultCellStyle = DataGridViewCellStyle1
        Me.RI.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RI.HeaderText = "Remove"
        Me.RI.MinimumWidth = 50
        Me.RI.Name = "RI"
        Me.RI.ReadOnly = True
        Me.RI.UseColumnTextForButtonValue = True
        Me.RI.Width = 50
        '
        'View2
        '
        Me.View2.HeaderText = "View"
        Me.View2.MinimumWidth = 40
        Me.View2.Name = "View2"
        Me.View2.ReadOnly = True
        Me.View2.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(4, 118)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(200, 24)
        Me.Label3.TabIndex = 57
        Me.Label3.Text = "Work to be completed:"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Label42)
        Me.TabPage2.Controls.Add(Me.txttotaladjustment2)
        Me.TabPage2.Controls.Add(Me.Label40)
        Me.TabPage2.Controls.Add(Me.txtEnvirofee)
        Me.TabPage2.Controls.Add(Me.CmbEnviro)
        Me.TabPage2.Controls.Add(Me.Label37)
        Me.TabPage2.Controls.Add(Me.txtBillpretax)
        Me.TabPage2.Controls.Add(Me.Label36)
        Me.TabPage2.Controls.Add(Me.txtbillpst)
        Me.TabPage2.Controls.Add(Me.Label35)
        Me.TabPage2.Controls.Add(Me.txtbillgst)
        Me.TabPage2.Controls.Add(Me.Button1)
        Me.TabPage2.Controls.Add(Me.Label34)
        Me.TabPage2.Controls.Add(Me.txtbalance)
        Me.TabPage2.Controls.Add(Me.Label32)
        Me.TabPage2.Controls.Add(Me.txtpaid)
        Me.TabPage2.Controls.Add(Me.Label31)
        Me.TabPage2.Controls.Add(Me.txtbill)
        Me.TabPage2.Controls.Add(Me.Label33)
        Me.TabPage2.Controls.Add(Me.DVpayments)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(477, 413)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Billing"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(206, 216)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(93, 18)
        Me.Label42.TabIndex = 103
        Me.Label42.Text = "Adjustments:"
        '
        'txttotaladjustment2
        '
        Me.txttotaladjustment2.Enabled = False
        Me.txttotaladjustment2.Location = New System.Drawing.Point(301, 214)
        Me.txttotaladjustment2.Name = "txttotaladjustment2"
        Me.txttotaladjustment2.Size = New System.Drawing.Size(71, 20)
        Me.txttotaladjustment2.TabIndex = 102
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(141, 190)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(83, 18)
        Me.Label40.TabIndex = 101
        Me.Label40.Text = "Enviro Fee:"
        '
        'txtEnvirofee
        '
        Me.txtEnvirofee.Enabled = False
        Me.txtEnvirofee.Location = New System.Drawing.Point(301, 188)
        Me.txtEnvirofee.Name = "txtEnvirofee"
        Me.txtEnvirofee.Size = New System.Drawing.Size(71, 20)
        Me.txtEnvirofee.TabIndex = 100
        '
        'CmbEnviro
        '
        Me.CmbEnviro.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbEnviro.FormattingEnabled = True
        Me.CmbEnviro.Items.AddRange(New Object() {"YES", "NO"})
        Me.CmbEnviro.Location = New System.Drawing.Point(230, 187)
        Me.CmbEnviro.Name = "CmbEnviro"
        Me.CmbEnviro.Size = New System.Drawing.Size(66, 21)
        Me.CmbEnviro.TabIndex = 99
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(264, 165)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(31, 18)
        Me.Label37.TabIndex = 98
        Me.Label37.Text = "Bill:"
        '
        'txtBillpretax
        '
        Me.txtBillpretax.Enabled = False
        Me.txtBillpretax.Location = New System.Drawing.Point(301, 162)
        Me.txtBillpretax.Name = "txtBillpretax"
        Me.txtBillpretax.Size = New System.Drawing.Size(71, 20)
        Me.txtBillpretax.TabIndex = 97
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(249, 265)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(41, 18)
        Me.Label36.TabIndex = 96
        Me.Label36.Text = "PST:"
        '
        'txtbillpst
        '
        Me.txtbillpst.Enabled = False
        Me.txtbillpst.Location = New System.Drawing.Point(301, 266)
        Me.txtbillpst.Name = "txtbillpst"
        Me.txtbillpst.Size = New System.Drawing.Size(71, 20)
        Me.txtbillpst.TabIndex = 95
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(252, 242)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(43, 18)
        Me.Label35.TabIndex = 94
        Me.Label35.Text = "GST:"
        '
        'txtbillgst
        '
        Me.txtbillgst.Enabled = False
        Me.txtbillgst.Location = New System.Drawing.Point(301, 240)
        Me.txtbillgst.Name = "txtbillgst"
        Me.txtbillgst.Size = New System.Drawing.Size(71, 20)
        Me.txtbillgst.TabIndex = 93
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(8, 170)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(100, 31)
        Me.Button1.TabIndex = 92
        Me.Button1.Text = "Add Payment"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(227, 349)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(65, 18)
        Me.Label34.TabIndex = 91
        Me.Label34.Text = "Balance:"
        '
        'txtbalance
        '
        Me.txtbalance.Enabled = False
        Me.txtbalance.Location = New System.Drawing.Point(301, 347)
        Me.txtbalance.Name = "txtbalance"
        Me.txtbalance.Size = New System.Drawing.Size(71, 20)
        Me.txtbalance.TabIndex = 90
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(217, 324)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(78, 18)
        Me.Label32.TabIndex = 89
        Me.Label32.Text = "Total Paid:"
        '
        'txtpaid
        '
        Me.txtpaid.Enabled = False
        Me.txtpaid.Location = New System.Drawing.Point(301, 320)
        Me.txtpaid.Name = "txtpaid"
        Me.txtpaid.Size = New System.Drawing.Size(71, 20)
        Me.txtpaid.TabIndex = 88
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(227, 294)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(68, 18)
        Me.Label31.TabIndex = 87
        Me.Label31.Text = "Total Bill:"
        '
        'txtbill
        '
        Me.txtbill.Enabled = False
        Me.txtbill.Location = New System.Drawing.Point(301, 292)
        Me.txtbill.Name = "txtbill"
        Me.txtbill.Size = New System.Drawing.Size(71, 20)
        Me.txtbill.TabIndex = 86
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(4, 4)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(172, 24)
        Me.Label33.TabIndex = 70
        Me.Label33.Text = "Payment Collected:"
        '
        'DVpayments
        '
        Me.DVpayments.AllowUserToAddRows = False
        Me.DVpayments.AllowUserToDeleteRows = False
        Me.DVpayments.AllowUserToResizeColumns = False
        Me.DVpayments.AllowUserToResizeRows = False
        Me.DVpayments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DVpayments.Location = New System.Drawing.Point(8, 35)
        Me.DVpayments.Name = "DVpayments"
        Me.DVpayments.ReadOnly = True
        Me.DVpayments.RowHeadersVisible = False
        Me.DVpayments.Size = New System.Drawing.Size(252, 129)
        Me.DVpayments.TabIndex = 69
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.listpdiforms)
        Me.TabPage3.Controls.Add(Me.Button4)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(477, 413)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Print PDI Sheets"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'listpdiforms
        '
        Me.listpdiforms.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.listpdiforms.FormattingEnabled = True
        Me.listpdiforms.ItemHeight = 20
        Me.listpdiforms.Items.AddRange(New Object() {"Boat and sterndrive", "Boat and outboard", "Small outboard", "Trailer", "In-Service Checklist 2013"})
        Me.listpdiforms.Location = New System.Drawing.Point(75, 105)
        Me.listpdiforms.Name = "listpdiforms"
        Me.listpdiforms.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple
        Me.listpdiforms.Size = New System.Drawing.Size(229, 124)
        Me.listpdiforms.TabIndex = 63
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(221, 245)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(83, 23)
        Me.Button4.TabIndex = 62
        Me.Button4.Text = "Print"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.txttotaladjustments)
        Me.TabPage4.Controls.Add(Me.BtnAddAdjustment)
        Me.TabPage4.Controls.Add(Me.Label41)
        Me.TabPage4.Controls.Add(Me.DVadjustments)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(477, 413)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Adjustments"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'txttotaladjustments
        '
        Me.txttotaladjustments.Enabled = False
        Me.txttotaladjustments.Location = New System.Drawing.Point(297, 340)
        Me.txttotaladjustments.Name = "txttotaladjustments"
        Me.txttotaladjustments.Size = New System.Drawing.Size(71, 20)
        Me.txttotaladjustments.TabIndex = 101
        '
        'BtnAddAdjustment
        '
        Me.BtnAddAdjustment.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnAddAdjustment.Location = New System.Drawing.Point(8, 334)
        Me.BtnAddAdjustment.Name = "BtnAddAdjustment"
        Me.BtnAddAdjustment.Size = New System.Drawing.Size(182, 31)
        Me.BtnAddAdjustment.TabIndex = 100
        Me.BtnAddAdjustment.Text = "Add Adjustment"
        Me.BtnAddAdjustment.UseVisualStyleBackColor = True
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(3, 4)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(96, 24)
        Me.Label41.TabIndex = 99
        Me.Label41.Text = "Adjust Bill:"
        '
        'DVadjustments
        '
        Me.DVadjustments.AllowUserToAddRows = False
        Me.DVadjustments.AllowUserToDeleteRows = False
        Me.DVadjustments.AllowUserToResizeColumns = False
        Me.DVadjustments.AllowUserToResizeRows = False
        Me.DVadjustments.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DVadjustments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DVadjustments.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Delete, Me.Edit})
        Me.DVadjustments.Location = New System.Drawing.Point(7, 35)
        Me.DVadjustments.Name = "DVadjustments"
        Me.DVadjustments.ReadOnly = True
        Me.DVadjustments.RowHeadersVisible = False
        Me.DVadjustments.Size = New System.Drawing.Size(462, 293)
        Me.DVadjustments.TabIndex = 98
        '
        'Delete
        '
        Me.Delete.HeaderText = "Remove"
        Me.Delete.Name = "Delete"
        Me.Delete.ReadOnly = True
        Me.Delete.Width = 50
        '
        'Edit
        '
        Me.Edit.HeaderText = "Edit"
        Me.Edit.Name = "Edit"
        Me.Edit.ReadOnly = True
        Me.Edit.Width = 50
        '
        'FrmWO
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(993, 615)
        Me.Controls.Add(Me.FlowLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "FrmWO"
        Me.Text = "Work Order"
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.PerformLayout()
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.DVCalls, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.DVissues, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.DVpayments, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        CType(Me.DVadjustments, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents FlowLayoutPanel1 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents BtnCustData As System.Windows.Forms.Button
    Friend WithEvents TxtBoatMake As System.Windows.Forms.TextBox
    Friend WithEvents TxtCity As System.Windows.Forms.TextBox
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents txtProv As System.Windows.Forms.TextBox
    Friend WithEvents Txtphone2 As System.Windows.Forms.TextBox
    Friend WithEvents txtphone1 As System.Windows.Forms.TextBox
    Friend WithEvents txtmotormodel As System.Windows.Forms.TextBox
    Friend WithEvents txtboatmodel As System.Windows.Forms.TextBox
    Friend WithEvents txtmotormake As System.Windows.Forms.TextBox
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents CalDateReqComp As System.Windows.Forms.MonthCalendar
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbPriority As System.Windows.Forms.ComboBox
    Friend WithEvents cmbStatus As System.Windows.Forms.ComboBox
    Friend WithEvents DateDropOff As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents DateDone As System.Windows.Forms.DateTimePicker
    Friend WithEvents btnLogCall As System.Windows.Forms.Button
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents DVCalls As System.Windows.Forms.DataGridView
    Friend WithEvents btnCompleted As System.Windows.Forms.Button
    Friend WithEvents BtnDropoff As System.Windows.Forms.Button
    Friend WithEvents txtWOnum As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents cmbstore As System.Windows.Forms.ComboBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents DateToBeDropped As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents DateReqComp As System.Windows.Forms.DateTimePicker
    Friend WithEvents btnviewbos As System.Windows.Forms.Button
    Friend WithEvents btnEditCust As System.Windows.Forms.Button
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtNotes As System.Windows.Forms.TextBox
    Friend WithEvents BtnAddIssue As System.Windows.Forms.Button
    Friend WithEvents DVissues As System.Windows.Forms.DataGridView
    Friend WithEvents btnCheckInNotes As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents View As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents Txtemail As System.Windows.Forms.TextBox
    Friend WithEvents txtpostal As System.Windows.Forms.TextBox
    Friend WithEvents txtmotorserial As System.Windows.Forms.TextBox
    Friend WithEvents txtBoatSerial As System.Windows.Forms.TextBox
    Friend WithEvents txttrailerserial As System.Windows.Forms.TextBox
    Friend WithEvents txttrailermodel As System.Windows.Forms.TextBox
    Friend WithEvents txtAddress As System.Windows.Forms.TextBox
    Friend WithEvents txttrailermake As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents DVpayments As System.Windows.Forms.DataGridView
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents txtbalance As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents txtpaid As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents txtbill As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents btnreadytogo As System.Windows.Forms.Button
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents txtbillpst As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents txtbillgst As System.Windows.Forms.TextBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents txtBillpretax As System.Windows.Forms.TextBox
    Friend WithEvents txtcolor As System.Windows.Forms.TextBox
    Friend WithEvents txtyear As System.Windows.Forms.TextBox
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents listpdiforms As System.Windows.Forms.ListBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents txtEnvirofee As System.Windows.Forms.TextBox
    Friend WithEvents CmbEnviro As System.Windows.Forms.ComboBox
    Friend WithEvents BtnRePrintCheckin As System.Windows.Forms.Button
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents txttotaladjustments As System.Windows.Forms.TextBox
    Friend WithEvents BtnAddAdjustment As System.Windows.Forms.Button
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents DVadjustments As System.Windows.Forms.DataGridView
    Friend WithEvents Delete As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents Edit As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents txttotaladjustment2 As System.Windows.Forms.TextBox
    Friend WithEvents btnReactivate As System.Windows.Forms.Button
    Friend WithEvents btnVoid As System.Windows.Forms.Button
    Friend WithEvents btnOrderParts As System.Windows.Forms.Button
    Friend WithEvents btnViewLogByCust As System.Windows.Forms.Button
    Friend WithEvents RI As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents View2 As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents txtWarnings As System.Windows.Forms.TextBox
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents btnCourtesyClean As System.Windows.Forms.Button
End Class
