﻿Module GlobalContstants

    Public Const shopSuppliesRate As Double = 0.08
    Public Const GSTRate As Double = 0.05
    Public Const PSTRate As Double = 0.07


End Module
