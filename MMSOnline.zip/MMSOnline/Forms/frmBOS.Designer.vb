<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBOS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.btnIAPWarranty = New System.Windows.Forms.Button()
        Me.btnBOprofitsheet = New System.Windows.Forms.Button()
        Me.btnPCLAuthorization = New System.Windows.Forms.Button()
        Me.btnInsuranceWaiver = New System.Windows.Forms.Button()
        Me.btnWarrantyWaiver = New System.Windows.Forms.Button()
        Me.btnTrailerBOS = New System.Windows.Forms.Button()
        Me.btnPCLForm = New System.Windows.Forms.Button()
        Me.btnPrintCAF = New System.Windows.Forms.Button()
        Me.btnATBprint = New System.Windows.Forms.Button()
        Me.btnUnlockBOS = New System.Windows.Forms.Button()
        Me.BtnProTech = New System.Windows.Forms.Button()
        Me.btnprintAT = New System.Windows.Forms.Button()
        Me.btnShowSoldBy = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnPrintSAL = New System.Windows.Forms.Button()
        Me.btnDetails = New System.Windows.Forms.Button()
        Me.btnPrintBOS = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.btnPrintCornerstone = New System.Windows.Forms.Button()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.Main = New System.Windows.Forms.TabPage()
        Me.Label119 = New System.Windows.Forms.Label()
        Me.lblFFee = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtskipkg = New System.Windows.Forms.TextBox()
        Me.Label120 = New System.Windows.Forms.Label()
        Me.txtDepDate = New System.Windows.Forms.TextBox()
        Me.txtDepNum = New System.Windows.Forms.TextBox()
        Me.txtDepAmount = New System.Windows.Forms.TextBox()
        Me.Tirestxt = New System.Windows.Forms.Label()
        Me.txttires = New System.Windows.Forms.TextBox()
        Me.txtb1atteries = New System.Windows.Forms.Label()
        Me.txtbatteries = New System.Windows.Forms.TextBox()
        Me.GroupBox17 = New System.Windows.Forms.GroupBox()
        Me.txtsmallitemcom = New System.Windows.Forms.TextBox()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.btnDoneComm = New System.Windows.Forms.Button()
        Me.txtcommrate8 = New System.Windows.Forms.TextBox()
        Me.txtcommrate7 = New System.Windows.Forms.TextBox()
        Me.txtcommrate6 = New System.Windows.Forms.TextBox()
        Me.txtcommrate5 = New System.Windows.Forms.TextBox()
        Me.txtcommrate4 = New System.Windows.Forms.TextBox()
        Me.txtcommrate3 = New System.Windows.Forms.TextBox()
        Me.txtcommrate2 = New System.Windows.Forms.TextBox()
        Me.txtcommrate1 = New System.Windows.Forms.TextBox()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.txtMiscComm = New System.Windows.Forms.TextBox()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.txtowing = New System.Windows.Forms.TextBox()
        Me.chkprotech = New System.Windows.Forms.CheckBox()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.txttradelein = New System.Windows.Forms.TextBox()
        Me.txtdatedeled = New System.Windows.Forms.TextBox()
        Me.ChkGST = New System.Windows.Forms.CheckBox()
        Me.chkPST = New System.Windows.Forms.CheckBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.btnReleaseBoat = New System.Windows.Forms.Button()
        Me.btnOrder = New System.Windows.Forms.Button()
        Me.txtp3date = New System.Windows.Forms.TextBox()
        Me.txtp2date = New System.Windows.Forms.TextBox()
        Me.txtp1date = New System.Windows.Forms.TextBox()
        Me.btnPickABoat = New System.Windows.Forms.Button()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtboatunit = New System.Windows.Forms.TextBox()
        Me.txtadminfee = New System.Windows.Forms.TextBox()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.txtpst = New System.Windows.Forms.TextBox()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtnotes1 = New System.Windows.Forms.TextBox()
        Me.txtp3num = New System.Windows.Forms.TextBox()
        Me.txtp2num = New System.Windows.Forms.TextBox()
        Me.txtp1num = New System.Windows.Forms.TextBox()
        Me.txtp3amount = New System.Windows.Forms.TextBox()
        Me.txtp2amount = New System.Windows.Forms.TextBox()
        Me.txtp1amount = New System.Windows.Forms.TextBox()
        Me.txto1 = New System.Windows.Forms.TextBox()
        Me.txto2 = New System.Windows.Forms.TextBox()
        Me.txto3 = New System.Windows.Forms.TextBox()
        Me.txto4 = New System.Windows.Forms.TextBox()
        Me.txto5 = New System.Windows.Forms.TextBox()
        Me.txto6 = New System.Windows.Forms.TextBox()
        Me.txto7 = New System.Windows.Forms.TextBox()
        Me.txto8 = New System.Windows.Forms.TextBox()
        Me.chkwinterize = New System.Windows.Forms.CheckBox()
        Me.Chk20hr = New System.Windows.Forms.CheckBox()
        Me.chkextwarranty = New System.Windows.Forms.CheckBox()
        Me.chkantitheftreg = New System.Windows.Forms.CheckBox()
        Me.chklockpkg = New System.Windows.Forms.CheckBox()
        Me.chksafepkg = New System.Windows.Forms.CheckBox()
        Me.chksprop = New System.Windows.Forms.CheckBox()
        Me.chkrockg = New System.Windows.Forms.CheckBox()
        Me.chkskipkg = New System.Windows.Forms.CheckBox()
        Me.chkcover = New System.Windows.Forms.CheckBox()
        Me.chkstire = New System.Windows.Forms.CheckBox()
        Me.txto5price = New System.Windows.Forms.TextBox()
        Me.txto4price = New System.Windows.Forms.TextBox()
        Me.txto3price = New System.Windows.Forms.TextBox()
        Me.txto6price = New System.Windows.Forms.TextBox()
        Me.txto2price = New System.Windows.Forms.TextBox()
        Me.txto8price = New System.Windows.Forms.TextBox()
        Me.txto1price = New System.Windows.Forms.TextBox()
        Me.txtlockpkgprice = New System.Windows.Forms.TextBox()
        Me.txtsafepkgprice = New System.Windows.Forms.TextBox()
        Me.txtspropprice = New System.Windows.Forms.TextBox()
        Me.txtrockgprice = New System.Windows.Forms.TextBox()
        Me.txtskipkgprice = New System.Windows.Forms.TextBox()
        Me.txtcoverprice = New System.Windows.Forms.TextBox()
        Me.txto7price = New System.Windows.Forms.TextBox()
        Me.txtstireprice = New System.Windows.Forms.TextBox()
        Me.txttotal = New System.Windows.Forms.TextBox()
        Me.txtgst = New System.Windows.Forms.TextBox()
        Me.txtsubtotal = New System.Windows.Forms.TextBox()
        Me.txttrade = New System.Windows.Forms.TextBox()
        Me.txtpackagetotal = New System.Windows.Forms.TextBox()
        Me.txtoptionstotal = New System.Windows.Forms.TextBox()
        Me.txtwinterize = New System.Windows.Forms.TextBox()
        Me.txt20hr = New System.Windows.Forms.TextBox()
        Me.txtextwarranty = New System.Windows.Forms.TextBox()
        Me.txtprotech = New System.Windows.Forms.TextBox()
        Me.txtantitheftreg = New System.Windows.Forms.TextBox()
        Me.txttiretax = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtdiscountprice = New System.Windows.Forms.TextBox()
        Me.txtdiscount = New System.Windows.Forms.TextBox()
        Me.txtkickerprice = New System.Windows.Forms.TextBox()
        Me.txtkickeryear = New System.Windows.Forms.TextBox()
        Me.txtkickerserial = New System.Windows.Forms.TextBox()
        Me.txtkickermodel = New System.Windows.Forms.TextBox()
        Me.txtkickermake = New System.Windows.Forms.TextBox()
        Me.txttplateprice = New System.Windows.Forms.TextBox()
        Me.txttplateyear = New System.Windows.Forms.TextBox()
        Me.txttplateserial = New System.Windows.Forms.TextBox()
        Me.txttplatemodel = New System.Windows.Forms.TextBox()
        Me.txttplatemake = New System.Windows.Forms.TextBox()
        Me.txtdriveprice = New System.Windows.Forms.TextBox()
        Me.txtdriveyear = New System.Windows.Forms.TextBox()
        Me.txtdriveserial = New System.Windows.Forms.TextBox()
        Me.txtdrivemodel = New System.Windows.Forms.TextBox()
        Me.txtdrivemake = New System.Windows.Forms.TextBox()
        Me.txttrailerprice = New System.Windows.Forms.TextBox()
        Me.txttraileryear = New System.Windows.Forms.TextBox()
        Me.txttrailerserial = New System.Windows.Forms.TextBox()
        Me.txttrailermodel = New System.Windows.Forms.TextBox()
        Me.txttrailermake = New System.Windows.Forms.TextBox()
        Me.txtmotorprice = New System.Windows.Forms.TextBox()
        Me.txtmotoryear = New System.Windows.Forms.TextBox()
        Me.txtmotorserial = New System.Windows.Forms.TextBox()
        Me.txtmotormodel = New System.Windows.Forms.TextBox()
        Me.txtmotormake = New System.Windows.Forms.TextBox()
        Me.txtboatprice = New System.Windows.Forms.TextBox()
        Me.txtboatyear = New System.Windows.Forms.TextBox()
        Me.txtboathin = New System.Windows.Forms.TextBox()
        Me.txtboatmodel = New System.Windows.Forms.TextBox()
        Me.txtboatmake = New System.Windows.Forms.TextBox()
        Me.txtcolor = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtprov = New System.Windows.Forms.TextBox()
        Me.txtpostal = New System.Windows.Forms.TextBox()
        Me.txtcity = New System.Windows.Forms.TextBox()
        Me.txtemail = New System.Windows.Forms.TextBox()
        Me.txtwork = New System.Windows.Forms.TextBox()
        Me.txthome = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtaddress = New System.Windows.Forms.TextBox()
        Me.txtbuyer1last = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtbuyer1first = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtbuyer2last = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtbuyer2first = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.DateSold = New System.Windows.Forms.DateTimePicker()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtBOS = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.txtRedNoGST = New System.Windows.Forms.Label()
        Me.txtrednopst = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.pnReq1 = New System.Windows.Forms.Panel()
        Me.pnReq2 = New System.Windows.Forms.Panel()
        Me.Sales = New System.Windows.Forms.TabPage()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.GroupBox21 = New System.Windows.Forms.GroupBox()
        Me.DVCalls = New System.Windows.Forms.DataGridView()
        Me.View = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.btnLogACall = New System.Windows.Forms.Button()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.txtatnum = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.DateTimeWO = New System.Windows.Forms.DateTimePicker()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.btnPrintWO = New System.Windows.Forms.Button()
        Me.txtwotext = New System.Windows.Forms.TextBox()
        Me.CmbShopStatus = New System.Windows.Forms.ComboBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.txtBOcommadjust = New System.Windows.Forms.TextBox()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.txtBOcommadjustnote = New System.Windows.Forms.TextBox()
        Me.txtcommchange2 = New System.Windows.Forms.TextBox()
        Me.txtcommchange1 = New System.Windows.Forms.TextBox()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.txtchange2note = New System.Windows.Forms.TextBox()
        Me.txtchange1note = New System.Windows.Forms.TextBox()
        Me.btnChangeSalesman = New System.Windows.Forms.Button()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.btnSplitDeal = New System.Windows.Forms.Button()
        Me.txtsalesman2 = New System.Windows.Forms.TextBox()
        Me.txtsalesman = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.rfin = New System.Windows.Forms.RadioButton()
        Me.rcash = New System.Windows.Forms.RadioButton()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.cmbCommissioned = New System.Windows.Forms.ComboBox()
        Me.btnDelivered = New System.Windows.Forms.Button()
        Me.btnVoid = New System.Windows.Forms.Button()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.cmbFinanceStatus = New System.Windows.Forms.ComboBox()
        Me.cmbDealStatus = New System.Windows.Forms.ComboBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.txthiddenfincode = New System.Windows.Forms.TextBox()
        Me.txtinssold = New System.Windows.Forms.TextBox()
        Me.runins = New System.Windows.Forms.RadioButton()
        Me.rins = New System.Windows.Forms.RadioButton()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.txtnotes = New System.Windows.Forms.TextBox()
        Me.GroupBox18 = New System.Windows.Forms.GroupBox()
        Me.txtwodate = New System.Windows.Forms.TextBox()
        Me.txtwostatus = New System.Windows.Forms.TextBox()
        Me.Label97 = New System.Windows.Forms.Label()
        Me.Label98 = New System.Windows.Forms.Label()
        Me.btnCreateWO = New System.Windows.Forms.Button()
        Me.txtwostore = New System.Windows.Forms.TextBox()
        Me.txtwonumber = New System.Windows.Forms.TextBox()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.Label96 = New System.Windows.Forms.Label()
        Me.Finance = New System.Windows.Forms.TabPage()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label104 = New System.Windows.Forms.Label()
        Me.txttotalfin = New System.Windows.Forms.TextBox()
        Me.Label102 = New System.Windows.Forms.Label()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.txtfinancefee = New System.Windows.Forms.TextBox()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.txtBankFee = New System.Windows.Forms.TextBox()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.txtreserve = New System.Windows.Forms.TextBox()
        Me.txtammover = New System.Windows.Forms.TextBox()
        Me.txtrateover = New System.Windows.Forms.TextBox()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.cmbrate = New System.Windows.Forms.ComboBox()
        Me.cmbammort = New System.Windows.Forms.ComboBox()
        Me.cmbTerm = New System.Windows.Forms.ComboBox()
        Me.ListBanks = New System.Windows.Forms.ListBox()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.txtbizman = New System.Windows.Forms.TextBox()
        Me.btnBizmanChange = New System.Windows.Forms.Button()
        Me.Label103 = New System.Windows.Forms.Label()
        Me.txtbolien = New System.Windows.Forms.TextBox()
        Me.btnTradeLienCTC = New System.Windows.Forms.Button()
        Me.btnTradeInCTC = New System.Windows.Forms.Button()
        Me.txtbowarranty = New System.Windows.Forms.TextBox()
        Me.txtbotrade = New System.Windows.Forms.TextBox()
        Me.btnWarrantyCTC = New System.Windows.Forms.Button()
        Me.Label100 = New System.Windows.Forms.Label()
        Me.Label99 = New System.Windows.Forms.Label()
        Me.txtbocashprice = New System.Windows.Forms.TextBox()
        Me.btnCashPriceCTC = New System.Windows.Forms.Button()
        Me.btnDownPmtCTC = New System.Windows.Forms.Button()
        Me.btnPrintInsRequest = New System.Windows.Forms.Button()
        Me.Label101 = New System.Windows.Forms.Label()
        Me.GroupBox16 = New System.Windows.Forms.GroupBox()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.CmbPTinstalled = New System.Windows.Forms.ComboBox()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.CmbPTreg = New System.Windows.Forms.ComboBox()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.CmbPTrtb = New System.Windows.Forms.ComboBox()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.txtPTcost = New System.Windows.Forms.TextBox()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.CmbPTfabric = New System.Windows.Forms.ComboBox()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.GroupBox20 = New System.Windows.Forms.GroupBox()
        Me.btnAPCopyToClip = New System.Windows.Forms.Button()
        Me.Label118 = New System.Windows.Forms.Label()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.btnCICopyToClip = New System.Windows.Forms.Button()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.GroupBox13 = New System.Windows.Forms.GroupBox()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.txtbday1 = New System.Windows.Forms.TextBox()
        Me.txtbday2 = New System.Windows.Forms.TextBox()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.btnASCopyToClip = New System.Windows.Forms.Button()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.btnLICopyToClip = New System.Windows.Forms.Button()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.cmbAccidentalPlus = New System.Windows.Forms.ComboBox()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.cmbahtype = New System.Windows.Forms.ComboBox()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.cmbcins = New System.Windows.Forms.ComboBox()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.cmbains = New System.Windows.Forms.ComboBox()
        Me.cmblins = New System.Windows.Forms.ComboBox()
        Me.Label117 = New System.Windows.Forms.Label()
        Me.GroupBox15 = New System.Windows.Forms.GroupBox()
        Me.txtfinnotes = New System.Windows.Forms.TextBox()
        Me.txtbodown = New System.Windows.Forms.TextBox()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.GroupBox19 = New System.Windows.Forms.GroupBox()
        Me.IAPseals = New System.Windows.Forms.CheckBox()
        Me.IAPaftersale = New System.Windows.Forms.CheckBox()
        Me.Label109 = New System.Windows.Forms.Label()
        Me.IAPgpr = New System.Windows.Forms.CheckBox()
        Me.IAPextWarranty = New System.Windows.Forms.TextBox()
        Me.Label116 = New System.Windows.Forms.Label()
        Me.Label110 = New System.Windows.Forms.Label()
        Me.Label115 = New System.Windows.Forms.Label()
        Me.IAPdeduct = New System.Windows.Forms.ComboBox()
        Me.IAPoemWarranty = New System.Windows.Forms.TextBox()
        Me.Label111 = New System.Windows.Forms.Label()
        Me.Label114 = New System.Windows.Forms.Label()
        Me.IAPfuel = New System.Windows.Forms.ComboBox()
        Me.IAPproduct = New System.Windows.Forms.ComboBox()
        Me.Label112 = New System.Windows.Forms.Label()
        Me.IAPdelDATE = New System.Windows.Forms.DateTimePicker()
        Me.IAPused = New System.Windows.Forms.CheckBox()
        Me.Label113 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.txtwarrcost = New System.Windows.Forms.TextBox()
        Me.btnShorelandWarr = New System.Windows.Forms.Button()
        Me.btnSylWarr = New System.Windows.Forms.Button()
        Me.GroupBox14 = New System.Windows.Forms.GroupBox()
        Me.chkfakedate = New System.Windows.Forms.CheckBox()
        Me.chkcstwinprop = New System.Windows.Forms.CheckBox()
        Me.chkcsOpti = New System.Windows.Forms.CheckBox()
        Me.Label108 = New System.Windows.Forms.Label()
        Me.Label107 = New System.Windows.Forms.Label()
        Me.cmbcsdeduct = New System.Windows.Forms.ComboBox()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.cmbcsfuel = New System.Windows.Forms.ComboBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.chkusedwarranty = New System.Windows.Forms.CheckBox()
        Me.btnPrintReminder = New System.Windows.Forms.Button()
        Me.Label105 = New System.Windows.Forms.Label()
        Me.DateWarrantystart = New System.Windows.Forms.DateTimePicker()
        Me.cmbcstype = New System.Windows.Forms.ComboBox()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.cmbGPR = New System.Windows.Forms.ComboBox()
        Me.CSmanwarr = New System.Windows.Forms.TextBox()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.CSextwarr = New System.Windows.Forms.TextBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.StatusStrip1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.Main.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.GroupBox17.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Sales.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.GroupBox21.SuspendLayout()
        CType(Me.DVCalls, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox18.SuspendLayout()
        Me.Finance.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox16.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox20.SuspendLayout()
        Me.GroupBox12.SuspendLayout()
        Me.GroupBox13.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox15.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox19.SuspendLayout()
        Me.GroupBox14.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.IsSplitterFixed = True
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.BackgroundImage = Global.MMSOnline.My.Resources.Resources.BkgTL
        Me.SplitContainer1.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnIAPWarranty)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnBOprofitsheet)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnPCLAuthorization)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnInsuranceWaiver)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnWarrantyWaiver)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnTrailerBOS)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnPCLForm)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnPrintCAF)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnATBprint)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnUnlockBOS)
        Me.SplitContainer1.Panel1.Controls.Add(Me.BtnProTech)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnprintAT)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnShowSoldBy)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnSave)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnPrintSAL)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnDetails)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnPrintBOS)
        Me.SplitContainer1.Panel1.Controls.Add(Me.PictureBox1)
        Me.SplitContainer1.Panel1.Controls.Add(Me.StatusStrip1)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnPrintCornerstone)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.AutoScroll = True
        Me.SplitContainer1.Panel2.BackColor = System.Drawing.Color.White
        Me.SplitContainer1.Panel2.Controls.Add(Me.TabControl1)
        Me.SplitContainer1.Panel2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SplitContainer1.Size = New System.Drawing.Size(958, 1023)
        Me.SplitContainer1.SplitterDistance = 150
        Me.SplitContainer1.SplitterWidth = 1
        Me.SplitContainer1.TabIndex = 0
        '
        'btnIAPWarranty
        '
        Me.btnIAPWarranty.Location = New System.Drawing.Point(23, 136)
        Me.btnIAPWarranty.Name = "btnIAPWarranty"
        Me.btnIAPWarranty.Size = New System.Drawing.Size(105, 23)
        Me.btnIAPWarranty.TabIndex = 3
        Me.btnIAPWarranty.Text = "Print IAP Warranty"
        Me.btnIAPWarranty.UseVisualStyleBackColor = True
        '
        'btnBOprofitsheet
        '
        Me.btnBOprofitsheet.Location = New System.Drawing.Point(23, 455)
        Me.btnBOprofitsheet.Name = "btnBOprofitsheet"
        Me.btnBOprofitsheet.Size = New System.Drawing.Size(105, 23)
        Me.btnBOprofitsheet.TabIndex = 15
        Me.btnBOprofitsheet.Text = "Print Profit Sheet"
        Me.btnBOprofitsheet.UseVisualStyleBackColor = True
        Me.btnBOprofitsheet.Visible = False
        '
        'btnPCLAuthorization
        '
        Me.btnPCLAuthorization.Location = New System.Drawing.Point(23, 397)
        Me.btnPCLAuthorization.Name = "btnPCLAuthorization"
        Me.btnPCLAuthorization.Size = New System.Drawing.Size(105, 23)
        Me.btnPCLAuthorization.TabIndex = 12
        Me.btnPCLAuthorization.Text = "PCL Authorization"
        Me.btnPCLAuthorization.UseVisualStyleBackColor = True
        '
        'btnInsuranceWaiver
        '
        Me.btnInsuranceWaiver.Location = New System.Drawing.Point(23, 281)
        Me.btnInsuranceWaiver.Name = "btnInsuranceWaiver"
        Me.btnInsuranceWaiver.Size = New System.Drawing.Size(105, 23)
        Me.btnInsuranceWaiver.TabIndex = 8
        Me.btnInsuranceWaiver.Text = "Insurance Waiver"
        Me.btnInsuranceWaiver.UseVisualStyleBackColor = True
        '
        'btnWarrantyWaiver
        '
        Me.btnWarrantyWaiver.Location = New System.Drawing.Point(23, 165)
        Me.btnWarrantyWaiver.Name = "btnWarrantyWaiver"
        Me.btnWarrantyWaiver.Size = New System.Drawing.Size(105, 23)
        Me.btnWarrantyWaiver.TabIndex = 4
        Me.btnWarrantyWaiver.Text = "Warranty Waiver"
        Me.btnWarrantyWaiver.UseVisualStyleBackColor = True
        '
        'btnTrailerBOS
        '
        Me.btnTrailerBOS.Location = New System.Drawing.Point(23, 426)
        Me.btnTrailerBOS.Name = "btnTrailerBOS"
        Me.btnTrailerBOS.Size = New System.Drawing.Size(105, 23)
        Me.btnTrailerBOS.TabIndex = 13
        Me.btnTrailerBOS.Text = "Trailer BOS"
        Me.btnTrailerBOS.UseVisualStyleBackColor = True
        '
        'btnPCLForm
        '
        Me.btnPCLForm.Location = New System.Drawing.Point(23, 368)
        Me.btnPCLForm.Name = "btnPCLForm"
        Me.btnPCLForm.Size = New System.Drawing.Size(105, 23)
        Me.btnPCLForm.TabIndex = 11
        Me.btnPCLForm.Text = "PCL Form"
        Me.btnPCLForm.UseVisualStyleBackColor = True
        '
        'btnPrintCAF
        '
        Me.btnPrintCAF.Location = New System.Drawing.Point(23, 339)
        Me.btnPrintCAF.Name = "btnPrintCAF"
        Me.btnPrintCAF.Size = New System.Drawing.Size(105, 23)
        Me.btnPrintCAF.TabIndex = 10
        Me.btnPrintCAF.Text = "Acceptance Form"
        Me.btnPrintCAF.UseVisualStyleBackColor = True
        '
        'btnATBprint
        '
        Me.btnATBprint.Location = New System.Drawing.Point(23, 310)
        Me.btnATBprint.Name = "btnATBprint"
        Me.btnATBprint.Size = New System.Drawing.Size(105, 23)
        Me.btnATBprint.TabIndex = 9
        Me.btnATBprint.Text = "Print ATB"
        Me.btnATBprint.UseVisualStyleBackColor = True
        '
        'btnUnlockBOS
        '
        Me.btnUnlockBOS.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnUnlockBOS.Location = New System.Drawing.Point(23, 962)
        Me.btnUnlockBOS.Name = "btnUnlockBOS"
        Me.btnUnlockBOS.Size = New System.Drawing.Size(93, 23)
        Me.btnUnlockBOS.TabIndex = 17
        Me.btnUnlockBOS.Text = "Unlock BOS"
        Me.btnUnlockBOS.UseVisualStyleBackColor = True
        Me.btnUnlockBOS.Visible = False
        '
        'BtnProTech
        '
        Me.BtnProTech.Location = New System.Drawing.Point(23, 223)
        Me.BtnProTech.Name = "BtnProTech"
        Me.BtnProTech.Size = New System.Drawing.Size(105, 23)
        Me.BtnProTech.TabIndex = 6
        Me.BtnProTech.Text = "Print Pro-Tech"
        Me.BtnProTech.UseVisualStyleBackColor = True
        '
        'btnprintAT
        '
        Me.btnprintAT.Location = New System.Drawing.Point(23, 194)
        Me.btnprintAT.Name = "btnprintAT"
        Me.btnprintAT.Size = New System.Drawing.Size(105, 23)
        Me.btnprintAT.TabIndex = 5
        Me.btnprintAT.Text = "Print Anti-theft"
        Me.btnprintAT.UseVisualStyleBackColor = True
        '
        'btnShowSoldBy
        '
        Me.btnShowSoldBy.Location = New System.Drawing.Point(23, 484)
        Me.btnShowSoldBy.Name = "btnShowSoldBy"
        Me.btnShowSoldBy.Size = New System.Drawing.Size(105, 23)
        Me.btnShowSoldBy.TabIndex = 14
        Me.btnShowSoldBy.Text = "Show Sold By"
        Me.btnShowSoldBy.UseVisualStyleBackColor = True
        Me.btnShowSoldBy.Visible = False
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(23, 790)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(93, 23)
        Me.btnSave.TabIndex = 16
        Me.btnSave.Text = "Save Changes"
        Me.btnSave.UseVisualStyleBackColor = True
        Me.btnSave.Visible = False
        '
        'btnPrintSAL
        '
        Me.btnPrintSAL.Location = New System.Drawing.Point(23, 252)
        Me.btnPrintSAL.Name = "btnPrintSAL"
        Me.btnPrintSAL.Size = New System.Drawing.Size(105, 23)
        Me.btnPrintSAL.TabIndex = 7
        Me.btnPrintSAL.Text = "Print SAL"
        Me.btnPrintSAL.UseVisualStyleBackColor = True
        '
        'btnDetails
        '
        Me.btnDetails.Location = New System.Drawing.Point(23, 49)
        Me.btnDetails.Name = "btnDetails"
        Me.btnDetails.Size = New System.Drawing.Size(105, 23)
        Me.btnDetails.TabIndex = 0
        Me.btnDetails.Text = "Boat Details"
        Me.btnDetails.UseVisualStyleBackColor = True
        '
        'btnPrintBOS
        '
        Me.btnPrintBOS.Location = New System.Drawing.Point(23, 78)
        Me.btnPrintBOS.Name = "btnPrintBOS"
        Me.btnPrintBOS.Size = New System.Drawing.Size(105, 23)
        Me.btnPrintBOS.TabIndex = 1
        Me.btnPrintBOS.Text = "Print BOS"
        Me.btnPrintBOS.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = Global.MMSOnline.My.Resources.Resources.MMSOnline
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(23, -16)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(150, 73)
        Me.PictureBox1.TabIndex = 15
        Me.PictureBox1.TabStop = False
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 1001)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(150, 22)
        Me.StatusStrip1.TabIndex = 5
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(0, 17)
        '
        'btnPrintCornerstone
        '
        Me.btnPrintCornerstone.Location = New System.Drawing.Point(23, 107)
        Me.btnPrintCornerstone.Name = "btnPrintCornerstone"
        Me.btnPrintCornerstone.Size = New System.Drawing.Size(105, 23)
        Me.btnPrintCornerstone.TabIndex = 2
        Me.btnPrintCornerstone.Text = "Print Cornerstone Contract"
        Me.btnPrintCornerstone.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.Main)
        Me.TabControl1.Controls.Add(Me.Sales)
        Me.TabControl1.Controls.Add(Me.Finance)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(807, 1023)
        Me.TabControl1.TabIndex = 0
        '
        'Main
        '
        Me.Main.AutoScroll = True
        Me.Main.Controls.Add(Me.Label119)
        Me.Main.Controls.Add(Me.lblFFee)
        Me.Main.Controls.Add(Me.Panel1)
        Me.Main.Location = New System.Drawing.Point(4, 25)
        Me.Main.Margin = New System.Windows.Forms.Padding(0)
        Me.Main.Name = "Main"
        Me.Main.Size = New System.Drawing.Size(799, 994)
        Me.Main.TabIndex = 0
        Me.Main.Text = "Purchase Information"
        Me.Main.UseVisualStyleBackColor = True
        '
        'Label119
        '
        Me.Label119.Location = New System.Drawing.Point(622, 466)
        Me.Label119.Name = "Label119"
        Me.Label119.Size = New System.Drawing.Size(61, 22)
        Me.Label119.TabIndex = 15
        Me.Label119.Text = "Fin Fee :"
        Me.Label119.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFFee
        '
        Me.lblFFee.Location = New System.Drawing.Point(684, 466)
        Me.lblFFee.Name = "lblFFee"
        Me.lblFFee.Size = New System.Drawing.Size(95, 22)
        Me.lblFFee.TabIndex = 14
        Me.lblFFee.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.txtskipkg)
        Me.Panel1.Controls.Add(Me.Label120)
        Me.Panel1.Controls.Add(Me.txtDepDate)
        Me.Panel1.Controls.Add(Me.txtDepNum)
        Me.Panel1.Controls.Add(Me.txtDepAmount)
        Me.Panel1.Controls.Add(Me.Tirestxt)
        Me.Panel1.Controls.Add(Me.txttires)
        Me.Panel1.Controls.Add(Me.txtb1atteries)
        Me.Panel1.Controls.Add(Me.txtbatteries)
        Me.Panel1.Controls.Add(Me.GroupBox17)
        Me.Panel1.Controls.Add(Me.btnDoneComm)
        Me.Panel1.Controls.Add(Me.txtcommrate8)
        Me.Panel1.Controls.Add(Me.txtcommrate7)
        Me.Panel1.Controls.Add(Me.txtcommrate6)
        Me.Panel1.Controls.Add(Me.txtcommrate5)
        Me.Panel1.Controls.Add(Me.txtcommrate4)
        Me.Panel1.Controls.Add(Me.txtcommrate3)
        Me.Panel1.Controls.Add(Me.txtcommrate2)
        Me.Panel1.Controls.Add(Me.txtcommrate1)
        Me.Panel1.Controls.Add(Me.Label88)
        Me.Panel1.Controls.Add(Me.txtMiscComm)
        Me.Panel1.Controls.Add(Me.Label87)
        Me.Panel1.Controls.Add(Me.Label71)
        Me.Panel1.Controls.Add(Me.txtowing)
        Me.Panel1.Controls.Add(Me.chkprotech)
        Me.Panel1.Controls.Add(Me.Label79)
        Me.Panel1.Controls.Add(Me.txttradelein)
        Me.Panel1.Controls.Add(Me.txtdatedeled)
        Me.Panel1.Controls.Add(Me.ChkGST)
        Me.Panel1.Controls.Add(Me.chkPST)
        Me.Panel1.Controls.Add(Me.PictureBox3)
        Me.Panel1.Controls.Add(Me.PictureBox2)
        Me.Panel1.Controls.Add(Me.btnReleaseBoat)
        Me.Panel1.Controls.Add(Me.btnOrder)
        Me.Panel1.Controls.Add(Me.txtp3date)
        Me.Panel1.Controls.Add(Me.txtp2date)
        Me.Panel1.Controls.Add(Me.txtp1date)
        Me.Panel1.Controls.Add(Me.btnPickABoat)
        Me.Panel1.Controls.Add(Me.Label48)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.txtboatunit)
        Me.Panel1.Controls.Add(Me.txtadminfee)
        Me.Panel1.Controls.Add(Me.Label47)
        Me.Panel1.Controls.Add(Me.txtpst)
        Me.Panel1.Controls.Add(Me.Label46)
        Me.Panel1.Controls.Add(Me.Label45)
        Me.Panel1.Controls.Add(Me.Label43)
        Me.Panel1.Controls.Add(Me.Label44)
        Me.Panel1.Controls.Add(Me.Label41)
        Me.Panel1.Controls.Add(Me.Label42)
        Me.Panel1.Controls.Add(Me.Label40)
        Me.Panel1.Controls.Add(Me.Label32)
        Me.Panel1.Controls.Add(Me.Label33)
        Me.Panel1.Controls.Add(Me.Label34)
        Me.Panel1.Controls.Add(Me.Label35)
        Me.Panel1.Controls.Add(Me.Label36)
        Me.Panel1.Controls.Add(Me.Label37)
        Me.Panel1.Controls.Add(Me.Label38)
        Me.Panel1.Controls.Add(Me.Label31)
        Me.Panel1.Controls.Add(Me.Label30)
        Me.Panel1.Controls.Add(Me.Label29)
        Me.Panel1.Controls.Add(Me.Label28)
        Me.Panel1.Controls.Add(Me.Label27)
        Me.Panel1.Controls.Add(Me.Label26)
        Me.Panel1.Controls.Add(Me.Label25)
        Me.Panel1.Controls.Add(Me.Label24)
        Me.Panel1.Controls.Add(Me.Label23)
        Me.Panel1.Controls.Add(Me.Label22)
        Me.Panel1.Controls.Add(Me.Label21)
        Me.Panel1.Controls.Add(Me.txtnotes1)
        Me.Panel1.Controls.Add(Me.txtp3num)
        Me.Panel1.Controls.Add(Me.txtp2num)
        Me.Panel1.Controls.Add(Me.txtp1num)
        Me.Panel1.Controls.Add(Me.txtp3amount)
        Me.Panel1.Controls.Add(Me.txtp2amount)
        Me.Panel1.Controls.Add(Me.txtp1amount)
        Me.Panel1.Controls.Add(Me.txto1)
        Me.Panel1.Controls.Add(Me.txto2)
        Me.Panel1.Controls.Add(Me.txto3)
        Me.Panel1.Controls.Add(Me.txto4)
        Me.Panel1.Controls.Add(Me.txto5)
        Me.Panel1.Controls.Add(Me.txto6)
        Me.Panel1.Controls.Add(Me.txto7)
        Me.Panel1.Controls.Add(Me.txto8)
        Me.Panel1.Controls.Add(Me.chkwinterize)
        Me.Panel1.Controls.Add(Me.Chk20hr)
        Me.Panel1.Controls.Add(Me.chkextwarranty)
        Me.Panel1.Controls.Add(Me.chkantitheftreg)
        Me.Panel1.Controls.Add(Me.chklockpkg)
        Me.Panel1.Controls.Add(Me.chksafepkg)
        Me.Panel1.Controls.Add(Me.chksprop)
        Me.Panel1.Controls.Add(Me.chkrockg)
        Me.Panel1.Controls.Add(Me.chkskipkg)
        Me.Panel1.Controls.Add(Me.chkcover)
        Me.Panel1.Controls.Add(Me.chkstire)
        Me.Panel1.Controls.Add(Me.txto5price)
        Me.Panel1.Controls.Add(Me.txto4price)
        Me.Panel1.Controls.Add(Me.txto3price)
        Me.Panel1.Controls.Add(Me.txto6price)
        Me.Panel1.Controls.Add(Me.txto2price)
        Me.Panel1.Controls.Add(Me.txto8price)
        Me.Panel1.Controls.Add(Me.txto1price)
        Me.Panel1.Controls.Add(Me.txtlockpkgprice)
        Me.Panel1.Controls.Add(Me.txtsafepkgprice)
        Me.Panel1.Controls.Add(Me.txtspropprice)
        Me.Panel1.Controls.Add(Me.txtrockgprice)
        Me.Panel1.Controls.Add(Me.txtskipkgprice)
        Me.Panel1.Controls.Add(Me.txtcoverprice)
        Me.Panel1.Controls.Add(Me.txto7price)
        Me.Panel1.Controls.Add(Me.txtstireprice)
        Me.Panel1.Controls.Add(Me.txttotal)
        Me.Panel1.Controls.Add(Me.txtgst)
        Me.Panel1.Controls.Add(Me.txtsubtotal)
        Me.Panel1.Controls.Add(Me.txttrade)
        Me.Panel1.Controls.Add(Me.txtpackagetotal)
        Me.Panel1.Controls.Add(Me.txtoptionstotal)
        Me.Panel1.Controls.Add(Me.txtwinterize)
        Me.Panel1.Controls.Add(Me.txt20hr)
        Me.Panel1.Controls.Add(Me.txtextwarranty)
        Me.Panel1.Controls.Add(Me.txtprotech)
        Me.Panel1.Controls.Add(Me.txtantitheftreg)
        Me.Panel1.Controls.Add(Me.txttiretax)
        Me.Panel1.Controls.Add(Me.Label20)
        Me.Panel1.Controls.Add(Me.Label19)
        Me.Panel1.Controls.Add(Me.Label18)
        Me.Panel1.Controls.Add(Me.Label17)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.txtdiscountprice)
        Me.Panel1.Controls.Add(Me.txtdiscount)
        Me.Panel1.Controls.Add(Me.txtkickerprice)
        Me.Panel1.Controls.Add(Me.txtkickeryear)
        Me.Panel1.Controls.Add(Me.txtkickerserial)
        Me.Panel1.Controls.Add(Me.txtkickermodel)
        Me.Panel1.Controls.Add(Me.txtkickermake)
        Me.Panel1.Controls.Add(Me.txttplateprice)
        Me.Panel1.Controls.Add(Me.txttplateyear)
        Me.Panel1.Controls.Add(Me.txttplateserial)
        Me.Panel1.Controls.Add(Me.txttplatemodel)
        Me.Panel1.Controls.Add(Me.txttplatemake)
        Me.Panel1.Controls.Add(Me.txtdriveprice)
        Me.Panel1.Controls.Add(Me.txtdriveyear)
        Me.Panel1.Controls.Add(Me.txtdriveserial)
        Me.Panel1.Controls.Add(Me.txtdrivemodel)
        Me.Panel1.Controls.Add(Me.txtdrivemake)
        Me.Panel1.Controls.Add(Me.txttrailerprice)
        Me.Panel1.Controls.Add(Me.txttraileryear)
        Me.Panel1.Controls.Add(Me.txttrailerserial)
        Me.Panel1.Controls.Add(Me.txttrailermodel)
        Me.Panel1.Controls.Add(Me.txttrailermake)
        Me.Panel1.Controls.Add(Me.txtmotorprice)
        Me.Panel1.Controls.Add(Me.txtmotoryear)
        Me.Panel1.Controls.Add(Me.txtmotorserial)
        Me.Panel1.Controls.Add(Me.txtmotormodel)
        Me.Panel1.Controls.Add(Me.txtmotormake)
        Me.Panel1.Controls.Add(Me.txtboatprice)
        Me.Panel1.Controls.Add(Me.txtboatyear)
        Me.Panel1.Controls.Add(Me.txtboathin)
        Me.Panel1.Controls.Add(Me.txtboatmodel)
        Me.Panel1.Controls.Add(Me.txtboatmake)
        Me.Panel1.Controls.Add(Me.txtcolor)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.txtprov)
        Me.Panel1.Controls.Add(Me.txtpostal)
        Me.Panel1.Controls.Add(Me.txtcity)
        Me.Panel1.Controls.Add(Me.txtemail)
        Me.Panel1.Controls.Add(Me.txtwork)
        Me.Panel1.Controls.Add(Me.txthome)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.txtaddress)
        Me.Panel1.Controls.Add(Me.txtbuyer1last)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.txtbuyer1first)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.txtbuyer2last)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.txtbuyer2first)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.DateSold)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.txtBOS)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Label73)
        Me.Panel1.Controls.Add(Me.Panel6)
        Me.Panel1.Controls.Add(Me.txtRedNoGST)
        Me.Panel1.Controls.Add(Me.txtrednopst)
        Me.Panel1.Controls.Add(Me.Panel7)
        Me.Panel1.Controls.Add(Me.Panel8)
        Me.Panel1.Controls.Add(Me.Panel9)
        Me.Panel1.Controls.Add(Me.pnReq1)
        Me.Panel1.Controls.Add(Me.pnReq2)
        Me.Panel1.Location = New System.Drawing.Point(-2, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(618, 1066)
        Me.Panel1.TabIndex = 13
        '
        'txtskipkg
        '
        Me.txtskipkg.Location = New System.Drawing.Point(158, 661)
        Me.txtskipkg.Name = "txtskipkg"
        Me.txtskipkg.Size = New System.Drawing.Size(45, 22)
        Me.txtskipkg.TabIndex = 15
        '
        'Label120
        '
        Me.Label120.AutoSize = True
        Me.Label120.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label120.Location = New System.Drawing.Point(320, 961)
        Me.Label120.Name = "Label120"
        Me.Label120.Size = New System.Drawing.Size(49, 14)
        Me.Label120.TabIndex = 200
        Me.Label120.Text = "Deposit"
        '
        'txtDepDate
        '
        Me.txtDepDate.Enabled = False
        Me.txtDepDate.Location = New System.Drawing.Point(469, 956)
        Me.txtDepDate.Name = "txtDepDate"
        Me.txtDepDate.Size = New System.Drawing.Size(94, 22)
        Me.txtDepDate.TabIndex = 198
        Me.txtDepDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtDepNum
        '
        Me.txtDepNum.Location = New System.Drawing.Point(566, 956)
        Me.txtDepNum.Name = "txtDepNum"
        Me.txtDepNum.Size = New System.Drawing.Size(47, 22)
        Me.txtDepNum.TabIndex = 199
        '
        'txtDepAmount
        '
        Me.txtDepAmount.Location = New System.Drawing.Point(373, 956)
        Me.txtDepAmount.Name = "txtDepAmount"
        Me.txtDepAmount.Size = New System.Drawing.Size(94, 22)
        Me.txtDepAmount.TabIndex = 197
        Me.txtDepAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Tirestxt
        '
        Me.Tirestxt.AutoSize = True
        Me.Tirestxt.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tirestxt.Location = New System.Drawing.Point(315, 496)
        Me.Tirestxt.Name = "Tirestxt"
        Me.Tirestxt.Size = New System.Drawing.Size(40, 17)
        Me.Tirestxt.TabIndex = 196
        Me.Tirestxt.Text = "Tires"
        '
        'txttires
        '
        Me.txttires.Location = New System.Drawing.Point(362, 494)
        Me.txttires.Name = "txttires"
        Me.txttires.Size = New System.Drawing.Size(39, 22)
        Me.txttires.TabIndex = 52
        Me.txttires.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtb1atteries
        '
        Me.txtb1atteries.AutoSize = True
        Me.txtb1atteries.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtb1atteries.Location = New System.Drawing.Point(410, 496)
        Me.txtb1atteries.Name = "txtb1atteries"
        Me.txtb1atteries.Size = New System.Drawing.Size(66, 17)
        Me.txtb1atteries.TabIndex = 194
        Me.txtb1atteries.Text = "Batteries"
        '
        'txtbatteries
        '
        Me.txtbatteries.Location = New System.Drawing.Point(482, 494)
        Me.txtbatteries.Name = "txtbatteries"
        Me.txtbatteries.Size = New System.Drawing.Size(39, 22)
        Me.txtbatteries.TabIndex = 53
        Me.txtbatteries.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'GroupBox17
        '
        Me.GroupBox17.Controls.Add(Me.txtsmallitemcom)
        Me.GroupBox17.Controls.Add(Me.Label94)
        Me.GroupBox17.Location = New System.Drawing.Point(406, 360)
        Me.GroupBox17.Name = "GroupBox17"
        Me.GroupBox17.Size = New System.Drawing.Size(191, 44)
        Me.GroupBox17.TabIndex = 190
        Me.GroupBox17.TabStop = False
        Me.GroupBox17.Text = "Small Item Pay"
        Me.GroupBox17.Visible = False
        '
        'txtsmallitemcom
        '
        Me.txtsmallitemcom.Location = New System.Drawing.Point(110, 14)
        Me.txtsmallitemcom.Name = "txtsmallitemcom"
        Me.txtsmallitemcom.Size = New System.Drawing.Size(75, 22)
        Me.txtsmallitemcom.TabIndex = 55
        Me.txtsmallitemcom.TabStop = False
        Me.txtsmallitemcom.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label94
        '
        Me.Label94.AutoSize = True
        Me.Label94.Location = New System.Drawing.Point(48, 20)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(57, 16)
        Me.Label94.TabIndex = 0
        Me.Label94.Text = "Amount:"
        '
        'btnDoneComm
        '
        Me.btnDoneComm.Location = New System.Drawing.Point(103, 956)
        Me.btnDoneComm.Name = "btnDoneComm"
        Me.btnDoneComm.Size = New System.Drawing.Size(160, 23)
        Me.btnDoneComm.TabIndex = 77
        Me.btnDoneComm.Text = "Done Commisioning"
        Me.btnDoneComm.UseVisualStyleBackColor = True
        Me.btnDoneComm.Visible = False
        '
        'txtcommrate8
        '
        Me.txtcommrate8.Enabled = False
        Me.txtcommrate8.Location = New System.Drawing.Point(313, 888)
        Me.txtcommrate8.Name = "txtcommrate8"
        Me.txtcommrate8.Size = New System.Drawing.Size(26, 22)
        Me.txtcommrate8.TabIndex = 51
        Me.txtcommrate8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtcommrate7
        '
        Me.txtcommrate7.Enabled = False
        Me.txtcommrate7.Location = New System.Drawing.Point(313, 860)
        Me.txtcommrate7.Name = "txtcommrate7"
        Me.txtcommrate7.Size = New System.Drawing.Size(26, 22)
        Me.txtcommrate7.TabIndex = 48
        Me.txtcommrate7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtcommrate6
        '
        Me.txtcommrate6.Enabled = False
        Me.txtcommrate6.Location = New System.Drawing.Point(313, 830)
        Me.txtcommrate6.Name = "txtcommrate6"
        Me.txtcommrate6.Size = New System.Drawing.Size(26, 22)
        Me.txtcommrate6.TabIndex = 45
        Me.txtcommrate6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtcommrate5
        '
        Me.txtcommrate5.Enabled = False
        Me.txtcommrate5.Location = New System.Drawing.Point(313, 802)
        Me.txtcommrate5.Name = "txtcommrate5"
        Me.txtcommrate5.Size = New System.Drawing.Size(26, 22)
        Me.txtcommrate5.TabIndex = 42
        Me.txtcommrate5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtcommrate4
        '
        Me.txtcommrate4.Enabled = False
        Me.txtcommrate4.Location = New System.Drawing.Point(313, 774)
        Me.txtcommrate4.Name = "txtcommrate4"
        Me.txtcommrate4.Size = New System.Drawing.Size(26, 22)
        Me.txtcommrate4.TabIndex = 39
        Me.txtcommrate4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtcommrate3
        '
        Me.txtcommrate3.Enabled = False
        Me.txtcommrate3.Location = New System.Drawing.Point(312, 746)
        Me.txtcommrate3.Name = "txtcommrate3"
        Me.txtcommrate3.Size = New System.Drawing.Size(26, 22)
        Me.txtcommrate3.TabIndex = 36
        Me.txtcommrate3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtcommrate2
        '
        Me.txtcommrate2.Enabled = False
        Me.txtcommrate2.Location = New System.Drawing.Point(312, 718)
        Me.txtcommrate2.Name = "txtcommrate2"
        Me.txtcommrate2.Size = New System.Drawing.Size(26, 22)
        Me.txtcommrate2.TabIndex = 33
        Me.txtcommrate2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtcommrate1
        '
        Me.txtcommrate1.Enabled = False
        Me.txtcommrate1.Location = New System.Drawing.Point(312, 690)
        Me.txtcommrate1.Name = "txtcommrate1"
        Me.txtcommrate1.Size = New System.Drawing.Size(26, 22)
        Me.txtcommrate1.TabIndex = 30
        Me.txtcommrate1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label88
        '
        Me.Label88.AutoSize = True
        Me.Label88.Enabled = False
        Me.Label88.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label88.Location = New System.Drawing.Point(20, 920)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(212, 17)
        Me.Label88.TabIndex = 180
        Me.Label88.Text = "Misc Commision Including PPB"
        '
        'txtMiscComm
        '
        Me.txtMiscComm.Enabled = False
        Me.txtMiscComm.Location = New System.Drawing.Point(241, 917)
        Me.txtMiscComm.Name = "txtMiscComm"
        Me.txtMiscComm.Size = New System.Drawing.Size(68, 22)
        Me.txtMiscComm.TabIndex = 179
        Me.txtMiscComm.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.BackColor = System.Drawing.Color.Transparent
        Me.Label87.Font = New System.Drawing.Font("Arial", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label87.Location = New System.Drawing.Point(32, 91)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(71, 10)
        Me.Label87.TabIndex = 177
        Me.Label87.Text = "(Manditory to save) "
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label71.Location = New System.Drawing.Point(425, 891)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(71, 19)
        Me.Label71.TabIndex = 176
        Me.Label71.Text = "Balance"
        '
        'txtowing
        '
        Me.txtowing.Location = New System.Drawing.Point(504, 890)
        Me.txtowing.Name = "txtowing"
        Me.txtowing.ReadOnly = True
        Me.txtowing.Size = New System.Drawing.Size(110, 22)
        Me.txtowing.TabIndex = 75
        Me.txtowing.TabStop = False
        Me.txtowing.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'chkprotech
        '
        Me.chkprotech.AutoSize = True
        Me.chkprotech.Location = New System.Drawing.Point(482, 555)
        Me.chkprotech.Name = "chkprotech"
        Me.chkprotech.Size = New System.Drawing.Size(15, 14)
        Me.chkprotech.TabIndex = 56
        Me.chkprotech.UseVisualStyleBackColor = True
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label79.Location = New System.Drawing.Point(395, 747)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(99, 16)
        Me.Label79.TabIndex = 172
        Me.Label79.Text = "TRADE IN LIEN"
        '
        'txttradelein
        '
        Me.txttradelein.Location = New System.Drawing.Point(503, 743)
        Me.txttradelein.Name = "txttradelein"
        Me.txttradelein.Size = New System.Drawing.Size(110, 22)
        Me.txttradelein.TabIndex = 67
        Me.txttradelein.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtdatedeled
        '
        Me.txtdatedeled.Location = New System.Drawing.Point(449, 73)
        Me.txtdatedeled.Name = "txtdatedeled"
        Me.txtdatedeled.ReadOnly = True
        Me.txtdatedeled.Size = New System.Drawing.Size(164, 22)
        Me.txtdatedeled.TabIndex = 169
        '
        'ChkGST
        '
        Me.ChkGST.AutoSize = True
        Me.ChkGST.Checked = True
        Me.ChkGST.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChkGST.Location = New System.Drawing.Point(481, 831)
        Me.ChkGST.Name = "ChkGST"
        Me.ChkGST.Size = New System.Drawing.Size(15, 14)
        Me.ChkGST.TabIndex = 71
        Me.ChkGST.UseVisualStyleBackColor = True
        '
        'chkPST
        '
        Me.chkPST.AutoSize = True
        Me.chkPST.Checked = True
        Me.chkPST.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkPST.Location = New System.Drawing.Point(481, 805)
        Me.chkPST.Name = "chkPST"
        Me.chkPST.Size = New System.Drawing.Size(15, 14)
        Me.chkPST.TabIndex = 69
        Me.chkPST.UseVisualStyleBackColor = True
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox3.Location = New System.Drawing.Point(109, 7)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(330, 75)
        Me.PictureBox3.TabIndex = 166
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Location = New System.Drawing.Point(3, 7)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(100, 50)
        Me.PictureBox2.TabIndex = 165
        Me.PictureBox2.TabStop = False
        '
        'btnReleaseBoat
        '
        Me.btnReleaseBoat.Location = New System.Drawing.Point(123, 443)
        Me.btnReleaseBoat.Name = "btnReleaseBoat"
        Me.btnReleaseBoat.Size = New System.Drawing.Size(111, 23)
        Me.btnReleaseBoat.TabIndex = 13
        Me.btnReleaseBoat.Text = "Release Boat"
        Me.btnReleaseBoat.UseVisualStyleBackColor = True
        '
        'btnOrder
        '
        Me.btnOrder.Location = New System.Drawing.Point(123, 442)
        Me.btnOrder.Name = "btnOrder"
        Me.btnOrder.Size = New System.Drawing.Size(111, 23)
        Me.btnOrder.TabIndex = 164
        Me.btnOrder.TabStop = False
        Me.btnOrder.Text = "Order a Boat"
        Me.btnOrder.UseVisualStyleBackColor = True
        '
        'txtp3date
        '
        Me.txtp3date.Enabled = False
        Me.txtp3date.Location = New System.Drawing.Point(469, 1040)
        Me.txtp3date.Name = "txtp3date"
        Me.txtp3date.Size = New System.Drawing.Size(94, 22)
        Me.txtp3date.TabIndex = 85
        Me.txtp3date.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtp2date
        '
        Me.txtp2date.Enabled = False
        Me.txtp2date.Location = New System.Drawing.Point(469, 1012)
        Me.txtp2date.Name = "txtp2date"
        Me.txtp2date.Size = New System.Drawing.Size(94, 22)
        Me.txtp2date.TabIndex = 82
        Me.txtp2date.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtp1date
        '
        Me.txtp1date.Enabled = False
        Me.txtp1date.Location = New System.Drawing.Point(469, 984)
        Me.txtp1date.Name = "txtp1date"
        Me.txtp1date.Size = New System.Drawing.Size(94, 22)
        Me.txtp1date.TabIndex = 79
        Me.txtp1date.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btnPickABoat
        '
        Me.btnPickABoat.Location = New System.Drawing.Point(6, 443)
        Me.btnPickABoat.Name = "btnPickABoat"
        Me.btnPickABoat.Size = New System.Drawing.Size(111, 23)
        Me.btnPickABoat.TabIndex = 12
        Me.btnPickABoat.TabStop = False
        Me.btnPickABoat.Text = "Pick a Boat"
        Me.btnPickABoat.UseVisualStyleBackColor = True
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.Location = New System.Drawing.Point(434, 257)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(33, 14)
        Me.Label48.TabIndex = 160
        Me.Label48.Text = "Year:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(260, 199)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(41, 14)
        Me.Label15.TabIndex = 159
        Me.Label15.Text = "Colour:"
        '
        'txtboatunit
        '
        Me.txtboatunit.Location = New System.Drawing.Point(195, 213)
        Me.txtboatunit.Name = "txtboatunit"
        Me.txtboatunit.ReadOnly = True
        Me.txtboatunit.Size = New System.Drawing.Size(59, 22)
        Me.txtboatunit.TabIndex = 158
        Me.txtboatunit.TabStop = False
        '
        'txtadminfee
        '
        Me.txtadminfee.Location = New System.Drawing.Point(503, 466)
        Me.txtadminfee.Name = "txtadminfee"
        Me.txtadminfee.Size = New System.Drawing.Size(110, 22)
        Me.txtadminfee.TabIndex = 51
        Me.txtadminfee.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(431, 802)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(41, 19)
        Me.Label47.TabIndex = 157
        Me.Label47.Text = "PST"
        '
        'txtpst
        '
        Me.txtpst.Location = New System.Drawing.Point(503, 798)
        Me.txtpst.Name = "txtpst"
        Me.txtpst.ReadOnly = True
        Me.txtpst.Size = New System.Drawing.Size(110, 22)
        Me.txtpst.TabIndex = 70
        Me.txtpst.TabStop = False
        Me.txtpst.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(338, 918)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(156, 18)
        Me.Label46.TabIndex = 155
        Me.Label46.Text = "Payment Information:"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.Location = New System.Drawing.Point(3, 468)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(152, 18)
        Me.Label45.TabIndex = 154
        Me.Label45.Text = "Optional Equipment:"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(416, 854)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(78, 24)
        Me.Label43.TabIndex = 73
        Me.Label43.Text = "TOTAL"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(432, 830)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(42, 19)
        Me.Label44.TabIndex = 152
        Me.Label44.Text = "GST"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(395, 773)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(100, 19)
        Me.Label41.TabIndex = 151
        Me.Label41.Text = "SUB TOTAL"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(363, 720)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(132, 19)
        Me.Label42.TabIndex = 150
        Me.Label42.Text = "LESS TRADE IN"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(343, 469)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(153, 17)
        Me.Label40.TabIndex = 148
        Me.Label40.Text = "Administration Service"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(350, 692)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(144, 19)
        Me.Label32.TabIndex = 147
        Me.Label32.Text = "PACKAGE TOTAL"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(357, 664)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(137, 19)
        Me.Label33.TabIndex = 146
        Me.Label33.Text = "OPTIONS TOTAL"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(337, 635)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(136, 17)
        Me.Label34.TabIndex = 145
        Me.Label34.Text = "First Year Winterize"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(378, 607)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(96, 17)
        Me.Label35.TabIndex = 144
        Me.Label35.Text = "20 Hr Service"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(340, 580)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(132, 17)
        Me.Label36.TabIndex = 143
        Me.Label36.Text = "Extended Warranty"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(369, 552)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(103, 17)
        Me.Label37.TabIndex = 142
        Me.Label37.Text = "Protection Pkg"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(347, 523)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(127, 17)
        Me.Label38.TabIndex = 141
        Me.Label38.Text = "Anti Theft Registry"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(36, 635)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(165, 17)
        Me.Label31.TabIndex = 139
        Me.Label31.Text = "Anti Theft Lock Package"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(33, 607)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(168, 17)
        Me.Label30.TabIndex = 138
        Me.Label30.Text = "Boater's Safety Package"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(119, 582)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(82, 17)
        Me.Label29.TabIndex = 137
        Me.Label29.Text = "Spare Prop"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(115, 551)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(86, 17)
        Me.Label28.TabIndex = 136
        Me.Label28.Text = "Rock Guard"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(66, 663)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(92, 17)
        Me.Label27.TabIndex = 135
        Me.Label27.Text = "Sports Pkg #"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(99, 524)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(102, 17)
        Me.Label26.TabIndex = 134
        Me.Label26.Text = "Storage Cover"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(125, 496)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(75, 17)
        Me.Label25.TabIndex = 133
        Me.Label25.Text = "Spare Tire"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(560, 943)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(57, 14)
        Me.Label24.TabIndex = 132
        Me.Label24.Text = "Reciept #"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(466, 943)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(31, 14)
        Me.Label23.TabIndex = 131
        Me.Label23.Text = "Date"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(369, 943)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(51, 14)
        Me.Label22.TabIndex = 130
        Me.Label22.Text = "Amount"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(3, 955)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(94, 16)
        Me.Label21.TabIndex = 129
        Me.Label21.Text = "Special Terms:"
        '
        'txtnotes1
        '
        Me.txtnotes1.Location = New System.Drawing.Point(6, 992)
        Me.txtnotes1.Multiline = True
        Me.txtnotes1.Name = "txtnotes1"
        Me.txtnotes1.Size = New System.Drawing.Size(345, 70)
        Me.txtnotes1.TabIndex = 76
        '
        'txtp3num
        '
        Me.txtp3num.Location = New System.Drawing.Point(566, 1040)
        Me.txtp3num.Name = "txtp3num"
        Me.txtp3num.Size = New System.Drawing.Size(47, 22)
        Me.txtp3num.TabIndex = 86
        '
        'txtp2num
        '
        Me.txtp2num.Location = New System.Drawing.Point(566, 1012)
        Me.txtp2num.Name = "txtp2num"
        Me.txtp2num.Size = New System.Drawing.Size(47, 22)
        Me.txtp2num.TabIndex = 83
        '
        'txtp1num
        '
        Me.txtp1num.Location = New System.Drawing.Point(566, 984)
        Me.txtp1num.Name = "txtp1num"
        Me.txtp1num.Size = New System.Drawing.Size(47, 22)
        Me.txtp1num.TabIndex = 80
        '
        'txtp3amount
        '
        Me.txtp3amount.Location = New System.Drawing.Point(373, 1040)
        Me.txtp3amount.Name = "txtp3amount"
        Me.txtp3amount.Size = New System.Drawing.Size(94, 22)
        Me.txtp3amount.TabIndex = 84
        Me.txtp3amount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtp2amount
        '
        Me.txtp2amount.Location = New System.Drawing.Point(373, 1012)
        Me.txtp2amount.Name = "txtp2amount"
        Me.txtp2amount.Size = New System.Drawing.Size(94, 22)
        Me.txtp2amount.TabIndex = 81
        Me.txtp2amount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtp1amount
        '
        Me.txtp1amount.Location = New System.Drawing.Point(373, 984)
        Me.txtp1amount.Name = "txtp1amount"
        Me.txtp1amount.Size = New System.Drawing.Size(94, 22)
        Me.txtp1amount.TabIndex = 78
        Me.txtp1amount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txto1
        '
        Me.txto1.Location = New System.Drawing.Point(6, 690)
        Me.txto1.Name = "txto1"
        Me.txto1.Size = New System.Drawing.Size(226, 22)
        Me.txto1.TabIndex = 28
        '
        'txto2
        '
        Me.txto2.Location = New System.Drawing.Point(6, 718)
        Me.txto2.Name = "txto2"
        Me.txto2.Size = New System.Drawing.Size(226, 22)
        Me.txto2.TabIndex = 31
        '
        'txto3
        '
        Me.txto3.Location = New System.Drawing.Point(6, 746)
        Me.txto3.Name = "txto3"
        Me.txto3.Size = New System.Drawing.Size(226, 22)
        Me.txto3.TabIndex = 34
        '
        'txto4
        '
        Me.txto4.Location = New System.Drawing.Point(6, 773)
        Me.txto4.Name = "txto4"
        Me.txto4.Size = New System.Drawing.Size(226, 22)
        Me.txto4.TabIndex = 37
        '
        'txto5
        '
        Me.txto5.Location = New System.Drawing.Point(6, 802)
        Me.txto5.Name = "txto5"
        Me.txto5.Size = New System.Drawing.Size(226, 22)
        Me.txto5.TabIndex = 40
        '
        'txto6
        '
        Me.txto6.Location = New System.Drawing.Point(6, 831)
        Me.txto6.Name = "txto6"
        Me.txto6.Size = New System.Drawing.Size(226, 22)
        Me.txto6.TabIndex = 43
        '
        'txto7
        '
        Me.txto7.Location = New System.Drawing.Point(6, 861)
        Me.txto7.Name = "txto7"
        Me.txto7.Size = New System.Drawing.Size(226, 22)
        Me.txto7.TabIndex = 46
        '
        'txto8
        '
        Me.txto8.Location = New System.Drawing.Point(6, 889)
        Me.txto8.Name = "txto8"
        Me.txto8.Size = New System.Drawing.Size(226, 22)
        Me.txto8.TabIndex = 49
        '
        'chkwinterize
        '
        Me.chkwinterize.AutoSize = True
        Me.chkwinterize.Location = New System.Drawing.Point(481, 636)
        Me.chkwinterize.Name = "chkwinterize"
        Me.chkwinterize.Size = New System.Drawing.Size(15, 14)
        Me.chkwinterize.TabIndex = 62
        Me.chkwinterize.UseVisualStyleBackColor = True
        '
        'Chk20hr
        '
        Me.Chk20hr.AutoSize = True
        Me.Chk20hr.Location = New System.Drawing.Point(481, 608)
        Me.Chk20hr.Name = "Chk20hr"
        Me.Chk20hr.Size = New System.Drawing.Size(15, 14)
        Me.Chk20hr.TabIndex = 60
        Me.Chk20hr.UseVisualStyleBackColor = True
        '
        'chkextwarranty
        '
        Me.chkextwarranty.AutoSize = True
        Me.chkextwarranty.Location = New System.Drawing.Point(481, 582)
        Me.chkextwarranty.Name = "chkextwarranty"
        Me.chkextwarranty.Size = New System.Drawing.Size(15, 14)
        Me.chkextwarranty.TabIndex = 58
        Me.chkextwarranty.UseVisualStyleBackColor = True
        Me.chkextwarranty.Visible = False
        '
        'chkantitheftreg
        '
        Me.chkantitheftreg.AutoSize = True
        Me.chkantitheftreg.Location = New System.Drawing.Point(481, 524)
        Me.chkantitheftreg.Name = "chkantitheftreg"
        Me.chkantitheftreg.Size = New System.Drawing.Size(15, 14)
        Me.chkantitheftreg.TabIndex = 54
        Me.chkantitheftreg.UseVisualStyleBackColor = True
        '
        'chklockpkg
        '
        Me.chklockpkg.AutoSize = True
        Me.chklockpkg.Location = New System.Drawing.Point(209, 638)
        Me.chklockpkg.Name = "chklockpkg"
        Me.chklockpkg.Size = New System.Drawing.Size(15, 14)
        Me.chklockpkg.TabIndex = 24
        Me.chklockpkg.UseVisualStyleBackColor = True
        '
        'chksafepkg
        '
        Me.chksafepkg.AutoSize = True
        Me.chksafepkg.Location = New System.Drawing.Point(209, 610)
        Me.chksafepkg.Name = "chksafepkg"
        Me.chksafepkg.Size = New System.Drawing.Size(15, 14)
        Me.chksafepkg.TabIndex = 22
        Me.chksafepkg.UseVisualStyleBackColor = True
        '
        'chksprop
        '
        Me.chksprop.AutoSize = True
        Me.chksprop.Location = New System.Drawing.Point(209, 582)
        Me.chksprop.Name = "chksprop"
        Me.chksprop.Size = New System.Drawing.Size(15, 14)
        Me.chksprop.TabIndex = 20
        Me.chksprop.UseVisualStyleBackColor = True
        '
        'chkrockg
        '
        Me.chkrockg.AutoSize = True
        Me.chkrockg.Location = New System.Drawing.Point(209, 554)
        Me.chkrockg.Name = "chkrockg"
        Me.chkrockg.Size = New System.Drawing.Size(15, 14)
        Me.chkrockg.TabIndex = 18
        Me.chkrockg.UseVisualStyleBackColor = True
        '
        'chkskipkg
        '
        Me.chkskipkg.AutoSize = True
        Me.chkskipkg.Location = New System.Drawing.Point(209, 666)
        Me.chkskipkg.Name = "chkskipkg"
        Me.chkskipkg.Size = New System.Drawing.Size(15, 14)
        Me.chkskipkg.TabIndex = 26
        Me.chkskipkg.UseVisualStyleBackColor = True
        '
        'chkcover
        '
        Me.chkcover.AutoSize = True
        Me.chkcover.Location = New System.Drawing.Point(209, 527)
        Me.chkcover.Name = "chkcover"
        Me.chkcover.Size = New System.Drawing.Size(15, 14)
        Me.chkcover.TabIndex = 16
        Me.chkcover.UseVisualStyleBackColor = True
        '
        'chkstire
        '
        Me.chkstire.AutoSize = True
        Me.chkstire.Location = New System.Drawing.Point(209, 499)
        Me.chkstire.Name = "chkstire"
        Me.chkstire.Size = New System.Drawing.Size(15, 14)
        Me.chkstire.TabIndex = 14
        Me.chkstire.UseVisualStyleBackColor = True
        '
        'txto5price
        '
        Me.txto5price.Location = New System.Drawing.Point(240, 802)
        Me.txto5price.Name = "txto5price"
        Me.txto5price.Size = New System.Drawing.Size(68, 22)
        Me.txto5price.TabIndex = 41
        Me.txto5price.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txto4price
        '
        Me.txto4price.Location = New System.Drawing.Point(240, 774)
        Me.txto4price.Name = "txto4price"
        Me.txto4price.Size = New System.Drawing.Size(68, 22)
        Me.txto4price.TabIndex = 38
        Me.txto4price.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txto3price
        '
        Me.txto3price.Location = New System.Drawing.Point(240, 746)
        Me.txto3price.Name = "txto3price"
        Me.txto3price.Size = New System.Drawing.Size(68, 22)
        Me.txto3price.TabIndex = 35
        Me.txto3price.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txto6price
        '
        Me.txto6price.Location = New System.Drawing.Point(240, 831)
        Me.txto6price.Name = "txto6price"
        Me.txto6price.Size = New System.Drawing.Size(68, 22)
        Me.txto6price.TabIndex = 44
        Me.txto6price.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txto2price
        '
        Me.txto2price.Location = New System.Drawing.Point(240, 718)
        Me.txto2price.Name = "txto2price"
        Me.txto2price.Size = New System.Drawing.Size(68, 22)
        Me.txto2price.TabIndex = 32
        Me.txto2price.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txto8price
        '
        Me.txto8price.Location = New System.Drawing.Point(240, 889)
        Me.txto8price.Name = "txto8price"
        Me.txto8price.Size = New System.Drawing.Size(68, 22)
        Me.txto8price.TabIndex = 50
        Me.txto8price.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txto1price
        '
        Me.txto1price.Location = New System.Drawing.Point(240, 690)
        Me.txto1price.Name = "txto1price"
        Me.txto1price.Size = New System.Drawing.Size(68, 22)
        Me.txto1price.TabIndex = 29
        Me.txto1price.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtlockpkgprice
        '
        Me.txtlockpkgprice.Location = New System.Drawing.Point(241, 633)
        Me.txtlockpkgprice.Name = "txtlockpkgprice"
        Me.txtlockpkgprice.Size = New System.Drawing.Size(68, 22)
        Me.txtlockpkgprice.TabIndex = 25
        Me.txtlockpkgprice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtsafepkgprice
        '
        Me.txtsafepkgprice.Location = New System.Drawing.Point(241, 605)
        Me.txtsafepkgprice.Name = "txtsafepkgprice"
        Me.txtsafepkgprice.Size = New System.Drawing.Size(68, 22)
        Me.txtsafepkgprice.TabIndex = 23
        Me.txtsafepkgprice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtspropprice
        '
        Me.txtspropprice.Location = New System.Drawing.Point(241, 577)
        Me.txtspropprice.Name = "txtspropprice"
        Me.txtspropprice.Size = New System.Drawing.Size(68, 22)
        Me.txtspropprice.TabIndex = 21
        Me.txtspropprice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtrockgprice
        '
        Me.txtrockgprice.Location = New System.Drawing.Point(241, 549)
        Me.txtrockgprice.Name = "txtrockgprice"
        Me.txtrockgprice.Size = New System.Drawing.Size(68, 22)
        Me.txtrockgprice.TabIndex = 19
        Me.txtrockgprice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtskipkgprice
        '
        Me.txtskipkgprice.Location = New System.Drawing.Point(241, 661)
        Me.txtskipkgprice.Name = "txtskipkgprice"
        Me.txtskipkgprice.Size = New System.Drawing.Size(68, 22)
        Me.txtskipkgprice.TabIndex = 27
        Me.txtskipkgprice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtcoverprice
        '
        Me.txtcoverprice.Location = New System.Drawing.Point(241, 522)
        Me.txtcoverprice.Name = "txtcoverprice"
        Me.txtcoverprice.Size = New System.Drawing.Size(68, 22)
        Me.txtcoverprice.TabIndex = 17
        Me.txtcoverprice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txto7price
        '
        Me.txto7price.Location = New System.Drawing.Point(240, 860)
        Me.txto7price.Name = "txto7price"
        Me.txto7price.Size = New System.Drawing.Size(68, 22)
        Me.txto7price.TabIndex = 47
        Me.txto7price.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtstireprice
        '
        Me.txtstireprice.Location = New System.Drawing.Point(241, 494)
        Me.txtstireprice.Name = "txtstireprice"
        Me.txtstireprice.Size = New System.Drawing.Size(68, 22)
        Me.txtstireprice.TabIndex = 15
        Me.txtstireprice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txttotal
        '
        Me.txttotal.Location = New System.Drawing.Point(504, 854)
        Me.txttotal.Name = "txttotal"
        Me.txttotal.ReadOnly = True
        Me.txttotal.Size = New System.Drawing.Size(110, 22)
        Me.txttotal.TabIndex = 74
        Me.txttotal.TabStop = False
        Me.txttotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtgst
        '
        Me.txtgst.Location = New System.Drawing.Point(504, 826)
        Me.txtgst.Name = "txtgst"
        Me.txtgst.ReadOnly = True
        Me.txtgst.Size = New System.Drawing.Size(110, 22)
        Me.txtgst.TabIndex = 72
        Me.txtgst.TabStop = False
        Me.txtgst.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtsubtotal
        '
        Me.txtsubtotal.Location = New System.Drawing.Point(503, 770)
        Me.txtsubtotal.Name = "txtsubtotal"
        Me.txtsubtotal.ReadOnly = True
        Me.txtsubtotal.Size = New System.Drawing.Size(110, 22)
        Me.txtsubtotal.TabIndex = 68
        Me.txtsubtotal.TabStop = False
        Me.txtsubtotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txttrade
        '
        Me.txttrade.Location = New System.Drawing.Point(503, 717)
        Me.txttrade.Name = "txttrade"
        Me.txttrade.Size = New System.Drawing.Size(110, 22)
        Me.txttrade.TabIndex = 66
        Me.txttrade.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtpackagetotal
        '
        Me.txtpackagetotal.Location = New System.Drawing.Point(503, 689)
        Me.txtpackagetotal.Name = "txtpackagetotal"
        Me.txtpackagetotal.ReadOnly = True
        Me.txtpackagetotal.Size = New System.Drawing.Size(110, 22)
        Me.txtpackagetotal.TabIndex = 65
        Me.txtpackagetotal.TabStop = False
        Me.txtpackagetotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtoptionstotal
        '
        Me.txtoptionstotal.Location = New System.Drawing.Point(503, 661)
        Me.txtoptionstotal.Name = "txtoptionstotal"
        Me.txtoptionstotal.ReadOnly = True
        Me.txtoptionstotal.Size = New System.Drawing.Size(110, 22)
        Me.txtoptionstotal.TabIndex = 64
        Me.txtoptionstotal.TabStop = False
        Me.txtoptionstotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtwinterize
        '
        Me.txtwinterize.Location = New System.Drawing.Point(503, 633)
        Me.txtwinterize.Name = "txtwinterize"
        Me.txtwinterize.Size = New System.Drawing.Size(110, 22)
        Me.txtwinterize.TabIndex = 63
        Me.txtwinterize.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txt20hr
        '
        Me.txt20hr.Location = New System.Drawing.Point(503, 605)
        Me.txt20hr.Name = "txt20hr"
        Me.txt20hr.Size = New System.Drawing.Size(110, 22)
        Me.txt20hr.TabIndex = 61
        Me.txt20hr.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtextwarranty
        '
        Me.txtextwarranty.Location = New System.Drawing.Point(503, 577)
        Me.txtextwarranty.Name = "txtextwarranty"
        Me.txtextwarranty.Size = New System.Drawing.Size(110, 22)
        Me.txtextwarranty.TabIndex = 59
        Me.txtextwarranty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtprotech
        '
        Me.txtprotech.Location = New System.Drawing.Point(503, 549)
        Me.txtprotech.Name = "txtprotech"
        Me.txtprotech.Size = New System.Drawing.Size(110, 22)
        Me.txtprotech.TabIndex = 57
        Me.txtprotech.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtantitheftreg
        '
        Me.txtantitheftreg.Location = New System.Drawing.Point(503, 521)
        Me.txtantitheftreg.Name = "txtantitheftreg"
        Me.txtantitheftreg.Size = New System.Drawing.Size(110, 22)
        Me.txtantitheftreg.TabIndex = 55
        Me.txtantitheftreg.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txttiretax
        '
        Me.txttiretax.Enabled = False
        Me.txttiretax.Location = New System.Drawing.Point(527, 493)
        Me.txttiretax.Name = "txttiretax"
        Me.txttiretax.Size = New System.Drawing.Size(86, 22)
        Me.txttiretax.TabIndex = 52
        Me.txttiretax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(500, 257)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(34, 14)
        Me.Label20.TabIndex = 68
        Me.Label20.Text = "Price:"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(192, 198)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(28, 14)
        Me.Label19.TabIndex = 67
        Me.Label19.Text = "Unit:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(257, 257)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(77, 14)
        Me.Label18.TabIndex = 66
        Me.Label18.Text = "Serial Number:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(120, 257)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(38, 14)
        Me.Label17.TabIndex = 65
        Me.Label17.Text = "Model:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(5, 257)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(35, 14)
        Me.Label16.TabIndex = 64
        Me.Label16.Text = "Make:"
        '
        'txtdiscountprice
        '
        Me.txtdiscountprice.Location = New System.Drawing.Point(503, 439)
        Me.txtdiscountprice.Name = "txtdiscountprice"
        Me.txtdiscountprice.ReadOnly = True
        Me.txtdiscountprice.Size = New System.Drawing.Size(110, 22)
        Me.txtdiscountprice.TabIndex = 63
        Me.txtdiscountprice.TabStop = False
        Me.txtdiscountprice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtdiscount
        '
        Me.txtdiscount.Location = New System.Drawing.Point(260, 439)
        Me.txtdiscount.Name = "txtdiscount"
        Me.txtdiscount.ReadOnly = True
        Me.txtdiscount.Size = New System.Drawing.Size(236, 22)
        Me.txtdiscount.TabIndex = 59
        Me.txtdiscount.TabStop = False
        '
        'txtkickerprice
        '
        Me.txtkickerprice.Location = New System.Drawing.Point(503, 411)
        Me.txtkickerprice.Name = "txtkickerprice"
        Me.txtkickerprice.Size = New System.Drawing.Size(110, 22)
        Me.txtkickerprice.TabIndex = 75
        Me.txtkickerprice.TabStop = False
        Me.txtkickerprice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtkickeryear
        '
        Me.txtkickeryear.Location = New System.Drawing.Point(437, 411)
        Me.txtkickeryear.Name = "txtkickeryear"
        Me.txtkickeryear.Size = New System.Drawing.Size(59, 22)
        Me.txtkickeryear.TabIndex = 74
        Me.txtkickeryear.TabStop = False
        Me.txtkickeryear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtkickerserial
        '
        Me.txtkickerserial.Location = New System.Drawing.Point(260, 411)
        Me.txtkickerserial.Name = "txtkickerserial"
        Me.txtkickerserial.Size = New System.Drawing.Size(171, 22)
        Me.txtkickerserial.TabIndex = 73
        Me.txtkickerserial.TabStop = False
        '
        'txtkickermodel
        '
        Me.txtkickermodel.Location = New System.Drawing.Point(123, 411)
        Me.txtkickermodel.Name = "txtkickermodel"
        Me.txtkickermodel.Size = New System.Drawing.Size(131, 22)
        Me.txtkickermodel.TabIndex = 72
        Me.txtkickermodel.TabStop = False
        '
        'txtkickermake
        '
        Me.txtkickermake.Location = New System.Drawing.Point(6, 411)
        Me.txtkickermake.Name = "txtkickermake"
        Me.txtkickermake.Size = New System.Drawing.Size(111, 22)
        Me.txtkickermake.TabIndex = 71
        Me.txtkickermake.TabStop = False
        '
        'txttplateprice
        '
        Me.txttplateprice.Location = New System.Drawing.Point(503, 383)
        Me.txttplateprice.Name = "txttplateprice"
        Me.txttplateprice.ReadOnly = True
        Me.txttplateprice.Size = New System.Drawing.Size(110, 22)
        Me.txttplateprice.TabIndex = 70
        Me.txttplateprice.TabStop = False
        Me.txttplateprice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txttplateyear
        '
        Me.txttplateyear.Location = New System.Drawing.Point(437, 383)
        Me.txttplateyear.Name = "txttplateyear"
        Me.txttplateyear.ReadOnly = True
        Me.txttplateyear.Size = New System.Drawing.Size(59, 22)
        Me.txttplateyear.TabIndex = 69
        Me.txttplateyear.TabStop = False
        Me.txttplateyear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txttplateserial
        '
        Me.txttplateserial.Location = New System.Drawing.Point(260, 383)
        Me.txttplateserial.Name = "txttplateserial"
        Me.txttplateserial.ReadOnly = True
        Me.txttplateserial.Size = New System.Drawing.Size(171, 22)
        Me.txttplateserial.TabIndex = 68
        Me.txttplateserial.TabStop = False
        '
        'txttplatemodel
        '
        Me.txttplatemodel.Location = New System.Drawing.Point(123, 383)
        Me.txttplatemodel.Name = "txttplatemodel"
        Me.txttplatemodel.ReadOnly = True
        Me.txttplatemodel.Size = New System.Drawing.Size(131, 22)
        Me.txttplatemodel.TabIndex = 67
        Me.txttplatemodel.TabStop = False
        '
        'txttplatemake
        '
        Me.txttplatemake.Location = New System.Drawing.Point(6, 383)
        Me.txttplatemake.Name = "txttplatemake"
        Me.txttplatemake.ReadOnly = True
        Me.txttplatemake.Size = New System.Drawing.Size(111, 22)
        Me.txttplatemake.TabIndex = 66
        Me.txttplatemake.TabStop = False
        '
        'txtdriveprice
        '
        Me.txtdriveprice.Location = New System.Drawing.Point(503, 355)
        Me.txtdriveprice.Name = "txtdriveprice"
        Me.txtdriveprice.ReadOnly = True
        Me.txtdriveprice.Size = New System.Drawing.Size(110, 22)
        Me.txtdriveprice.TabIndex = 65
        Me.txtdriveprice.TabStop = False
        Me.txtdriveprice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtdriveyear
        '
        Me.txtdriveyear.Location = New System.Drawing.Point(437, 355)
        Me.txtdriveyear.Name = "txtdriveyear"
        Me.txtdriveyear.ReadOnly = True
        Me.txtdriveyear.Size = New System.Drawing.Size(59, 22)
        Me.txtdriveyear.TabIndex = 64
        Me.txtdriveyear.TabStop = False
        Me.txtdriveyear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtdriveserial
        '
        Me.txtdriveserial.Location = New System.Drawing.Point(260, 355)
        Me.txtdriveserial.Name = "txtdriveserial"
        Me.txtdriveserial.ReadOnly = True
        Me.txtdriveserial.Size = New System.Drawing.Size(171, 22)
        Me.txtdriveserial.TabIndex = 63
        Me.txtdriveserial.TabStop = False
        '
        'txtdrivemodel
        '
        Me.txtdrivemodel.Location = New System.Drawing.Point(123, 355)
        Me.txtdrivemodel.Name = "txtdrivemodel"
        Me.txtdrivemodel.ReadOnly = True
        Me.txtdrivemodel.Size = New System.Drawing.Size(131, 22)
        Me.txtdrivemodel.TabIndex = 62
        Me.txtdrivemodel.TabStop = False
        '
        'txtdrivemake
        '
        Me.txtdrivemake.Location = New System.Drawing.Point(6, 355)
        Me.txtdrivemake.Name = "txtdrivemake"
        Me.txtdrivemake.ReadOnly = True
        Me.txtdrivemake.Size = New System.Drawing.Size(111, 22)
        Me.txtdrivemake.TabIndex = 61
        Me.txtdrivemake.TabStop = False
        '
        'txttrailerprice
        '
        Me.txttrailerprice.Location = New System.Drawing.Point(503, 327)
        Me.txttrailerprice.Name = "txttrailerprice"
        Me.txttrailerprice.Size = New System.Drawing.Size(110, 22)
        Me.txttrailerprice.TabIndex = 60
        Me.txttrailerprice.TabStop = False
        Me.txttrailerprice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txttraileryear
        '
        Me.txttraileryear.Location = New System.Drawing.Point(437, 327)
        Me.txttraileryear.Name = "txttraileryear"
        Me.txttraileryear.Size = New System.Drawing.Size(59, 22)
        Me.txttraileryear.TabIndex = 59
        Me.txttraileryear.TabStop = False
        Me.txttraileryear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txttrailerserial
        '
        Me.txttrailerserial.Location = New System.Drawing.Point(260, 327)
        Me.txttrailerserial.Name = "txttrailerserial"
        Me.txttrailerserial.Size = New System.Drawing.Size(171, 22)
        Me.txttrailerserial.TabIndex = 58
        Me.txttrailerserial.TabStop = False
        '
        'txttrailermodel
        '
        Me.txttrailermodel.Location = New System.Drawing.Point(123, 327)
        Me.txttrailermodel.Name = "txttrailermodel"
        Me.txttrailermodel.Size = New System.Drawing.Size(131, 22)
        Me.txttrailermodel.TabIndex = 57
        Me.txttrailermodel.TabStop = False
        '
        'txttrailermake
        '
        Me.txttrailermake.Location = New System.Drawing.Point(6, 327)
        Me.txttrailermake.Name = "txttrailermake"
        Me.txttrailermake.Size = New System.Drawing.Size(111, 22)
        Me.txttrailermake.TabIndex = 56
        Me.txttrailermake.TabStop = False
        '
        'txtmotorprice
        '
        Me.txtmotorprice.Location = New System.Drawing.Point(503, 299)
        Me.txtmotorprice.Name = "txtmotorprice"
        Me.txtmotorprice.Size = New System.Drawing.Size(110, 22)
        Me.txtmotorprice.TabIndex = 55
        Me.txtmotorprice.TabStop = False
        Me.txtmotorprice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtmotoryear
        '
        Me.txtmotoryear.Location = New System.Drawing.Point(437, 299)
        Me.txtmotoryear.Name = "txtmotoryear"
        Me.txtmotoryear.Size = New System.Drawing.Size(59, 22)
        Me.txtmotoryear.TabIndex = 54
        Me.txtmotoryear.TabStop = False
        Me.txtmotoryear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtmotorserial
        '
        Me.txtmotorserial.Location = New System.Drawing.Point(260, 299)
        Me.txtmotorserial.Name = "txtmotorserial"
        Me.txtmotorserial.Size = New System.Drawing.Size(171, 22)
        Me.txtmotorserial.TabIndex = 53
        Me.txtmotorserial.TabStop = False
        '
        'txtmotormodel
        '
        Me.txtmotormodel.Location = New System.Drawing.Point(123, 299)
        Me.txtmotormodel.Name = "txtmotormodel"
        Me.txtmotormodel.Size = New System.Drawing.Size(131, 22)
        Me.txtmotormodel.TabIndex = 52
        Me.txtmotormodel.TabStop = False
        '
        'txtmotormake
        '
        Me.txtmotormake.Location = New System.Drawing.Point(6, 299)
        Me.txtmotormake.Name = "txtmotormake"
        Me.txtmotormake.Size = New System.Drawing.Size(111, 22)
        Me.txtmotormake.TabIndex = 51
        Me.txtmotormake.TabStop = False
        '
        'txtboatprice
        '
        Me.txtboatprice.Location = New System.Drawing.Point(503, 271)
        Me.txtboatprice.Name = "txtboatprice"
        Me.txtboatprice.ReadOnly = True
        Me.txtboatprice.Size = New System.Drawing.Size(110, 22)
        Me.txtboatprice.TabIndex = 50
        Me.txtboatprice.TabStop = False
        Me.txtboatprice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtboatyear
        '
        Me.txtboatyear.Location = New System.Drawing.Point(437, 271)
        Me.txtboatyear.Name = "txtboatyear"
        Me.txtboatyear.ReadOnly = True
        Me.txtboatyear.Size = New System.Drawing.Size(59, 22)
        Me.txtboatyear.TabIndex = 49
        Me.txtboatyear.TabStop = False
        Me.txtboatyear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtboathin
        '
        Me.txtboathin.Location = New System.Drawing.Point(260, 271)
        Me.txtboathin.Name = "txtboathin"
        Me.txtboathin.ReadOnly = True
        Me.txtboathin.Size = New System.Drawing.Size(171, 22)
        Me.txtboathin.TabIndex = 48
        Me.txtboathin.TabStop = False
        '
        'txtboatmodel
        '
        Me.txtboatmodel.Location = New System.Drawing.Point(123, 271)
        Me.txtboatmodel.Name = "txtboatmodel"
        Me.txtboatmodel.ReadOnly = True
        Me.txtboatmodel.Size = New System.Drawing.Size(131, 22)
        Me.txtboatmodel.TabIndex = 47
        Me.txtboatmodel.TabStop = False
        '
        'txtboatmake
        '
        Me.txtboatmake.Location = New System.Drawing.Point(6, 271)
        Me.txtboatmake.Name = "txtboatmake"
        Me.txtboatmake.ReadOnly = True
        Me.txtboatmake.Size = New System.Drawing.Size(111, 22)
        Me.txtboatmake.TabIndex = 46
        Me.txtboatmake.TabStop = False
        '
        'txtcolor
        '
        Me.txtcolor.Location = New System.Drawing.Point(267, 213)
        Me.txtcolor.Name = "txtcolor"
        Me.txtcolor.ReadOnly = True
        Me.txtcolor.Size = New System.Drawing.Size(102, 22)
        Me.txtcolor.TabIndex = 28
        Me.txtcolor.TabStop = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(3, 218)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(163, 18)
        Me.Label14.TabIndex = 0
        Me.Label14.Text = "Purchase Information:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(446, 123)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(49, 14)
        Me.Label13.TabIndex = 25
        Me.Label13.Text = "Home # :"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(446, 159)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(47, 14)
        Me.Label12.TabIndex = 24
        Me.Label12.Text = "Work # :"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(410, 198)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(44, 14)
        Me.Label11.TabIndex = 23
        Me.Label11.Text = "E - Mail:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(302, 159)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(67, 14)
        Me.Label10.TabIndex = 22
        Me.Label10.Text = "Postal Code:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(225, 160)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(32, 14)
        Me.Label9.TabIndex = 21
        Me.Label9.Text = "Prov:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(3, 160)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(28, 14)
        Me.Label8.TabIndex = 20
        Me.Label8.Text = "City:"
        '
        'txtprov
        '
        Me.txtprov.Location = New System.Drawing.Point(228, 174)
        Me.txtprov.Name = "txtprov"
        Me.txtprov.Size = New System.Drawing.Size(71, 22)
        Me.txtprov.TabIndex = 7
        '
        'txtpostal
        '
        Me.txtpostal.Location = New System.Drawing.Point(305, 174)
        Me.txtpostal.Name = "txtpostal"
        Me.txtpostal.Size = New System.Drawing.Size(126, 22)
        Me.txtpostal.TabIndex = 8
        '
        'txtcity
        '
        Me.txtcity.Location = New System.Drawing.Point(6, 174)
        Me.txtcity.Name = "txtcity"
        Me.txtcity.Size = New System.Drawing.Size(164, 22)
        Me.txtcity.TabIndex = 6
        '
        'txtemail
        '
        Me.txtemail.Location = New System.Drawing.Point(413, 213)
        Me.txtemail.Name = "txtemail"
        Me.txtemail.Size = New System.Drawing.Size(200, 22)
        Me.txtemail.TabIndex = 11
        '
        'txtwork
        '
        Me.txtwork.Location = New System.Drawing.Point(449, 174)
        Me.txtwork.Name = "txtwork"
        Me.txtwork.Size = New System.Drawing.Size(164, 22)
        Me.txtwork.TabIndex = 10
        '
        'txthome
        '
        Me.txthome.Location = New System.Drawing.Point(449, 137)
        Me.txthome.Name = "txthome"
        Me.txthome.Size = New System.Drawing.Size(164, 22)
        Me.txthome.TabIndex = 9
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(3, 123)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(52, 14)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Address:"
        '
        'txtaddress
        '
        Me.txtaddress.Location = New System.Drawing.Point(6, 137)
        Me.txtaddress.Name = "txtaddress"
        Me.txtaddress.Size = New System.Drawing.Size(425, 22)
        Me.txtaddress.TabIndex = 5
        '
        'txtbuyer1last
        '
        Me.txtbuyer1last.Location = New System.Drawing.Point(6, 101)
        Me.txtbuyer1last.Name = "txtbuyer1last"
        Me.txtbuyer1last.Size = New System.Drawing.Size(126, 22)
        Me.txtbuyer1last.TabIndex = 1
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(410, 87)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(31, 14)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "First:"
        '
        'txtbuyer1first
        '
        Me.txtbuyer1first.Location = New System.Drawing.Point(138, 101)
        Me.txtbuyer1first.Name = "txtbuyer1first"
        Me.txtbuyer1first.Size = New System.Drawing.Size(126, 22)
        Me.txtbuyer1first.TabIndex = 2
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(278, 87)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(31, 14)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Last:"
        '
        'txtbuyer2last
        '
        Me.txtbuyer2last.Location = New System.Drawing.Point(281, 101)
        Me.txtbuyer2last.Name = "txtbuyer2last"
        Me.txtbuyer2last.Size = New System.Drawing.Size(126, 22)
        Me.txtbuyer2last.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(135, 87)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(31, 14)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "First:"
        '
        'txtbuyer2first
        '
        Me.txtbuyer2first.Location = New System.Drawing.Point(413, 101)
        Me.txtbuyer2first.Name = "txtbuyer2first"
        Me.txtbuyer2first.Size = New System.Drawing.Size(126, 22)
        Me.txtbuyer2first.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(3, 87)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(37, 16)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Last:"
        '
        'DateSold
        '
        Me.DateSold.CalendarFont = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateSold.CustomFormat = "MMMM dd, yyyy"
        Me.DateSold.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DateSold.Location = New System.Drawing.Point(452, 35)
        Me.DateSold.Name = "DateSold"
        Me.DateSold.Size = New System.Drawing.Size(164, 22)
        Me.DateSold.TabIndex = 0
        Me.DateSold.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(3, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(66, 18)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Sold To:"
        '
        'txtBOS
        '
        Me.txtBOS.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBOS.Location = New System.Drawing.Point(516, 7)
        Me.txtBOS.Name = "txtBOS"
        Me.txtBOS.ReadOnly = True
        Me.txtBOS.Size = New System.Drawing.Size(100, 26)
        Me.txtBOS.TabIndex = 5
        Me.txtBOS.TabStop = False
        Me.txtBOS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(453, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 19)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "BOS #"
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label73.Location = New System.Drawing.Point(446, 59)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(80, 14)
        Me.Label73.TabIndex = 170
        Me.Label73.Text = "Date Delivered:"
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.DimGray
        Me.Panel6.Location = New System.Drawing.Point(0, 98)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(268, 29)
        Me.Panel6.TabIndex = 178
        '
        'txtRedNoGST
        '
        Me.txtRedNoGST.AutoSize = True
        Me.txtRedNoGST.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRedNoGST.ForeColor = System.Drawing.Color.Red
        Me.txtRedNoGST.Location = New System.Drawing.Point(393, 823)
        Me.txtRedNoGST.Name = "txtRedNoGST"
        Me.txtRedNoGST.Size = New System.Drawing.Size(48, 29)
        Me.txtRedNoGST.TabIndex = 191
        Me.txtRedNoGST.Text = "NO"
        Me.txtRedNoGST.Visible = False
        '
        'txtrednopst
        '
        Me.txtrednopst.AutoSize = True
        Me.txtrednopst.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtrednopst.ForeColor = System.Drawing.Color.Red
        Me.txtrednopst.Location = New System.Drawing.Point(391, 796)
        Me.txtrednopst.Name = "txtrednopst"
        Me.txtrednopst.Size = New System.Drawing.Size(48, 29)
        Me.txtrednopst.TabIndex = 192
        Me.txtrednopst.Text = "NO"
        Me.txtrednopst.Visible = False
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.DimGray
        Me.Panel7.Location = New System.Drawing.Point(3, 171)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(171, 29)
        Me.Panel7.TabIndex = 179
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.Color.DimGray
        Me.Panel8.Location = New System.Drawing.Point(444, 134)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(173, 29)
        Me.Panel8.TabIndex = 179
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.Color.DimGray
        Me.Panel9.Location = New System.Drawing.Point(409, 210)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(208, 29)
        Me.Panel9.TabIndex = 179
        '
        'pnReq1
        '
        Me.pnReq1.BackColor = System.Drawing.Color.DimGray
        Me.pnReq1.Location = New System.Drawing.Point(223, 171)
        Me.pnReq1.Name = "pnReq1"
        Me.pnReq1.Size = New System.Drawing.Size(213, 29)
        Me.pnReq1.TabIndex = 180
        Me.pnReq1.Visible = False
        '
        'pnReq2
        '
        Me.pnReq2.BackColor = System.Drawing.Color.DimGray
        Me.pnReq2.Location = New System.Drawing.Point(2, 134)
        Me.pnReq2.Name = "pnReq2"
        Me.pnReq2.Size = New System.Drawing.Size(434, 29)
        Me.pnReq2.TabIndex = 181
        Me.pnReq2.Visible = False
        '
        'Sales
        '
        Me.Sales.Controls.Add(Me.Panel2)
        Me.Sales.Location = New System.Drawing.Point(4, 25)
        Me.Sales.Name = "Sales"
        Me.Sales.Padding = New System.Windows.Forms.Padding(3)
        Me.Sales.Size = New System.Drawing.Size(799, 994)
        Me.Sales.TabIndex = 1
        Me.Sales.Text = "Additional Info"
        Me.Sales.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.Controls.Add(Me.GroupBox21)
        Me.Panel2.Controls.Add(Me.GroupBox5)
        Me.Panel2.Controls.Add(Me.GroupBox2)
        Me.Panel2.Controls.Add(Me.GroupBox3)
        Me.Panel2.Controls.Add(Me.GroupBox1)
        Me.Panel2.Controls.Add(Me.GroupBox4)
        Me.Panel2.Controls.Add(Me.GroupBox18)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 3)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(793, 988)
        Me.Panel2.TabIndex = 0
        '
        'GroupBox21
        '
        Me.GroupBox21.Controls.Add(Me.DVCalls)
        Me.GroupBox21.Controls.Add(Me.btnLogACall)
        Me.GroupBox21.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox21.Location = New System.Drawing.Point(3, 556)
        Me.GroupBox21.Name = "GroupBox21"
        Me.GroupBox21.Size = New System.Drawing.Size(624, 166)
        Me.GroupBox21.TabIndex = 85
        Me.GroupBox21.TabStop = False
        Me.GroupBox21.Text = "Call Log:"
        '
        'DVCalls
        '
        Me.DVCalls.AllowUserToAddRows = False
        Me.DVCalls.AllowUserToDeleteRows = False
        Me.DVCalls.AllowUserToResizeRows = False
        Me.DVCalls.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DVCalls.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.View})
        Me.DVCalls.Location = New System.Drawing.Point(8, 39)
        Me.DVCalls.Name = "DVCalls"
        Me.DVCalls.ReadOnly = True
        Me.DVCalls.RowHeadersVisible = False
        Me.DVCalls.Size = New System.Drawing.Size(610, 121)
        Me.DVCalls.TabIndex = 81
        '
        'View
        '
        Me.View.HeaderText = "View"
        Me.View.Name = "View"
        Me.View.ReadOnly = True
        Me.View.Text = "View"
        Me.View.Visible = False
        Me.View.Width = 50
        '
        'btnLogACall
        '
        Me.btnLogACall.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogACall.Location = New System.Drawing.Point(518, 10)
        Me.btnLogACall.Name = "btnLogACall"
        Me.btnLogACall.Size = New System.Drawing.Size(100, 23)
        Me.btnLogACall.TabIndex = 83
        Me.btnLogACall.Text = "Log a Call"
        Me.btnLogACall.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Label81)
        Me.GroupBox5.Controls.Add(Me.txtatnum)
        Me.GroupBox5.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(362, 473)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(265, 77)
        Me.GroupBox5.TabIndex = 19
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Other"
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Location = New System.Drawing.Point(36, 18)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(50, 16)
        Me.Label81.TabIndex = 4
        Me.Label81.Text = "Etch #:"
        '
        'txtatnum
        '
        Me.txtatnum.Location = New System.Drawing.Point(95, 15)
        Me.txtatnum.Name = "txtatnum"
        Me.txtatnum.Size = New System.Drawing.Size(89, 22)
        Me.txtatnum.TabIndex = 3
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label54)
        Me.GroupBox2.Controls.Add(Me.DateTimeWO)
        Me.GroupBox2.Controls.Add(Me.Label51)
        Me.GroupBox2.Controls.Add(Me.Label52)
        Me.GroupBox2.Controls.Add(Me.btnPrintWO)
        Me.GroupBox2.Controls.Add(Me.txtwotext)
        Me.GroupBox2.Controls.Add(Me.CmbShopStatus)
        Me.GroupBox2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(3, 728)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(619, 184)
        Me.GroupBox2.TabIndex = 4
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Work Order"
        Me.GroupBox2.Visible = False
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(479, 71)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(100, 16)
        Me.Label54.TabIndex = 5
        Me.Label54.Text = "Delivery Time:"
        '
        'DateTimeWO
        '
        Me.DateTimeWO.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTimeWO.Location = New System.Drawing.Point(479, 90)
        Me.DateTimeWO.Name = "DateTimeWO"
        Me.DateTimeWO.Size = New System.Drawing.Size(133, 22)
        Me.DateTimeWO.TabIndex = 1
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.Location = New System.Drawing.Point(476, 25)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(42, 16)
        Me.Label51.TabIndex = 5
        Me.Label51.Text = "Shop:"
        Me.Label51.Visible = False
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(479, 115)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(62, 16)
        Me.Label52.TabIndex = 3
        Me.Label52.Text = "Number:"
        '
        'btnPrintWO
        '
        Me.btnPrintWO.Location = New System.Drawing.Point(495, 150)
        Me.btnPrintWO.Name = "btnPrintWO"
        Me.btnPrintWO.Size = New System.Drawing.Size(94, 23)
        Me.btnPrintWO.TabIndex = 3
        Me.btnPrintWO.Text = "Print"
        Me.btnPrintWO.UseVisualStyleBackColor = True
        '
        'txtwotext
        '
        Me.txtwotext.Location = New System.Drawing.Point(8, 22)
        Me.txtwotext.Multiline = True
        Me.txtwotext.Name = "txtwotext"
        Me.txtwotext.Size = New System.Drawing.Size(462, 151)
        Me.txtwotext.TabIndex = 0
        '
        'CmbShopStatus
        '
        Me.CmbShopStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbShopStatus.FormattingEnabled = True
        Me.CmbShopStatus.Location = New System.Drawing.Point(479, 44)
        Me.CmbShopStatus.Name = "CmbShopStatus"
        Me.CmbShopStatus.Size = New System.Drawing.Size(133, 24)
        Me.CmbShopStatus.TabIndex = 2
        Me.CmbShopStatus.Visible = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txtBOcommadjust)
        Me.GroupBox3.Controls.Add(Me.Label93)
        Me.GroupBox3.Controls.Add(Me.txtBOcommadjustnote)
        Me.GroupBox3.Controls.Add(Me.txtcommchange2)
        Me.GroupBox3.Controls.Add(Me.txtcommchange1)
        Me.GroupBox3.Controls.Add(Me.Label91)
        Me.GroupBox3.Controls.Add(Me.Label90)
        Me.GroupBox3.Controls.Add(Me.Label89)
        Me.GroupBox3.Controls.Add(Me.txtchange2note)
        Me.GroupBox3.Controls.Add(Me.txtchange1note)
        Me.GroupBox3.Controls.Add(Me.btnChangeSalesman)
        Me.GroupBox3.Controls.Add(Me.Label53)
        Me.GroupBox3.Controls.Add(Me.btnSplitDeal)
        Me.GroupBox3.Controls.Add(Me.txtsalesman2)
        Me.GroupBox3.Controls.Add(Me.txtsalesman)
        Me.GroupBox3.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(3, 1)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(624, 169)
        Me.GroupBox3.TabIndex = 5
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Sold By"
        '
        'txtBOcommadjust
        '
        Me.txtBOcommadjust.Enabled = False
        Me.txtBOcommadjust.Location = New System.Drawing.Point(520, 114)
        Me.txtBOcommadjust.Name = "txtBOcommadjust"
        Me.txtBOcommadjust.Size = New System.Drawing.Size(61, 22)
        Me.txtBOcommadjust.TabIndex = 13
        '
        'Label93
        '
        Me.Label93.AutoSize = True
        Me.Label93.Location = New System.Drawing.Point(5, 120)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(119, 16)
        Me.Label93.TabIndex = 12
        Me.Label93.Text = "Finance Manager"
        '
        'txtBOcommadjustnote
        '
        Me.txtBOcommadjustnote.Enabled = False
        Me.txtBOcommadjustnote.Location = New System.Drawing.Point(130, 114)
        Me.txtBOcommadjustnote.Name = "txtBOcommadjustnote"
        Me.txtBOcommadjustnote.Size = New System.Drawing.Size(384, 22)
        Me.txtBOcommadjustnote.TabIndex = 11
        '
        'txtcommchange2
        '
        Me.txtcommchange2.Enabled = False
        Me.txtcommchange2.Location = New System.Drawing.Point(520, 85)
        Me.txtcommchange2.Name = "txtcommchange2"
        Me.txtcommchange2.Size = New System.Drawing.Size(61, 22)
        Me.txtcommchange2.TabIndex = 10
        '
        'txtcommchange1
        '
        Me.txtcommchange1.Enabled = False
        Me.txtcommchange1.Location = New System.Drawing.Point(520, 57)
        Me.txtcommchange1.Name = "txtcommchange1"
        Me.txtcommchange1.Size = New System.Drawing.Size(61, 22)
        Me.txtcommchange1.TabIndex = 9
        '
        'Label91
        '
        Me.Label91.AutoSize = True
        Me.Label91.Location = New System.Drawing.Point(43, 91)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(82, 16)
        Me.Label91.TabIndex = 8
        Me.Label91.Text = "Salesmen 2"
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Location = New System.Drawing.Point(43, 63)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(82, 16)
        Me.Label90.TabIndex = 7
        Me.Label90.Text = "Salesmen 1"
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.Location = New System.Drawing.Point(9, 38)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(160, 16)
        Me.Label89.TabIndex = 6
        Me.Label89.Text = "Commision Adjustments"
        '
        'txtchange2note
        '
        Me.txtchange2note.Enabled = False
        Me.txtchange2note.Location = New System.Drawing.Point(130, 85)
        Me.txtchange2note.Name = "txtchange2note"
        Me.txtchange2note.Size = New System.Drawing.Size(384, 22)
        Me.txtchange2note.TabIndex = 5
        '
        'txtchange1note
        '
        Me.txtchange1note.Enabled = False
        Me.txtchange1note.Location = New System.Drawing.Point(130, 57)
        Me.txtchange1note.Name = "txtchange1note"
        Me.txtchange1note.Size = New System.Drawing.Size(384, 22)
        Me.txtchange1note.TabIndex = 4
        '
        'btnChangeSalesman
        '
        Me.btnChangeSalesman.Location = New System.Drawing.Point(211, 10)
        Me.btnChangeSalesman.Name = "btnChangeSalesman"
        Me.btnChangeSalesman.Size = New System.Drawing.Size(84, 23)
        Me.btnChangeSalesman.TabIndex = 0
        Me.btnChangeSalesman.Text = "Change"
        Me.btnChangeSalesman.UseVisualStyleBackColor = True
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.Location = New System.Drawing.Point(299, 13)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(69, 16)
        Me.Label53.TabIndex = 3
        Me.Label53.Text = "Split With:"
        '
        'btnSplitDeal
        '
        Me.btnSplitDeal.Location = New System.Drawing.Point(520, 10)
        Me.btnSplitDeal.Name = "btnSplitDeal"
        Me.btnSplitDeal.Size = New System.Drawing.Size(84, 23)
        Me.btnSplitDeal.TabIndex = 1
        Me.btnSplitDeal.Text = "Split Deal"
        Me.btnSplitDeal.UseVisualStyleBackColor = True
        '
        'txtsalesman2
        '
        Me.txtsalesman2.Location = New System.Drawing.Point(374, 11)
        Me.txtsalesman2.Name = "txtsalesman2"
        Me.txtsalesman2.ReadOnly = True
        Me.txtsalesman2.Size = New System.Drawing.Size(140, 22)
        Me.txtsalesman2.TabIndex = 1
        '
        'txtsalesman
        '
        Me.txtsalesman.Location = New System.Drawing.Point(65, 11)
        Me.txtsalesman.Name = "txtsalesman"
        Me.txtsalesman.ReadOnly = True
        Me.txtsalesman.Size = New System.Drawing.Size(140, 22)
        Me.txtsalesman.TabIndex = 0
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Panel5)
        Me.GroupBox1.Controls.Add(Me.Label74)
        Me.GroupBox1.Controls.Add(Me.cmbCommissioned)
        Me.GroupBox1.Controls.Add(Me.btnDelivered)
        Me.GroupBox1.Controls.Add(Me.btnVoid)
        Me.GroupBox1.Controls.Add(Me.Label50)
        Me.GroupBox1.Controls.Add(Me.Label49)
        Me.GroupBox1.Controls.Add(Me.cmbFinanceStatus)
        Me.GroupBox1.Controls.Add(Me.cmbDealStatus)
        Me.GroupBox1.Controls.Add(Me.Panel4)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(3, 173)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(624, 119)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Status"
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.Gainsboro
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel5.Controls.Add(Me.rfin)
        Me.Panel5.Controls.Add(Me.rcash)
        Me.Panel5.Location = New System.Drawing.Point(8, 59)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(160, 54)
        Me.Panel5.TabIndex = 12
        Me.Panel5.Visible = False
        '
        'rfin
        '
        Me.rfin.AutoCheck = False
        Me.rfin.AutoSize = True
        Me.rfin.Location = New System.Drawing.Point(18, 31)
        Me.rfin.Name = "rfin"
        Me.rfin.Size = New System.Drawing.Size(85, 20)
        Me.rfin.TabIndex = 13
        Me.rfin.TabStop = True
        Me.rfin.Text = "Financed"
        Me.rfin.UseVisualStyleBackColor = True
        '
        'rcash
        '
        Me.rcash.AutoCheck = False
        Me.rcash.AutoSize = True
        Me.rcash.Location = New System.Drawing.Point(18, 3)
        Me.rcash.Name = "rcash"
        Me.rcash.Size = New System.Drawing.Size(57, 20)
        Me.rcash.TabIndex = 12
        Me.rcash.TabStop = True
        Me.rcash.Text = "Cash"
        Me.rcash.UseVisualStyleBackColor = True
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label74.Location = New System.Drawing.Point(431, 7)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(98, 16)
        Me.Label74.TabIndex = 8
        Me.Label74.Text = "Commissioned:"
        '
        'cmbCommissioned
        '
        Me.cmbCommissioned.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbCommissioned.Enabled = False
        Me.cmbCommissioned.FormattingEnabled = True
        Me.cmbCommissioned.Items.AddRange(New Object() {"NO", "YES"})
        Me.cmbCommissioned.Location = New System.Drawing.Point(441, 25)
        Me.cmbCommissioned.Name = "cmbCommissioned"
        Me.cmbCommissioned.Size = New System.Drawing.Size(88, 24)
        Me.cmbCommissioned.TabIndex = 7
        '
        'btnDelivered
        '
        Me.btnDelivered.Location = New System.Drawing.Point(535, 6)
        Me.btnDelivered.Name = "btnDelivered"
        Me.btnDelivered.Size = New System.Drawing.Size(84, 23)
        Me.btnDelivered.TabIndex = 6
        Me.btnDelivered.Text = "Delivered"
        Me.btnDelivered.UseVisualStyleBackColor = True
        Me.btnDelivered.Visible = False
        '
        'btnVoid
        '
        Me.btnVoid.Enabled = False
        Me.btnVoid.Location = New System.Drawing.Point(535, 30)
        Me.btnVoid.Name = "btnVoid"
        Me.btnVoid.Size = New System.Drawing.Size(84, 23)
        Me.btnVoid.TabIndex = 3
        Me.btnVoid.Text = "Void"
        Me.btnVoid.UseVisualStyleBackColor = True
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.Location = New System.Drawing.Point(210, 6)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(58, 16)
        Me.Label50.TabIndex = 4
        Me.Label50.Text = "Finance:"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.Location = New System.Drawing.Point(49, 6)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(38, 16)
        Me.Label49.TabIndex = 3
        Me.Label49.Text = "Deal:"
        '
        'cmbFinanceStatus
        '
        Me.cmbFinanceStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbFinanceStatus.FormattingEnabled = True
        Me.cmbFinanceStatus.Location = New System.Drawing.Point(213, 25)
        Me.cmbFinanceStatus.Name = "cmbFinanceStatus"
        Me.cmbFinanceStatus.Size = New System.Drawing.Size(155, 24)
        Me.cmbFinanceStatus.TabIndex = 1
        '
        'cmbDealStatus
        '
        Me.cmbDealStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbDealStatus.FormattingEnabled = True
        Me.cmbDealStatus.Location = New System.Drawing.Point(52, 25)
        Me.cmbDealStatus.Name = "cmbDealStatus"
        Me.cmbDealStatus.Size = New System.Drawing.Size(155, 24)
        Me.cmbDealStatus.TabIndex = 0
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Gainsboro
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.Label75)
        Me.Panel4.Controls.Add(Me.txthiddenfincode)
        Me.Panel4.Controls.Add(Me.txtinssold)
        Me.Panel4.Controls.Add(Me.runins)
        Me.Panel4.Controls.Add(Me.rins)
        Me.Panel4.Location = New System.Drawing.Point(173, 59)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(445, 54)
        Me.Panel4.TabIndex = 9
        Me.Panel4.Visible = False
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Location = New System.Drawing.Point(325, 7)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(103, 16)
        Me.Label75.TabIndex = 12
        Me.Label75.Text = "Insurance Amt."
        '
        'txthiddenfincode
        '
        Me.txthiddenfincode.Location = New System.Drawing.Point(220, 26)
        Me.txthiddenfincode.Name = "txthiddenfincode"
        Me.txthiddenfincode.Size = New System.Drawing.Size(100, 22)
        Me.txthiddenfincode.TabIndex = 11
        Me.txthiddenfincode.Visible = False
        '
        'txtinssold
        '
        Me.txtinssold.Location = New System.Drawing.Point(326, 26)
        Me.txtinssold.Name = "txtinssold"
        Me.txtinssold.ReadOnly = True
        Me.txtinssold.Size = New System.Drawing.Size(100, 22)
        Me.txtinssold.TabIndex = 4
        '
        'runins
        '
        Me.runins.AutoCheck = False
        Me.runins.AutoSize = True
        Me.runins.Location = New System.Drawing.Point(26, 3)
        Me.runins.Name = "runins"
        Me.runins.Size = New System.Drawing.Size(157, 20)
        Me.runins.TabIndex = 3
        Me.runins.TabStop = True
        Me.runins.Text = "Financing Uninsured"
        Me.runins.UseVisualStyleBackColor = True
        '
        'rins
        '
        Me.rins.AutoCheck = False
        Me.rins.AutoSize = True
        Me.rins.Location = New System.Drawing.Point(26, 29)
        Me.rins.Name = "rins"
        Me.rins.Size = New System.Drawing.Size(140, 20)
        Me.rins.TabIndex = 2
        Me.rins.TabStop = True
        Me.rins.Text = "Financing Insured"
        Me.rins.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.txtnotes)
        Me.GroupBox4.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(3, 298)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(350, 252)
        Me.GroupBox4.TabIndex = 6
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Notes:"
        '
        'txtnotes
        '
        Me.txtnotes.Location = New System.Drawing.Point(8, 26)
        Me.txtnotes.Multiline = True
        Me.txtnotes.Name = "txtnotes"
        Me.txtnotes.Size = New System.Drawing.Size(332, 214)
        Me.txtnotes.TabIndex = 0
        '
        'GroupBox18
        '
        Me.GroupBox18.Controls.Add(Me.txtwodate)
        Me.GroupBox18.Controls.Add(Me.txtwostatus)
        Me.GroupBox18.Controls.Add(Me.Label97)
        Me.GroupBox18.Controls.Add(Me.Label98)
        Me.GroupBox18.Controls.Add(Me.btnCreateWO)
        Me.GroupBox18.Controls.Add(Me.txtwostore)
        Me.GroupBox18.Controls.Add(Me.txtwonumber)
        Me.GroupBox18.Controls.Add(Me.Label95)
        Me.GroupBox18.Controls.Add(Me.Label96)
        Me.GroupBox18.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox18.Location = New System.Drawing.Point(362, 298)
        Me.GroupBox18.Name = "GroupBox18"
        Me.GroupBox18.Size = New System.Drawing.Size(265, 169)
        Me.GroupBox18.TabIndex = 7
        Me.GroupBox18.TabStop = False
        Me.GroupBox18.Text = "Work Order"
        '
        'txtwodate
        '
        Me.txtwodate.Enabled = False
        Me.txtwodate.Location = New System.Drawing.Point(91, 110)
        Me.txtwodate.Name = "txtwodate"
        Me.txtwodate.Size = New System.Drawing.Size(168, 22)
        Me.txtwodate.TabIndex = 17
        '
        'txtwostatus
        '
        Me.txtwostatus.Enabled = False
        Me.txtwostatus.Location = New System.Drawing.Point(91, 82)
        Me.txtwostatus.Name = "txtwostatus"
        Me.txtwostatus.Size = New System.Drawing.Size(168, 22)
        Me.txtwostatus.TabIndex = 16
        '
        'Label97
        '
        Me.Label97.AutoSize = True
        Me.Label97.Location = New System.Drawing.Point(17, 116)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(66, 16)
        Me.Label97.TabIndex = 15
        Me.Label97.Text = "Del Date:"
        '
        'Label98
        '
        Me.Label98.AutoSize = True
        Me.Label98.Location = New System.Drawing.Point(7, 88)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(78, 16)
        Me.Label98.TabIndex = 14
        Me.Label98.Text = "WO Status:"
        '
        'btnCreateWO
        '
        Me.btnCreateWO.Location = New System.Drawing.Point(82, 138)
        Me.btnCreateWO.Name = "btnCreateWO"
        Me.btnCreateWO.Size = New System.Drawing.Size(104, 23)
        Me.btnCreateWO.TabIndex = 13
        Me.btnCreateWO.Text = "Create WO"
        Me.btnCreateWO.UseVisualStyleBackColor = True
        '
        'txtwostore
        '
        Me.txtwostore.Enabled = False
        Me.txtwostore.Location = New System.Drawing.Point(141, 54)
        Me.txtwostore.Name = "txtwostore"
        Me.txtwostore.Size = New System.Drawing.Size(83, 22)
        Me.txtwostore.TabIndex = 12
        '
        'txtwonumber
        '
        Me.txtwonumber.Enabled = False
        Me.txtwonumber.Location = New System.Drawing.Point(141, 26)
        Me.txtwonumber.Name = "txtwonumber"
        Me.txtwonumber.Size = New System.Drawing.Size(83, 22)
        Me.txtwonumber.TabIndex = 11
        '
        'Label95
        '
        Me.Label95.AutoSize = True
        Me.Label95.Location = New System.Drawing.Point(62, 60)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(73, 16)
        Me.Label95.TabIndex = 10
        Me.Label95.Text = "WO Store:"
        '
        'Label96
        '
        Me.Label96.AutoSize = True
        Me.Label96.Location = New System.Drawing.Point(46, 29)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(89, 16)
        Me.Label96.TabIndex = 9
        Me.Label96.Text = "WO Number:"
        '
        'Finance
        '
        Me.Finance.Controls.Add(Me.Panel3)
        Me.Finance.Location = New System.Drawing.Point(4, 25)
        Me.Finance.Name = "Finance"
        Me.Finance.Size = New System.Drawing.Size(799, 994)
        Me.Finance.TabIndex = 2
        Me.Finance.Text = "Finance"
        Me.Finance.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.AutoScroll = True
        Me.Panel3.Controls.Add(Me.Label104)
        Me.Panel3.Controls.Add(Me.txttotalfin)
        Me.Panel3.Controls.Add(Me.Label102)
        Me.Panel3.Controls.Add(Me.GroupBox7)
        Me.Panel3.Controls.Add(Me.GroupBox8)
        Me.Panel3.Controls.Add(Me.Label103)
        Me.Panel3.Controls.Add(Me.txtbolien)
        Me.Panel3.Controls.Add(Me.btnTradeLienCTC)
        Me.Panel3.Controls.Add(Me.btnTradeInCTC)
        Me.Panel3.Controls.Add(Me.txtbowarranty)
        Me.Panel3.Controls.Add(Me.txtbotrade)
        Me.Panel3.Controls.Add(Me.btnWarrantyCTC)
        Me.Panel3.Controls.Add(Me.Label100)
        Me.Panel3.Controls.Add(Me.Label99)
        Me.Panel3.Controls.Add(Me.txtbocashprice)
        Me.Panel3.Controls.Add(Me.btnCashPriceCTC)
        Me.Panel3.Controls.Add(Me.btnDownPmtCTC)
        Me.Panel3.Controls.Add(Me.btnPrintInsRequest)
        Me.Panel3.Controls.Add(Me.Label101)
        Me.Panel3.Controls.Add(Me.GroupBox16)
        Me.Panel3.Controls.Add(Me.GroupBox9)
        Me.Panel3.Controls.Add(Me.GroupBox15)
        Me.Panel3.Controls.Add(Me.txtbodown)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(799, 994)
        Me.Panel3.TabIndex = 0
        '
        'Label104
        '
        Me.Label104.AutoSize = True
        Me.Label104.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label104.Location = New System.Drawing.Point(439, 811)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(77, 32)
        Me.Label104.TabIndex = 222
        Me.Label104.Text = "TOTAL " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "FINANCED:"
        '
        'txttotalfin
        '
        Me.txttotalfin.Enabled = False
        Me.txttotalfin.Location = New System.Drawing.Point(520, 821)
        Me.txttotalfin.Name = "txttotalfin"
        Me.txttotalfin.Size = New System.Drawing.Size(89, 22)
        Me.txttotalfin.TabIndex = 221
        '
        'Label102
        '
        Me.Label102.AutoSize = True
        Me.Label102.Location = New System.Drawing.Point(438, 763)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(72, 16)
        Me.Label102.TabIndex = 217
        Me.Label102.Text = "Trade Lien:"
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.Label92)
        Me.GroupBox7.Controls.Add(Me.txtfinancefee)
        Me.GroupBox7.Controls.Add(Me.Label72)
        Me.GroupBox7.Controls.Add(Me.txtBankFee)
        Me.GroupBox7.Controls.Add(Me.Label80)
        Me.GroupBox7.Controls.Add(Me.txtreserve)
        Me.GroupBox7.Controls.Add(Me.txtammover)
        Me.GroupBox7.Controls.Add(Me.txtrateover)
        Me.GroupBox7.Controls.Add(Me.Label60)
        Me.GroupBox7.Controls.Add(Me.Label59)
        Me.GroupBox7.Controls.Add(Me.Label58)
        Me.GroupBox7.Controls.Add(Me.cmbrate)
        Me.GroupBox7.Controls.Add(Me.cmbammort)
        Me.GroupBox7.Controls.Add(Me.cmbTerm)
        Me.GroupBox7.Controls.Add(Me.ListBanks)
        Me.GroupBox7.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox7.Location = New System.Drawing.Point(3, 5)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(403, 244)
        Me.GroupBox7.TabIndex = 199
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Bank Info"
        '
        'Label92
        '
        Me.Label92.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label92.AutoSize = True
        Me.Label92.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label92.Location = New System.Drawing.Point(181, 222)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(84, 16)
        Me.Label92.TabIndex = 15
        Me.Label92.Text = "Finance Fee:"
        '
        'txtfinancefee
        '
        Me.txtfinancefee.Location = New System.Drawing.Point(271, 216)
        Me.txtfinancefee.Name = "txtfinancefee"
        Me.txtfinancefee.Size = New System.Drawing.Size(102, 22)
        Me.txtfinancefee.TabIndex = 14
        '
        'Label72
        '
        Me.Label72.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label72.AutoSize = True
        Me.Label72.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label72.Location = New System.Drawing.Point(188, 191)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(77, 16)
        Me.Label72.TabIndex = 13
        Me.Label72.Text = "Bank's Fee:"
        '
        'txtBankFee
        '
        Me.txtBankFee.Location = New System.Drawing.Point(271, 188)
        Me.txtBankFee.Name = "txtBankFee"
        Me.txtBankFee.Size = New System.Drawing.Size(102, 22)
        Me.txtBankFee.TabIndex = 12
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Location = New System.Drawing.Point(31, 194)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(59, 16)
        Me.Label80.TabIndex = 2
        Me.Label80.Text = "Reserve"
        '
        'txtreserve
        '
        Me.txtreserve.Enabled = False
        Me.txtreserve.Location = New System.Drawing.Point(41, 213)
        Me.txtreserve.Name = "txtreserve"
        Me.txtreserve.Size = New System.Drawing.Size(89, 22)
        Me.txtreserve.TabIndex = 1
        '
        'txtammover
        '
        Me.txtammover.Location = New System.Drawing.Point(277, 73)
        Me.txtammover.Name = "txtammover"
        Me.txtammover.Size = New System.Drawing.Size(102, 22)
        Me.txtammover.TabIndex = 11
        '
        'txtrateover
        '
        Me.txtrateover.Location = New System.Drawing.Point(277, 101)
        Me.txtrateover.Name = "txtrateover"
        Me.txtrateover.Size = New System.Drawing.Size(102, 22)
        Me.txtrateover.TabIndex = 10
        '
        'Label60
        '
        Me.Label60.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label60.AutoSize = True
        Me.Label60.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label60.Location = New System.Drawing.Point(236, 107)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(39, 16)
        Me.Label60.TabIndex = 9
        Me.Label60.Text = "Rate:"
        '
        'Label59
        '
        Me.Label59.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label59.AutoSize = True
        Me.Label59.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.Location = New System.Drawing.Point(215, 51)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(58, 16)
        Me.Label59.TabIndex = 8
        Me.Label59.Text = "Ammort:"
        '
        'Label58
        '
        Me.Label58.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label58.AutoSize = True
        Me.Label58.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label58.Location = New System.Drawing.Point(234, 21)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(36, 16)
        Me.Label58.TabIndex = 7
        Me.Label58.Text = "Term"
        '
        'cmbrate
        '
        Me.cmbrate.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmbrate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbrate.FormattingEnabled = True
        Me.cmbrate.Location = New System.Drawing.Point(277, 129)
        Me.cmbrate.Name = "cmbrate"
        Me.cmbrate.Size = New System.Drawing.Size(102, 24)
        Me.cmbrate.TabIndex = 3
        Me.cmbrate.Visible = False
        '
        'cmbammort
        '
        Me.cmbammort.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmbammort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbammort.FormattingEnabled = True
        Me.cmbammort.Items.AddRange(New Object() {"12", "24", "36", "48", "60", "72", "84", "96", "108", "120", "132", "144", "156", "168", "180", "192", "204", "216", "228", "240"})
        Me.cmbammort.Location = New System.Drawing.Point(277, 43)
        Me.cmbammort.Name = "cmbammort"
        Me.cmbammort.Size = New System.Drawing.Size(102, 24)
        Me.cmbammort.TabIndex = 2
        '
        'cmbTerm
        '
        Me.cmbTerm.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmbTerm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbTerm.FormattingEnabled = True
        Me.cmbTerm.Items.AddRange(New Object() {"12", "24", "36", "48", "60", "72", "84", "96", "108", "120", "132", "144", "156", "168", "180", "192", "204", "216", "228", "240"})
        Me.cmbTerm.Location = New System.Drawing.Point(277, 13)
        Me.cmbTerm.Name = "cmbTerm"
        Me.cmbTerm.Size = New System.Drawing.Size(102, 24)
        Me.cmbTerm.TabIndex = 1
        '
        'ListBanks
        '
        Me.ListBanks.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBanks.FormattingEnabled = True
        Me.ListBanks.ItemHeight = 16
        Me.ListBanks.Location = New System.Drawing.Point(20, 21)
        Me.ListBanks.Name = "ListBanks"
        Me.ListBanks.Size = New System.Drawing.Size(187, 148)
        Me.ListBanks.TabIndex = 0
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.txtbizman)
        Me.GroupBox8.Controls.Add(Me.btnBizmanChange)
        Me.GroupBox8.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox8.Location = New System.Drawing.Point(410, 188)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(202, 79)
        Me.GroupBox8.TabIndex = 200
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Buisness Manager"
        '
        'txtbizman
        '
        Me.txtbizman.Location = New System.Drawing.Point(26, 21)
        Me.txtbizman.Name = "txtbizman"
        Me.txtbizman.ReadOnly = True
        Me.txtbizman.Size = New System.Drawing.Size(158, 22)
        Me.txtbizman.TabIndex = 5
        '
        'btnBizmanChange
        '
        Me.btnBizmanChange.Location = New System.Drawing.Point(70, 49)
        Me.btnBizmanChange.Name = "btnBizmanChange"
        Me.btnBizmanChange.Size = New System.Drawing.Size(75, 23)
        Me.btnBizmanChange.TabIndex = 6
        Me.btnBizmanChange.Text = "Reassign"
        Me.btnBizmanChange.UseVisualStyleBackColor = True
        '
        'Label103
        '
        Me.Label103.AutoSize = True
        Me.Label103.Location = New System.Drawing.Point(445, 603)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(65, 16)
        Me.Label103.TabIndex = 220
        Me.Label103.Text = "Warranty:"
        '
        'txtbolien
        '
        Me.txtbolien.Enabled = False
        Me.txtbolien.Location = New System.Drawing.Point(516, 760)
        Me.txtbolien.Name = "txtbolien"
        Me.txtbolien.Size = New System.Drawing.Size(89, 22)
        Me.txtbolien.TabIndex = 216
        '
        'btnTradeLienCTC
        '
        Me.btnTradeLienCTC.Location = New System.Drawing.Point(456, 785)
        Me.btnTradeLienCTC.Name = "btnTradeLienCTC"
        Me.btnTradeLienCTC.Size = New System.Drawing.Size(131, 23)
        Me.btnTradeLienCTC.TabIndex = 215
        Me.btnTradeLienCTC.Text = "Copy to Clipboard"
        Me.btnTradeLienCTC.UseVisualStyleBackColor = True
        '
        'btnTradeInCTC
        '
        Me.btnTradeInCTC.Location = New System.Drawing.Point(455, 731)
        Me.btnTradeInCTC.Name = "btnTradeInCTC"
        Me.btnTradeInCTC.Size = New System.Drawing.Size(131, 23)
        Me.btnTradeInCTC.TabIndex = 206
        Me.btnTradeInCTC.Text = "Copy to Clipboard"
        Me.btnTradeInCTC.UseVisualStyleBackColor = True
        '
        'txtbowarranty
        '
        Me.txtbowarranty.Enabled = False
        Me.txtbowarranty.Location = New System.Drawing.Point(516, 597)
        Me.txtbowarranty.Name = "txtbowarranty"
        Me.txtbowarranty.Size = New System.Drawing.Size(89, 22)
        Me.txtbowarranty.TabIndex = 219
        '
        'txtbotrade
        '
        Me.txtbotrade.Enabled = False
        Me.txtbotrade.Location = New System.Drawing.Point(515, 705)
        Me.txtbotrade.Name = "txtbotrade"
        Me.txtbotrade.Size = New System.Drawing.Size(89, 22)
        Me.txtbotrade.TabIndex = 210
        '
        'btnWarrantyCTC
        '
        Me.btnWarrantyCTC.Location = New System.Drawing.Point(456, 622)
        Me.btnWarrantyCTC.Name = "btnWarrantyCTC"
        Me.btnWarrantyCTC.Size = New System.Drawing.Size(131, 23)
        Me.btnWarrantyCTC.TabIndex = 218
        Me.btnWarrantyCTC.Text = "Copy to Clipboard"
        Me.btnWarrantyCTC.UseVisualStyleBackColor = True
        '
        'Label100
        '
        Me.Label100.AutoSize = True
        Me.Label100.Location = New System.Drawing.Point(451, 708)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(58, 16)
        Me.Label100.TabIndex = 211
        Me.Label100.Text = "Trade In:"
        '
        'Label99
        '
        Me.Label99.AutoSize = True
        Me.Label99.Location = New System.Drawing.Point(433, 546)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(76, 16)
        Me.Label99.TabIndex = 209
        Me.Label99.Text = "Cash Price:"
        '
        'txtbocashprice
        '
        Me.txtbocashprice.Enabled = False
        Me.txtbocashprice.Location = New System.Drawing.Point(515, 543)
        Me.txtbocashprice.Name = "txtbocashprice"
        Me.txtbocashprice.Size = New System.Drawing.Size(89, 22)
        Me.txtbocashprice.TabIndex = 208
        '
        'btnCashPriceCTC
        '
        Me.btnCashPriceCTC.Location = New System.Drawing.Point(455, 568)
        Me.btnCashPriceCTC.Name = "btnCashPriceCTC"
        Me.btnCashPriceCTC.Size = New System.Drawing.Size(131, 23)
        Me.btnCashPriceCTC.TabIndex = 207
        Me.btnCashPriceCTC.Text = "Copy to Clipboard"
        Me.btnCashPriceCTC.UseVisualStyleBackColor = True
        '
        'btnDownPmtCTC
        '
        Me.btnDownPmtCTC.Location = New System.Drawing.Point(454, 676)
        Me.btnDownPmtCTC.Name = "btnDownPmtCTC"
        Me.btnDownPmtCTC.Size = New System.Drawing.Size(131, 23)
        Me.btnDownPmtCTC.TabIndex = 212
        Me.btnDownPmtCTC.Text = "Copy to Clipboard"
        Me.btnDownPmtCTC.UseVisualStyleBackColor = True
        '
        'btnPrintInsRequest
        '
        Me.btnPrintInsRequest.Location = New System.Drawing.Point(24, 677)
        Me.btnPrintInsRequest.Name = "btnPrintInsRequest"
        Me.btnPrintInsRequest.Size = New System.Drawing.Size(158, 25)
        Me.btnPrintInsRequest.TabIndex = 205
        Me.btnPrintInsRequest.Text = "Print Insurance Request"
        Me.btnPrintInsRequest.UseVisualStyleBackColor = True
        '
        'Label101
        '
        Me.Label101.AutoSize = True
        Me.Label101.Location = New System.Drawing.Point(408, 654)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(100, 16)
        Me.Label101.TabIndex = 214
        Me.Label101.Text = "Down Payment:"
        '
        'GroupBox16
        '
        Me.GroupBox16.Controls.Add(Me.Label83)
        Me.GroupBox16.Controls.Add(Me.CmbPTinstalled)
        Me.GroupBox16.Controls.Add(Me.Label86)
        Me.GroupBox16.Controls.Add(Me.CmbPTreg)
        Me.GroupBox16.Controls.Add(Me.Label85)
        Me.GroupBox16.Controls.Add(Me.CmbPTrtb)
        Me.GroupBox16.Controls.Add(Me.Label82)
        Me.GroupBox16.Controls.Add(Me.txtPTcost)
        Me.GroupBox16.Controls.Add(Me.Label84)
        Me.GroupBox16.Controls.Add(Me.CmbPTfabric)
        Me.GroupBox16.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox16.Location = New System.Drawing.Point(410, 5)
        Me.GroupBox16.Name = "GroupBox16"
        Me.GroupBox16.Size = New System.Drawing.Size(200, 177)
        Me.GroupBox16.TabIndex = 204
        Me.GroupBox16.TabStop = False
        Me.GroupBox16.Text = "Protech"
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Location = New System.Drawing.Point(43, 121)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(61, 16)
        Me.Label83.TabIndex = 28
        Me.Label83.Text = "Applied:"
        '
        'CmbPTinstalled
        '
        Me.CmbPTinstalled.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbPTinstalled.FormattingEnabled = True
        Me.CmbPTinstalled.Items.AddRange(New Object() {"NO", "YES"})
        Me.CmbPTinstalled.Location = New System.Drawing.Point(117, 118)
        Me.CmbPTinstalled.Name = "CmbPTinstalled"
        Me.CmbPTinstalled.Size = New System.Drawing.Size(74, 24)
        Me.CmbPTinstalled.TabIndex = 27
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.Location = New System.Drawing.Point(43, 33)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(64, 16)
        Me.Label86.TabIndex = 26
        Me.Label86.Text = "Register:"
        '
        'CmbPTreg
        '
        Me.CmbPTreg.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbPTreg.FormattingEnabled = True
        Me.CmbPTreg.Items.AddRange(New Object() {"NO", "YES"})
        Me.CmbPTreg.Location = New System.Drawing.Point(117, 30)
        Me.CmbPTreg.Name = "CmbPTreg"
        Me.CmbPTreg.Size = New System.Drawing.Size(74, 24)
        Me.CmbPTreg.TabIndex = 25
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.Location = New System.Drawing.Point(23, 63)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(84, 16)
        Me.Label85.TabIndex = 24
        Me.Label85.Text = "R, T and Bs:"
        '
        'CmbPTrtb
        '
        Me.CmbPTrtb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbPTrtb.FormattingEnabled = True
        Me.CmbPTrtb.Items.AddRange(New Object() {"NO", "YES"})
        Me.CmbPTrtb.Location = New System.Drawing.Point(117, 60)
        Me.CmbPTrtb.Name = "CmbPTrtb"
        Me.CmbPTrtb.Size = New System.Drawing.Size(74, 24)
        Me.CmbPTrtb.TabIndex = 23
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Location = New System.Drawing.Point(12, 151)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(96, 16)
        Me.Label82.TabIndex = 22
        Me.Label82.Text = "Pro-tech Cost:"
        '
        'txtPTcost
        '
        Me.txtPTcost.Location = New System.Drawing.Point(116, 148)
        Me.txtPTcost.Name = "txtPTcost"
        Me.txtPTcost.ReadOnly = True
        Me.txtPTcost.Size = New System.Drawing.Size(75, 22)
        Me.txtPTcost.TabIndex = 21
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.Location = New System.Drawing.Point(53, 93)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(54, 16)
        Me.Label84.TabIndex = 18
        Me.Label84.Text = "Carpet:"
        '
        'CmbPTfabric
        '
        Me.CmbPTfabric.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbPTfabric.FormattingEnabled = True
        Me.CmbPTfabric.Items.AddRange(New Object() {"NO", "YES"})
        Me.CmbPTfabric.Location = New System.Drawing.Point(117, 90)
        Me.CmbPTfabric.Name = "CmbPTfabric"
        Me.CmbPTfabric.Size = New System.Drawing.Size(74, 24)
        Me.CmbPTfabric.TabIndex = 17
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.GroupBox20)
        Me.GroupBox9.Controls.Add(Me.GroupBox12)
        Me.GroupBox9.Controls.Add(Me.GroupBox13)
        Me.GroupBox9.Controls.Add(Me.GroupBox11)
        Me.GroupBox9.Controls.Add(Me.GroupBox10)
        Me.GroupBox9.Controls.Add(Me.GroupBox6)
        Me.GroupBox9.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox9.Location = New System.Drawing.Point(3, 253)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(403, 417)
        Me.GroupBox9.TabIndex = 201
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Insurance"
        '
        'GroupBox20
        '
        Me.GroupBox20.Controls.Add(Me.btnAPCopyToClip)
        Me.GroupBox20.Controls.Add(Me.Label118)
        Me.GroupBox20.Controls.Add(Me.TextBox7)
        Me.GroupBox20.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox20.Location = New System.Drawing.Point(6, 326)
        Me.GroupBox20.Name = "GroupBox20"
        Me.GroupBox20.Size = New System.Drawing.Size(186, 85)
        Me.GroupBox20.TabIndex = 12
        Me.GroupBox20.TabStop = False
        Me.GroupBox20.Text = "Accidental Plus"
        '
        'btnAPCopyToClip
        '
        Me.btnAPCopyToClip.Location = New System.Drawing.Point(28, 45)
        Me.btnAPCopyToClip.Name = "btnAPCopyToClip"
        Me.btnAPCopyToClip.Size = New System.Drawing.Size(131, 23)
        Me.btnAPCopyToClip.TabIndex = 11
        Me.btnAPCopyToClip.Text = "Copy to Clipboard"
        Me.btnAPCopyToClip.UseVisualStyleBackColor = True
        '
        'Label118
        '
        Me.Label118.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label118.AutoSize = True
        Me.Label118.Location = New System.Drawing.Point(34, 24)
        Me.Label118.Name = "Label118"
        Me.Label118.Size = New System.Drawing.Size(44, 16)
        Me.Label118.TabIndex = 8
        Me.Label118.Text = "Term:"
        '
        'TextBox7
        '
        Me.TextBox7.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox7.Enabled = False
        Me.TextBox7.Location = New System.Drawing.Point(85, 21)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(89, 22)
        Me.TextBox7.TabIndex = 2
        '
        'GroupBox12
        '
        Me.GroupBox12.Controls.Add(Me.btnCICopyToClip)
        Me.GroupBox12.Controls.Add(Me.Label66)
        Me.GroupBox12.Controls.Add(Me.Label65)
        Me.GroupBox12.Controls.Add(Me.TextBox4)
        Me.GroupBox12.Controls.Add(Me.TextBox5)
        Me.GroupBox12.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox12.Location = New System.Drawing.Point(6, 128)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Size = New System.Drawing.Size(186, 108)
        Me.GroupBox12.TabIndex = 2
        Me.GroupBox12.TabStop = False
        Me.GroupBox12.Text = "Critical Illness"
        '
        'btnCICopyToClip
        '
        Me.btnCICopyToClip.Location = New System.Drawing.Point(28, 75)
        Me.btnCICopyToClip.Name = "btnCICopyToClip"
        Me.btnCICopyToClip.Size = New System.Drawing.Size(131, 23)
        Me.btnCICopyToClip.TabIndex = 12
        Me.btnCICopyToClip.Text = "Copy to Clipboard"
        Me.btnCICopyToClip.UseVisualStyleBackColor = True
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Location = New System.Drawing.Point(13, 52)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(67, 16)
        Me.Label66.TabIndex = 6
        Me.Label66.Text = "Residual:"
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(34, 24)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(44, 16)
        Me.Label65.TabIndex = 5
        Me.Label65.Text = "Term:"
        '
        'TextBox4
        '
        Me.TextBox4.Enabled = False
        Me.TextBox4.Location = New System.Drawing.Point(85, 21)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(89, 22)
        Me.TextBox4.TabIndex = 3
        '
        'TextBox5
        '
        Me.TextBox5.Enabled = False
        Me.TextBox5.Location = New System.Drawing.Point(85, 49)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(89, 22)
        Me.TextBox5.TabIndex = 4
        '
        'GroupBox13
        '
        Me.GroupBox13.Controls.Add(Me.Label62)
        Me.GroupBox13.Controls.Add(Me.Label63)
        Me.GroupBox13.Controls.Add(Me.txtbday1)
        Me.GroupBox13.Controls.Add(Me.txtbday2)
        Me.GroupBox13.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox13.Location = New System.Drawing.Point(198, 282)
        Me.GroupBox13.Name = "GroupBox13"
        Me.GroupBox13.Size = New System.Drawing.Size(200, 108)
        Me.GroupBox13.TabIndex = 10
        Me.GroupBox13.TabStop = False
        Me.GroupBox13.Text = "Birthdays"
        '
        'Label62
        '
        Me.Label62.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(10, 18)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(60, 16)
        Me.Label62.TabIndex = 12
        Me.Label62.Text = "Buyer 1:"
        '
        'Label63
        '
        Me.Label63.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label63.AutoSize = True
        Me.Label63.Location = New System.Drawing.Point(10, 61)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(60, 16)
        Me.Label63.TabIndex = 13
        Me.Label63.Text = "Buyer 2:"
        '
        'txtbday1
        '
        Me.txtbday1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtbday1.Location = New System.Drawing.Point(55, 37)
        Me.txtbday1.Name = "txtbday1"
        Me.txtbday1.Size = New System.Drawing.Size(138, 22)
        Me.txtbday1.TabIndex = 10
        '
        'txtbday2
        '
        Me.txtbday2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtbday2.Location = New System.Drawing.Point(55, 80)
        Me.txtbday2.Name = "txtbday2"
        Me.txtbday2.Size = New System.Drawing.Size(138, 22)
        Me.txtbday2.TabIndex = 11
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.btnASCopyToClip)
        Me.GroupBox11.Controls.Add(Me.Label68)
        Me.GroupBox11.Controls.Add(Me.TextBox3)
        Me.GroupBox11.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox11.Location = New System.Drawing.Point(6, 239)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(186, 85)
        Me.GroupBox11.TabIndex = 1
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "Accident And Sickness"
        '
        'btnASCopyToClip
        '
        Me.btnASCopyToClip.Location = New System.Drawing.Point(28, 45)
        Me.btnASCopyToClip.Name = "btnASCopyToClip"
        Me.btnASCopyToClip.Size = New System.Drawing.Size(131, 23)
        Me.btnASCopyToClip.TabIndex = 11
        Me.btnASCopyToClip.Text = "Copy to Clipboard"
        Me.btnASCopyToClip.UseVisualStyleBackColor = True
        '
        'Label68
        '
        Me.Label68.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label68.AutoSize = True
        Me.Label68.Location = New System.Drawing.Point(34, 24)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(44, 16)
        Me.Label68.TabIndex = 8
        Me.Label68.Text = "Term:"
        '
        'TextBox3
        '
        Me.TextBox3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox3.Enabled = False
        Me.TextBox3.Location = New System.Drawing.Point(85, 21)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(89, 22)
        Me.TextBox3.TabIndex = 2
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.btnLICopyToClip)
        Me.GroupBox10.Controls.Add(Me.Label67)
        Me.GroupBox10.Controls.Add(Me.Label69)
        Me.GroupBox10.Controls.Add(Me.TextBox1)
        Me.GroupBox10.Controls.Add(Me.TextBox2)
        Me.GroupBox10.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox10.Location = New System.Drawing.Point(6, 23)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(186, 103)
        Me.GroupBox10.TabIndex = 0
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Life"
        '
        'btnLICopyToClip
        '
        Me.btnLICopyToClip.Location = New System.Drawing.Point(27, 64)
        Me.btnLICopyToClip.Name = "btnLICopyToClip"
        Me.btnLICopyToClip.Size = New System.Drawing.Size(131, 23)
        Me.btnLICopyToClip.TabIndex = 10
        Me.btnLICopyToClip.Text = "Copy to Clipboard"
        Me.btnLICopyToClip.UseVisualStyleBackColor = True
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Location = New System.Drawing.Point(34, 18)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(44, 16)
        Me.Label67.TabIndex = 7
        Me.Label67.Text = "Term:"
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Location = New System.Drawing.Point(12, 43)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(67, 16)
        Me.Label69.TabIndex = 9
        Me.Label69.Text = "Residual:"
        '
        'TextBox1
        '
        Me.TextBox1.Enabled = False
        Me.TextBox1.Location = New System.Drawing.Point(85, 12)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(89, 22)
        Me.TextBox1.TabIndex = 0
        '
        'TextBox2
        '
        Me.TextBox2.Enabled = False
        Me.TextBox2.Location = New System.Drawing.Point(85, 40)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(89, 22)
        Me.TextBox2.TabIndex = 1
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.cmbAccidentalPlus)
        Me.GroupBox6.Controls.Add(Me.Label61)
        Me.GroupBox6.Controls.Add(Me.cmbahtype)
        Me.GroupBox6.Controls.Add(Me.Label57)
        Me.GroupBox6.Controls.Add(Me.cmbcins)
        Me.GroupBox6.Controls.Add(Me.Label56)
        Me.GroupBox6.Controls.Add(Me.Label55)
        Me.GroupBox6.Controls.Add(Me.cmbains)
        Me.GroupBox6.Controls.Add(Me.cmblins)
        Me.GroupBox6.Controls.Add(Me.Label117)
        Me.GroupBox6.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox6.Location = New System.Drawing.Point(198, 21)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(200, 255)
        Me.GroupBox6.TabIndex = 1
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Insurance"
        '
        'cmbAccidentalPlus
        '
        Me.cmbAccidentalPlus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbAccidentalPlus.FormattingEnabled = True
        Me.cmbAccidentalPlus.Items.AddRange(New Object() {"Declined", "Buyer", "Co-Buyer", "Both"})
        Me.cmbAccidentalPlus.Location = New System.Drawing.Point(20, 218)
        Me.cmbAccidentalPlus.Name = "cmbAccidentalPlus"
        Me.cmbAccidentalPlus.Size = New System.Drawing.Size(168, 24)
        Me.cmbAccidentalPlus.TabIndex = 9
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label61.Location = New System.Drawing.Point(17, 153)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(73, 16)
        Me.Label61.TabIndex = 8
        Me.Label61.Text = "A && S Type"
        '
        'cmbahtype
        '
        Me.cmbahtype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbahtype.FormattingEnabled = True
        Me.cmbahtype.Items.AddRange(New Object() {"7 Day Retro", "14 Day Retro", "30 Day Retro", "30 Day Elim"})
        Me.cmbahtype.Location = New System.Drawing.Point(20, 172)
        Me.cmbahtype.Name = "cmbahtype"
        Me.cmbahtype.Size = New System.Drawing.Size(168, 24)
        Me.cmbahtype.TabIndex = 2
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label57.Location = New System.Drawing.Point(17, 61)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(89, 16)
        Me.Label57.TabIndex = 6
        Me.Label57.Text = "Critical Illness"
        '
        'cmbcins
        '
        Me.cmbcins.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbcins.FormattingEnabled = True
        Me.cmbcins.Items.AddRange(New Object() {"Declined", "Buyer", "Co-Buyer", "Both"})
        Me.cmbcins.Location = New System.Drawing.Point(20, 80)
        Me.cmbcins.Name = "cmbcins"
        Me.cmbcins.Size = New System.Drawing.Size(168, 24)
        Me.cmbcins.TabIndex = 3
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label56.Location = New System.Drawing.Point(17, 107)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(130, 16)
        Me.Label56.TabIndex = 4
        Me.Label56.Text = "Accident && Sickness"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.Location = New System.Drawing.Point(17, 16)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(28, 16)
        Me.Label55.TabIndex = 3
        Me.Label55.Text = "Life"
        '
        'cmbains
        '
        Me.cmbains.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbains.FormattingEnabled = True
        Me.cmbains.Items.AddRange(New Object() {"Declined", "Buyer", "Co-Buyer", "Both"})
        Me.cmbains.Location = New System.Drawing.Point(20, 126)
        Me.cmbains.Name = "cmbains"
        Me.cmbains.Size = New System.Drawing.Size(168, 24)
        Me.cmbains.TabIndex = 1
        '
        'cmblins
        '
        Me.cmblins.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmblins.FormattingEnabled = True
        Me.cmblins.Items.AddRange(New Object() {"Declined", "Buyer", "Co-Buyer", "Both"})
        Me.cmblins.Location = New System.Drawing.Point(20, 35)
        Me.cmblins.Name = "cmblins"
        Me.cmblins.Size = New System.Drawing.Size(168, 24)
        Me.cmblins.TabIndex = 0
        '
        'Label117
        '
        Me.Label117.AutoSize = True
        Me.Label117.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label117.Location = New System.Drawing.Point(17, 199)
        Me.Label117.Name = "Label117"
        Me.Label117.Size = New System.Drawing.Size(99, 16)
        Me.Label117.TabIndex = 10
        Me.Label117.Text = "Accidental Plus"
        '
        'GroupBox15
        '
        Me.GroupBox15.Controls.Add(Me.txtfinnotes)
        Me.GroupBox15.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox15.Location = New System.Drawing.Point(0, 708)
        Me.GroupBox15.Name = "GroupBox15"
        Me.GroupBox15.Size = New System.Drawing.Size(406, 158)
        Me.GroupBox15.TabIndex = 202
        Me.GroupBox15.TabStop = False
        Me.GroupBox15.Text = "Notes:"
        '
        'txtfinnotes
        '
        Me.txtfinnotes.Location = New System.Drawing.Point(13, 21)
        Me.txtfinnotes.Multiline = True
        Me.txtfinnotes.Name = "txtfinnotes"
        Me.txtfinnotes.Size = New System.Drawing.Size(381, 127)
        Me.txtfinnotes.TabIndex = 0
        '
        'txtbodown
        '
        Me.txtbodown.Enabled = False
        Me.txtbodown.Location = New System.Drawing.Point(514, 651)
        Me.txtbodown.Name = "txtbodown"
        Me.txtbodown.Size = New System.Drawing.Size(89, 22)
        Me.txtbodown.TabIndex = 213
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.GroupBox19)
        Me.TabPage1.Controls.Add(Me.Label78)
        Me.TabPage1.Controls.Add(Me.txtwarrcost)
        Me.TabPage1.Controls.Add(Me.btnShorelandWarr)
        Me.TabPage1.Controls.Add(Me.btnSylWarr)
        Me.TabPage1.Controls.Add(Me.GroupBox14)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(799, 994)
        Me.TabPage1.TabIndex = 3
        Me.TabPage1.Text = "Warranty"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'GroupBox19
        '
        Me.GroupBox19.Controls.Add(Me.IAPseals)
        Me.GroupBox19.Controls.Add(Me.IAPaftersale)
        Me.GroupBox19.Controls.Add(Me.Label109)
        Me.GroupBox19.Controls.Add(Me.IAPgpr)
        Me.GroupBox19.Controls.Add(Me.IAPextWarranty)
        Me.GroupBox19.Controls.Add(Me.Label116)
        Me.GroupBox19.Controls.Add(Me.Label110)
        Me.GroupBox19.Controls.Add(Me.Label115)
        Me.GroupBox19.Controls.Add(Me.IAPdeduct)
        Me.GroupBox19.Controls.Add(Me.IAPoemWarranty)
        Me.GroupBox19.Controls.Add(Me.Label111)
        Me.GroupBox19.Controls.Add(Me.Label114)
        Me.GroupBox19.Controls.Add(Me.IAPfuel)
        Me.GroupBox19.Controls.Add(Me.IAPproduct)
        Me.GroupBox19.Controls.Add(Me.Label112)
        Me.GroupBox19.Controls.Add(Me.IAPdelDATE)
        Me.GroupBox19.Controls.Add(Me.IAPused)
        Me.GroupBox19.Controls.Add(Me.Label113)
        Me.GroupBox19.Location = New System.Drawing.Point(298, 6)
        Me.GroupBox19.Name = "GroupBox19"
        Me.GroupBox19.Size = New System.Drawing.Size(327, 401)
        Me.GroupBox19.TabIndex = 230
        Me.GroupBox19.TabStop = False
        Me.GroupBox19.Text = "IAP Warranty"
        '
        'IAPseals
        '
        Me.IAPseals.AutoSize = True
        Me.IAPseals.Location = New System.Drawing.Point(36, 281)
        Me.IAPseals.Name = "IAPseals"
        Me.IAPseals.Size = New System.Drawing.Size(138, 20)
        Me.IAPseals.TabIndex = 233
        Me.IAPseals.Text = "Seals and Gaskets"
        Me.IAPseals.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.IAPseals.UseVisualStyleBackColor = True
        '
        'IAPaftersale
        '
        Me.IAPaftersale.AutoSize = True
        Me.IAPaftersale.Location = New System.Drawing.Point(36, 255)
        Me.IAPaftersale.Name = "IAPaftersale"
        Me.IAPaftersale.Size = New System.Drawing.Size(78, 20)
        Me.IAPaftersale.TabIndex = 232
        Me.IAPaftersale.Text = "Aftersale"
        Me.IAPaftersale.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.IAPaftersale.UseVisualStyleBackColor = True
        '
        'Label109
        '
        Me.Label109.AutoSize = True
        Me.Label109.Location = New System.Drawing.Point(217, 80)
        Me.Label109.Name = "Label109"
        Me.Label109.Size = New System.Drawing.Size(41, 16)
        Me.Label109.TabIndex = 230
        Me.Label109.Text = "Years"
        '
        'IAPgpr
        '
        Me.IAPgpr.AutoSize = True
        Me.IAPgpr.Location = New System.Drawing.Point(36, 204)
        Me.IAPgpr.Name = "IAPgpr"
        Me.IAPgpr.Size = New System.Drawing.Size(55, 20)
        Me.IAPgpr.TabIndex = 231
        Me.IAPgpr.Text = "GPR"
        Me.IAPgpr.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.IAPgpr.UseVisualStyleBackColor = True
        '
        'IAPextWarranty
        '
        Me.IAPextWarranty.Location = New System.Drawing.Point(136, 74)
        Me.IAPextWarranty.Name = "IAPextWarranty"
        Me.IAPextWarranty.Size = New System.Drawing.Size(75, 22)
        Me.IAPextWarranty.TabIndex = 217
        '
        'Label116
        '
        Me.Label116.AutoSize = True
        Me.Label116.Location = New System.Drawing.Point(20, 78)
        Me.Label116.Name = "Label116"
        Me.Label116.Size = New System.Drawing.Size(96, 16)
        Me.Label116.TabIndex = 219
        Me.Label116.Text = "Total Warranty:"
        '
        'Label110
        '
        Me.Label110.AutoSize = True
        Me.Label110.Location = New System.Drawing.Point(217, 54)
        Me.Label110.Name = "Label110"
        Me.Label110.Size = New System.Drawing.Size(41, 16)
        Me.Label110.TabIndex = 229
        Me.Label110.Text = "Years"
        '
        'Label115
        '
        Me.Label115.AutoSize = True
        Me.Label115.Location = New System.Drawing.Point(25, 54)
        Me.Label115.Name = "Label115"
        Me.Label115.Size = New System.Drawing.Size(107, 16)
        Me.Label115.TabIndex = 218
        Me.Label115.Text = "OEM Warranty:  "
        '
        'IAPdeduct
        '
        Me.IAPdeduct.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.IAPdeduct.FormattingEnabled = True
        Me.IAPdeduct.Items.AddRange(New Object() {"$100", "$50", "$500 (Diesel)"})
        Me.IAPdeduct.Location = New System.Drawing.Point(136, 162)
        Me.IAPdeduct.Name = "IAPdeduct"
        Me.IAPdeduct.Size = New System.Drawing.Size(74, 24)
        Me.IAPdeduct.TabIndex = 228
        '
        'IAPoemWarranty
        '
        Me.IAPoemWarranty.Location = New System.Drawing.Point(136, 48)
        Me.IAPoemWarranty.Name = "IAPoemWarranty"
        Me.IAPoemWarranty.Size = New System.Drawing.Size(75, 22)
        Me.IAPoemWarranty.TabIndex = 216
        '
        'Label111
        '
        Me.Label111.AutoSize = True
        Me.Label111.Location = New System.Drawing.Point(33, 165)
        Me.Label111.Name = "Label111"
        Me.Label111.Size = New System.Drawing.Size(77, 16)
        Me.Label111.TabIndex = 227
        Me.Label111.Text = "Deductable:"
        '
        'Label114
        '
        Me.Label114.AutoSize = True
        Me.Label114.Location = New System.Drawing.Point(34, 105)
        Me.Label114.Name = "Label114"
        Me.Label114.Size = New System.Drawing.Size(88, 16)
        Me.Label114.TabIndex = 220
        Me.Label114.Text = "Product Type:"
        '
        'IAPfuel
        '
        Me.IAPfuel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.IAPfuel.FormattingEnabled = True
        Me.IAPfuel.Items.AddRange(New Object() {"Gas", "Diesel"})
        Me.IAPfuel.Location = New System.Drawing.Point(136, 132)
        Me.IAPfuel.Name = "IAPfuel"
        Me.IAPfuel.Size = New System.Drawing.Size(74, 24)
        Me.IAPfuel.TabIndex = 226
        '
        'IAPproduct
        '
        Me.IAPproduct.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.IAPproduct.FormattingEnabled = True
        Me.IAPproduct.Items.AddRange(New Object() {"Inboard/Sterndrive/Jet", "Outboard", "Stand Alone Outboard"})
        Me.IAPproduct.Location = New System.Drawing.Point(137, 102)
        Me.IAPproduct.Name = "IAPproduct"
        Me.IAPproduct.Size = New System.Drawing.Size(74, 24)
        Me.IAPproduct.TabIndex = 221
        '
        'Label112
        '
        Me.Label112.AutoSize = True
        Me.Label112.Location = New System.Drawing.Point(33, 135)
        Me.Label112.Name = "Label112"
        Me.Label112.Size = New System.Drawing.Size(37, 16)
        Me.Label112.TabIndex = 225
        Me.Label112.Text = "Fuel:"
        '
        'IAPdelDATE
        '
        Me.IAPdelDATE.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.IAPdelDATE.Location = New System.Drawing.Point(88, 22)
        Me.IAPdelDATE.Name = "IAPdelDATE"
        Me.IAPdelDATE.Size = New System.Drawing.Size(123, 22)
        Me.IAPdelDATE.TabIndex = 222
        '
        'IAPused
        '
        Me.IAPused.AutoSize = True
        Me.IAPused.Location = New System.Drawing.Point(36, 230)
        Me.IAPused.Name = "IAPused"
        Me.IAPused.Size = New System.Drawing.Size(57, 20)
        Me.IAPused.TabIndex = 224
        Me.IAPused.Text = "Used"
        Me.IAPused.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.IAPused.UseVisualStyleBackColor = True
        '
        'Label113
        '
        Me.Label113.AutoSize = True
        Me.Label113.Location = New System.Drawing.Point(20, 27)
        Me.Label113.Name = "Label113"
        Me.Label113.Size = New System.Drawing.Size(62, 16)
        Me.Label113.TabIndex = 223
        Me.Label113.Text = "Del Date:"
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Location = New System.Drawing.Point(189, 416)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(92, 16)
        Me.Label78.TabIndex = 229
        Me.Label78.Text = "Warrany Cost:"
        '
        'txtwarrcost
        '
        Me.txtwarrcost.Enabled = False
        Me.txtwarrcost.Location = New System.Drawing.Point(293, 413)
        Me.txtwarrcost.Name = "txtwarrcost"
        Me.txtwarrcost.Size = New System.Drawing.Size(75, 22)
        Me.txtwarrcost.TabIndex = 228
        '
        'btnShorelandWarr
        '
        Me.btnShorelandWarr.Location = New System.Drawing.Point(387, 537)
        Me.btnShorelandWarr.Name = "btnShorelandWarr"
        Me.btnShorelandWarr.Size = New System.Drawing.Size(193, 25)
        Me.btnShorelandWarr.TabIndex = 227
        Me.btnShorelandWarr.Text = "Shoreland'r Warranty Card"
        Me.btnShorelandWarr.UseVisualStyleBackColor = True
        '
        'btnSylWarr
        '
        Me.btnSylWarr.Location = New System.Drawing.Point(138, 537)
        Me.btnSylWarr.Name = "btnSylWarr"
        Me.btnSylWarr.Size = New System.Drawing.Size(193, 25)
        Me.btnSylWarr.TabIndex = 226
        Me.btnSylWarr.Text = "Sylvan/Smoker Warranty Card"
        Me.btnSylWarr.UseVisualStyleBackColor = True
        '
        'GroupBox14
        '
        Me.GroupBox14.Controls.Add(Me.chkfakedate)
        Me.GroupBox14.Controls.Add(Me.chkcstwinprop)
        Me.GroupBox14.Controls.Add(Me.chkcsOpti)
        Me.GroupBox14.Controls.Add(Me.Label108)
        Me.GroupBox14.Controls.Add(Me.Label107)
        Me.GroupBox14.Controls.Add(Me.cmbcsdeduct)
        Me.GroupBox14.Controls.Add(Me.Label106)
        Me.GroupBox14.Controls.Add(Me.cmbcsfuel)
        Me.GroupBox14.Controls.Add(Me.Label39)
        Me.GroupBox14.Controls.Add(Me.chkusedwarranty)
        Me.GroupBox14.Controls.Add(Me.btnPrintReminder)
        Me.GroupBox14.Controls.Add(Me.Label105)
        Me.GroupBox14.Controls.Add(Me.DateWarrantystart)
        Me.GroupBox14.Controls.Add(Me.cmbcstype)
        Me.GroupBox14.Controls.Add(Me.Label77)
        Me.GroupBox14.Controls.Add(Me.Label76)
        Me.GroupBox14.Controls.Add(Me.cmbGPR)
        Me.GroupBox14.Controls.Add(Me.CSmanwarr)
        Me.GroupBox14.Controls.Add(Me.Label64)
        Me.GroupBox14.Controls.Add(Me.Label70)
        Me.GroupBox14.Controls.Add(Me.CSextwarr)
        Me.GroupBox14.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox14.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox14.Name = "GroupBox14"
        Me.GroupBox14.Size = New System.Drawing.Size(286, 401)
        Me.GroupBox14.TabIndex = 225
        Me.GroupBox14.TabStop = False
        Me.GroupBox14.Text = "Cornerstone"
        '
        'chkfakedate
        '
        Me.chkfakedate.AutoSize = True
        Me.chkfakedate.Location = New System.Drawing.Point(27, 307)
        Me.chkfakedate.Name = "chkfakedate"
        Me.chkfakedate.Size = New System.Drawing.Size(192, 20)
        Me.chkfakedate.TabIndex = 216
        Me.chkfakedate.Text = "Use Del Date as Date Sold"
        Me.chkfakedate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkfakedate.UseVisualStyleBackColor = True
        '
        'chkcstwinprop
        '
        Me.chkcstwinprop.AutoSize = True
        Me.chkcstwinprop.Location = New System.Drawing.Point(27, 281)
        Me.chkcstwinprop.Name = "chkcstwinprop"
        Me.chkcstwinprop.Size = New System.Drawing.Size(180, 20)
        Me.chkcstwinprop.TabIndex = 215
        Me.chkcstwinprop.Text = "Twin Propeller (Bravo 3)"
        Me.chkcstwinprop.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkcstwinprop.UseVisualStyleBackColor = True
        '
        'chkcsOpti
        '
        Me.chkcsOpti.AutoSize = True
        Me.chkcsOpti.Location = New System.Drawing.Point(27, 255)
        Me.chkcsOpti.Name = "chkcsOpti"
        Me.chkcsOpti.Size = New System.Drawing.Size(130, 20)
        Me.chkcsOpti.TabIndex = 214
        Me.chkcsOpti.Text = "Optimax/Verado"
        Me.chkcsOpti.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkcsOpti.UseVisualStyleBackColor = True
        '
        'Label108
        '
        Me.Label108.AutoSize = True
        Me.Label108.Location = New System.Drawing.Point(208, 79)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(42, 16)
        Me.Label108.TabIndex = 213
        Me.Label108.Text = "Years"
        '
        'Label107
        '
        Me.Label107.AutoSize = True
        Me.Label107.Location = New System.Drawing.Point(208, 53)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(42, 16)
        Me.Label107.TabIndex = 212
        Me.Label107.Text = "Years"
        '
        'cmbcsdeduct
        '
        Me.cmbcsdeduct.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbcsdeduct.FormattingEnabled = True
        Me.cmbcsdeduct.Items.AddRange(New Object() {"$100", "$0", "$500 (Diesel)"})
        Me.cmbcsdeduct.Location = New System.Drawing.Point(127, 161)
        Me.cmbcsdeduct.Name = "cmbcsdeduct"
        Me.cmbcsdeduct.Size = New System.Drawing.Size(74, 24)
        Me.cmbcsdeduct.TabIndex = 211
        '
        'Label106
        '
        Me.Label106.AutoSize = True
        Me.Label106.Location = New System.Drawing.Point(24, 164)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(84, 16)
        Me.Label106.TabIndex = 210
        Me.Label106.Text = "Deductable:"
        '
        'cmbcsfuel
        '
        Me.cmbcsfuel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbcsfuel.FormattingEnabled = True
        Me.cmbcsfuel.Items.AddRange(New Object() {"Gas", "Diesel"})
        Me.cmbcsfuel.Location = New System.Drawing.Point(127, 131)
        Me.cmbcsfuel.Name = "cmbcsfuel"
        Me.cmbcsfuel.Size = New System.Drawing.Size(74, 24)
        Me.cmbcsfuel.TabIndex = 209
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(24, 134)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(40, 16)
        Me.Label39.TabIndex = 208
        Me.Label39.Text = "Fuel:"
        '
        'chkusedwarranty
        '
        Me.chkusedwarranty.AutoSize = True
        Me.chkusedwarranty.Location = New System.Drawing.Point(27, 229)
        Me.chkusedwarranty.Name = "chkusedwarranty"
        Me.chkusedwarranty.Size = New System.Drawing.Size(58, 20)
        Me.chkusedwarranty.TabIndex = 207
        Me.chkusedwarranty.Text = "Used"
        Me.chkusedwarranty.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkusedwarranty.UseVisualStyleBackColor = True
        '
        'btnPrintReminder
        '
        Me.btnPrintReminder.Location = New System.Drawing.Point(59, 370)
        Me.btnPrintReminder.Name = "btnPrintReminder"
        Me.btnPrintReminder.Size = New System.Drawing.Size(158, 25)
        Me.btnPrintReminder.TabIndex = 206
        Me.btnPrintReminder.Text = "Print Reminder"
        Me.btnPrintReminder.UseVisualStyleBackColor = True
        '
        'Label105
        '
        Me.Label105.AutoSize = True
        Me.Label105.Location = New System.Drawing.Point(11, 26)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(66, 16)
        Me.Label105.TabIndex = 24
        Me.Label105.Text = "Del Date:"
        '
        'DateWarrantystart
        '
        Me.DateWarrantystart.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateWarrantystart.Location = New System.Drawing.Point(79, 21)
        Me.DateWarrantystart.Name = "DateWarrantystart"
        Me.DateWarrantystart.Size = New System.Drawing.Size(123, 22)
        Me.DateWarrantystart.TabIndex = 23
        '
        'cmbcstype
        '
        Me.cmbcstype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbcstype.FormattingEnabled = True
        Me.cmbcstype.Items.AddRange(New Object() {"Sterndrive", "Inboard", "Outboard", "Jet Drive"})
        Me.cmbcstype.Location = New System.Drawing.Point(128, 101)
        Me.cmbcstype.Name = "cmbcstype"
        Me.cmbcstype.Size = New System.Drawing.Size(74, 24)
        Me.cmbcstype.TabIndex = 20
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Location = New System.Drawing.Point(25, 104)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(95, 16)
        Me.Label77.TabIndex = 19
        Me.Label77.Text = "Product Type:"
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Location = New System.Drawing.Point(25, 194)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(40, 16)
        Me.Label76.TabIndex = 18
        Me.Label76.Text = "GRP:"
        '
        'cmbGPR
        '
        Me.cmbGPR.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbGPR.FormattingEnabled = True
        Me.cmbGPR.Items.AddRange(New Object() {"NONE", "$500", "$1000", "$1500", "$2000", "$2500", "$3000"})
        Me.cmbGPR.Location = New System.Drawing.Point(127, 191)
        Me.cmbGPR.Name = "cmbGPR"
        Me.cmbGPR.Size = New System.Drawing.Size(74, 24)
        Me.cmbGPR.TabIndex = 17
        '
        'CSmanwarr
        '
        Me.CSmanwarr.Location = New System.Drawing.Point(127, 47)
        Me.CSmanwarr.Name = "CSmanwarr"
        Me.CSmanwarr.Size = New System.Drawing.Size(75, 22)
        Me.CSmanwarr.TabIndex = 10
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Location = New System.Drawing.Point(16, 53)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(111, 16)
        Me.Label64.TabIndex = 12
        Me.Label64.Text = "OEM Warranty:  "
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.Location = New System.Drawing.Point(11, 77)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(105, 16)
        Me.Label70.TabIndex = 13
        Me.Label70.Text = "Total Warranty:"
        '
        'CSextwarr
        '
        Me.CSextwarr.Location = New System.Drawing.Point(127, 73)
        Me.CSextwarr.Name = "CSextwarr"
        Me.CSextwarr.Size = New System.Drawing.Size(75, 22)
        Me.CSextwarr.TabIndex = 11
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 250000
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(8, 26)
        Me.TextBox6.Multiline = True
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(601, 264)
        Me.TextBox6.TabIndex = 0
        '
        'frmBOS
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(958, 1023)
        Me.Controls.Add(Me.SplitContainer1)
        Me.MinimumSize = New System.Drawing.Size(800, 300)
        Me.Name = "frmBOS"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "New Bill of Sale"
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.PerformLayout()
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.Main.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox17.ResumeLayout(False)
        Me.GroupBox17.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Sales.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.GroupBox21.ResumeLayout(False)
        CType(Me.DVCalls, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox18.ResumeLayout(False)
        Me.GroupBox18.PerformLayout()
        Me.Finance.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox16.ResumeLayout(False)
        Me.GroupBox16.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox20.ResumeLayout(False)
        Me.GroupBox20.PerformLayout()
        Me.GroupBox12.ResumeLayout(False)
        Me.GroupBox12.PerformLayout()
        Me.GroupBox13.ResumeLayout(False)
        Me.GroupBox13.PerformLayout()
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox15.ResumeLayout(False)
        Me.GroupBox15.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.GroupBox19.ResumeLayout(False)
        Me.GroupBox19.PerformLayout()
        Me.GroupBox14.ResumeLayout(False)
        Me.GroupBox14.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents btnPickABoat As System.Windows.Forms.Button
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents Main As System.Windows.Forms.TabPage
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtboatunit As System.Windows.Forms.TextBox
    Friend WithEvents txtadminfee As System.Windows.Forms.TextBox
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents txtpst As System.Windows.Forms.TextBox
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents txtskipkg As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txtnotes1 As System.Windows.Forms.TextBox
    Friend WithEvents txtp3num As System.Windows.Forms.TextBox
    Friend WithEvents txtp2num As System.Windows.Forms.TextBox
    Friend WithEvents txtp1num As System.Windows.Forms.TextBox
    Friend WithEvents txtp3amount As System.Windows.Forms.TextBox
    Friend WithEvents txtp2amount As System.Windows.Forms.TextBox
    Friend WithEvents txtp1amount As System.Windows.Forms.TextBox
    Friend WithEvents txto1 As System.Windows.Forms.TextBox
    Friend WithEvents txto2 As System.Windows.Forms.TextBox
    Friend WithEvents txto3 As System.Windows.Forms.TextBox
    Friend WithEvents txto4 As System.Windows.Forms.TextBox
    Friend WithEvents txto5 As System.Windows.Forms.TextBox
    Friend WithEvents txto6 As System.Windows.Forms.TextBox
    Friend WithEvents txto7 As System.Windows.Forms.TextBox
    Friend WithEvents txto8 As System.Windows.Forms.TextBox
    Friend WithEvents chkwinterize As System.Windows.Forms.CheckBox
    Friend WithEvents Chk20hr As System.Windows.Forms.CheckBox
    Friend WithEvents chklockpkg As System.Windows.Forms.CheckBox
    Friend WithEvents chksafepkg As System.Windows.Forms.CheckBox
    Friend WithEvents chksprop As System.Windows.Forms.CheckBox
    Friend WithEvents chkrockg As System.Windows.Forms.CheckBox
    Friend WithEvents chkskipkg As System.Windows.Forms.CheckBox
    Friend WithEvents chkcover As System.Windows.Forms.CheckBox
    Friend WithEvents chkstire As System.Windows.Forms.CheckBox
    Friend WithEvents txto5price As System.Windows.Forms.TextBox
    Friend WithEvents txto4price As System.Windows.Forms.TextBox
    Friend WithEvents txto3price As System.Windows.Forms.TextBox
    Friend WithEvents txto6price As System.Windows.Forms.TextBox
    Friend WithEvents txto2price As System.Windows.Forms.TextBox
    Friend WithEvents txto8price As System.Windows.Forms.TextBox
    Friend WithEvents txto1price As System.Windows.Forms.TextBox
    Friend WithEvents txtlockpkgprice As System.Windows.Forms.TextBox
    Friend WithEvents txtsafepkgprice As System.Windows.Forms.TextBox
    Friend WithEvents txtspropprice As System.Windows.Forms.TextBox
    Friend WithEvents txtrockgprice As System.Windows.Forms.TextBox
    Friend WithEvents txtskipkgprice As System.Windows.Forms.TextBox
    Friend WithEvents txtcoverprice As System.Windows.Forms.TextBox
    Friend WithEvents txto7price As System.Windows.Forms.TextBox
    Friend WithEvents txtstireprice As System.Windows.Forms.TextBox
    Friend WithEvents txttotal As System.Windows.Forms.TextBox
    Friend WithEvents txtgst As System.Windows.Forms.TextBox
    Friend WithEvents txtsubtotal As System.Windows.Forms.TextBox
    Friend WithEvents txttrade As System.Windows.Forms.TextBox
    Friend WithEvents txtpackagetotal As System.Windows.Forms.TextBox
    Friend WithEvents txtoptionstotal As System.Windows.Forms.TextBox
    Friend WithEvents txtwinterize As System.Windows.Forms.TextBox
    Friend WithEvents txt20hr As System.Windows.Forms.TextBox
    Friend WithEvents txtextwarranty As System.Windows.Forms.TextBox
    Friend WithEvents txtprotech As System.Windows.Forms.TextBox
    Friend WithEvents txtantitheftreg As System.Windows.Forms.TextBox
    Friend WithEvents txttiretax As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtdiscountprice As System.Windows.Forms.TextBox
    Friend WithEvents txtdiscount As System.Windows.Forms.TextBox
    Friend WithEvents txtkickerprice As System.Windows.Forms.TextBox
    Friend WithEvents txtkickeryear As System.Windows.Forms.TextBox
    Friend WithEvents txtkickerserial As System.Windows.Forms.TextBox
    Friend WithEvents txtkickermodel As System.Windows.Forms.TextBox
    Friend WithEvents txtkickermake As System.Windows.Forms.TextBox
    Friend WithEvents txttplateprice As System.Windows.Forms.TextBox
    Friend WithEvents txttplateyear As System.Windows.Forms.TextBox
    Friend WithEvents txttplateserial As System.Windows.Forms.TextBox
    Friend WithEvents txttplatemodel As System.Windows.Forms.TextBox
    Friend WithEvents txttplatemake As System.Windows.Forms.TextBox
    Friend WithEvents txtdriveprice As System.Windows.Forms.TextBox
    Friend WithEvents txtdriveyear As System.Windows.Forms.TextBox
    Friend WithEvents txtdriveserial As System.Windows.Forms.TextBox
    Friend WithEvents txtdrivemodel As System.Windows.Forms.TextBox
    Friend WithEvents txtdrivemake As System.Windows.Forms.TextBox
    Friend WithEvents txttrailerprice As System.Windows.Forms.TextBox
    Friend WithEvents txttraileryear As System.Windows.Forms.TextBox
    Friend WithEvents txttrailerserial As System.Windows.Forms.TextBox
    Friend WithEvents txttrailermodel As System.Windows.Forms.TextBox
    Friend WithEvents txttrailermake As System.Windows.Forms.TextBox
    Friend WithEvents txtmotorprice As System.Windows.Forms.TextBox
    Friend WithEvents txtmotoryear As System.Windows.Forms.TextBox
    Friend WithEvents txtmotorserial As System.Windows.Forms.TextBox
    Friend WithEvents txtmotormodel As System.Windows.Forms.TextBox
    Friend WithEvents txtmotormake As System.Windows.Forms.TextBox
    Friend WithEvents txtboatprice As System.Windows.Forms.TextBox
    Friend WithEvents txtboatyear As System.Windows.Forms.TextBox
    Friend WithEvents txtboathin As System.Windows.Forms.TextBox
    Friend WithEvents txtboatmodel As System.Windows.Forms.TextBox
    Friend WithEvents txtboatmake As System.Windows.Forms.TextBox
    Friend WithEvents txtcolor As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtprov As System.Windows.Forms.TextBox
    Friend WithEvents txtpostal As System.Windows.Forms.TextBox
    Friend WithEvents txtcity As System.Windows.Forms.TextBox
    Friend WithEvents txtemail As System.Windows.Forms.TextBox
    Friend WithEvents txtwork As System.Windows.Forms.TextBox
    Friend WithEvents txthome As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtaddress As System.Windows.Forms.TextBox
    Friend WithEvents txtbuyer1last As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtbuyer1first As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtbuyer2last As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtbuyer2first As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents DateSold As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtBOS As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Sales As System.Windows.Forms.TabPage
    Friend WithEvents Finance As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents cmbFinanceStatus As System.Windows.Forms.ComboBox
    Friend WithEvents CmbShopStatus As System.Windows.Forms.ComboBox
    Friend WithEvents cmbDealStatus As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents btnPrintWO As System.Windows.Forms.Button
    Friend WithEvents txtwotext As System.Windows.Forms.TextBox
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents btnSplitDeal As System.Windows.Forms.Button
    Friend WithEvents txtsalesman2 As System.Windows.Forms.TextBox
    Friend WithEvents txtsalesman As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents txtnotes As System.Windows.Forms.TextBox
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents DateTimeWO As System.Windows.Forms.DateTimePicker
    Friend WithEvents btnPrintSAL As System.Windows.Forms.Button
    Friend WithEvents btnPrintBOS As System.Windows.Forms.Button
    Friend WithEvents btnVoid As System.Windows.Forms.Button
    Friend WithEvents txtp3date As System.Windows.Forms.TextBox
    Friend WithEvents txtp2date As System.Windows.Forms.TextBox
    Friend WithEvents txtp1date As System.Windows.Forms.TextBox
    Friend WithEvents btnChangeSalesman As System.Windows.Forms.Button
    Friend WithEvents btnDetails As System.Windows.Forms.Button
    Friend WithEvents btnOrder As System.Windows.Forms.Button
    Friend WithEvents btnReleaseBoat As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents ChkGST As System.Windows.Forms.CheckBox
    Friend WithEvents chkPST As System.Windows.Forms.CheckBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents chkextwarranty As System.Windows.Forms.CheckBox
    Friend WithEvents btnDelivered As System.Windows.Forms.Button
    Friend WithEvents txtdatedeled As System.Windows.Forms.TextBox
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents cmbCommissioned As System.Windows.Forms.ComboBox
    Friend WithEvents btnShowSoldBy As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents txtinssold As System.Windows.Forms.TextBox
    Friend WithEvents runins As System.Windows.Forms.RadioButton
    Friend WithEvents rins As System.Windows.Forms.RadioButton
    Friend WithEvents txthiddenfincode As System.Windows.Forms.TextBox
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents rfin As System.Windows.Forms.RadioButton
    Friend WithEvents rcash As System.Windows.Forms.RadioButton
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents btnPrintCornerstone As System.Windows.Forms.Button
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents txttradelein As System.Windows.Forms.TextBox
    Friend WithEvents chkprotech As System.Windows.Forms.CheckBox
    Friend WithEvents chkantitheftreg As System.Windows.Forms.CheckBox
    Friend WithEvents btnprintAT As System.Windows.Forms.Button
    Friend WithEvents BtnProTech As System.Windows.Forms.Button
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents txtowing As System.Windows.Forms.TextBox
    Friend WithEvents btnUnlockBOS As System.Windows.Forms.Button
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Label88 As System.Windows.Forms.Label
    Friend WithEvents txtMiscComm As System.Windows.Forms.TextBox
    Friend WithEvents txtcommrate6 As System.Windows.Forms.TextBox
    Friend WithEvents txtcommrate5 As System.Windows.Forms.TextBox
    Friend WithEvents txtcommrate4 As System.Windows.Forms.TextBox
    Friend WithEvents txtcommrate3 As System.Windows.Forms.TextBox
    Friend WithEvents txtcommrate2 As System.Windows.Forms.TextBox
    Friend WithEvents txtcommrate1 As System.Windows.Forms.TextBox
    Friend WithEvents txtcommrate8 As System.Windows.Forms.TextBox
    Friend WithEvents txtcommrate7 As System.Windows.Forms.TextBox
    Friend WithEvents btnDoneComm As System.Windows.Forms.Button
    Friend WithEvents Label89 As System.Windows.Forms.Label
    Friend WithEvents txtchange2note As System.Windows.Forms.TextBox
    Friend WithEvents txtchange1note As System.Windows.Forms.TextBox
    Friend WithEvents Label91 As System.Windows.Forms.Label
    Friend WithEvents Label90 As System.Windows.Forms.Label
    Friend WithEvents txtcommchange2 As System.Windows.Forms.TextBox
    Friend WithEvents txtcommchange1 As System.Windows.Forms.TextBox
    Friend WithEvents txtBOcommadjust As System.Windows.Forms.TextBox
    Friend WithEvents Label93 As System.Windows.Forms.Label
    Friend WithEvents txtBOcommadjustnote As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox17 As System.Windows.Forms.GroupBox
    Friend WithEvents txtsmallitemcom As System.Windows.Forms.TextBox
    Friend WithEvents Label94 As System.Windows.Forms.Label
    Friend WithEvents GroupBox18 As System.Windows.Forms.GroupBox
    Friend WithEvents txtwostore As System.Windows.Forms.TextBox
    Friend WithEvents txtwonumber As System.Windows.Forms.TextBox
    Friend WithEvents Label95 As System.Windows.Forms.Label
    Friend WithEvents Label96 As System.Windows.Forms.Label
    Friend WithEvents btnCreateWO As System.Windows.Forms.Button
    Friend WithEvents txtwodate As System.Windows.Forms.TextBox
    Friend WithEvents txtwostatus As System.Windows.Forms.TextBox
    Friend WithEvents Label97 As System.Windows.Forms.Label
    Friend WithEvents Label98 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents txtatnum As System.Windows.Forms.TextBox
    Friend WithEvents txtRedNoGST As System.Windows.Forms.Label
    Friend WithEvents btnATBprint As System.Windows.Forms.Button
    Friend WithEvents btnPrintCAF As System.Windows.Forms.Button
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label102 As System.Windows.Forms.Label
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents Label92 As System.Windows.Forms.Label
    Friend WithEvents txtfinancefee As System.Windows.Forms.TextBox
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents txtBankFee As System.Windows.Forms.TextBox
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents txtreserve As System.Windows.Forms.TextBox
    Friend WithEvents txtammover As System.Windows.Forms.TextBox
    Friend WithEvents txtrateover As System.Windows.Forms.TextBox
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents cmbrate As System.Windows.Forms.ComboBox
    Friend WithEvents cmbammort As System.Windows.Forms.ComboBox
    Friend WithEvents cmbTerm As System.Windows.Forms.ComboBox
    Friend WithEvents ListBanks As System.Windows.Forms.ListBox
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents txtbizman As System.Windows.Forms.TextBox
    Friend WithEvents btnBizmanChange As System.Windows.Forms.Button
    Friend WithEvents Label103 As System.Windows.Forms.Label
    Friend WithEvents txtbolien As System.Windows.Forms.TextBox
    Friend WithEvents btnTradeLienCTC As System.Windows.Forms.Button
    Friend WithEvents btnTradeInCTC As System.Windows.Forms.Button
    Friend WithEvents txtbowarranty As System.Windows.Forms.TextBox
    Friend WithEvents txtbotrade As System.Windows.Forms.TextBox
    Friend WithEvents btnWarrantyCTC As System.Windows.Forms.Button
    Friend WithEvents Label100 As System.Windows.Forms.Label
    Friend WithEvents Label99 As System.Windows.Forms.Label
    Friend WithEvents txtbocashprice As System.Windows.Forms.TextBox
    Friend WithEvents btnCashPriceCTC As System.Windows.Forms.Button
    Friend WithEvents btnDownPmtCTC As System.Windows.Forms.Button
    Friend WithEvents btnPrintInsRequest As System.Windows.Forms.Button
    Friend WithEvents Label101 As System.Windows.Forms.Label
    Friend WithEvents GroupBox16 As System.Windows.Forms.GroupBox
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Friend WithEvents CmbPTinstalled As System.Windows.Forms.ComboBox
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents CmbPTreg As System.Windows.Forms.ComboBox
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents CmbPTrtb As System.Windows.Forms.ComboBox
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents txtPTcost As System.Windows.Forms.TextBox
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents CmbPTfabric As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox12 As System.Windows.Forms.GroupBox
    Friend WithEvents btnCICopyToClip As System.Windows.Forms.Button
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox13 As System.Windows.Forms.GroupBox
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents txtbday1 As System.Windows.Forms.TextBox
    Friend WithEvents txtbday2 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents btnASCopyToClip As System.Windows.Forms.Button
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents btnLICopyToClip As System.Windows.Forms.Button
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents cmbahtype As System.Windows.Forms.ComboBox
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents cmbcins As System.Windows.Forms.ComboBox
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents cmbains As System.Windows.Forms.ComboBox
    Friend WithEvents cmblins As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox15 As System.Windows.Forms.GroupBox
    Friend WithEvents txtfinnotes As System.Windows.Forms.TextBox
    Friend WithEvents txtbodown As System.Windows.Forms.TextBox
    Friend WithEvents btnPCLForm As System.Windows.Forms.Button
    Friend WithEvents btnTrailerBOS As System.Windows.Forms.Button
    Friend WithEvents btnInsuranceWaiver As System.Windows.Forms.Button
    Friend WithEvents btnWarrantyWaiver As System.Windows.Forms.Button
    Friend WithEvents txtrednopst As System.Windows.Forms.Label
    Friend WithEvents Label104 As System.Windows.Forms.Label
    Friend WithEvents txttotalfin As System.Windows.Forms.TextBox
    Friend WithEvents btnPCLAuthorization As System.Windows.Forms.Button
    Friend WithEvents Tirestxt As System.Windows.Forms.Label
    Friend WithEvents txttires As System.Windows.Forms.TextBox
    Friend WithEvents txtb1atteries As System.Windows.Forms.Label
    Friend WithEvents txtbatteries As System.Windows.Forms.TextBox
    Friend WithEvents btnBOprofitsheet As System.Windows.Forms.Button
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents btnShorelandWarr As System.Windows.Forms.Button
    Friend WithEvents btnSylWarr As System.Windows.Forms.Button
    Friend WithEvents GroupBox14 As System.Windows.Forms.GroupBox
    Friend WithEvents chkusedwarranty As System.Windows.Forms.CheckBox
    Friend WithEvents btnPrintReminder As System.Windows.Forms.Button
    Friend WithEvents Label105 As System.Windows.Forms.Label
    Friend WithEvents DateWarrantystart As System.Windows.Forms.DateTimePicker
    Friend WithEvents cmbcstype As System.Windows.Forms.ComboBox
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents cmbGPR As System.Windows.Forms.ComboBox
    Friend WithEvents CSmanwarr As System.Windows.Forms.TextBox
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents CSextwarr As System.Windows.Forms.TextBox
    Friend WithEvents cmbcsfuel As System.Windows.Forms.ComboBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents cmbcsdeduct As System.Windows.Forms.ComboBox
    Friend WithEvents Label106 As System.Windows.Forms.Label
    Friend WithEvents chkcstwinprop As System.Windows.Forms.CheckBox
    Friend WithEvents chkcsOpti As System.Windows.Forms.CheckBox
    Friend WithEvents Label108 As System.Windows.Forms.Label
    Friend WithEvents Label107 As System.Windows.Forms.Label
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents txtwarrcost As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox19 As System.Windows.Forms.GroupBox
    Friend WithEvents IAPaftersale As System.Windows.Forms.CheckBox
    Friend WithEvents Label109 As System.Windows.Forms.Label
    Friend WithEvents IAPgpr As System.Windows.Forms.CheckBox
    Friend WithEvents IAPextWarranty As System.Windows.Forms.TextBox
    Friend WithEvents Label116 As System.Windows.Forms.Label
    Friend WithEvents Label110 As System.Windows.Forms.Label
    Friend WithEvents Label115 As System.Windows.Forms.Label
    Friend WithEvents IAPdeduct As System.Windows.Forms.ComboBox
    Friend WithEvents IAPoemWarranty As System.Windows.Forms.TextBox
    Friend WithEvents Label111 As System.Windows.Forms.Label
    Friend WithEvents Label114 As System.Windows.Forms.Label
    Friend WithEvents IAPfuel As System.Windows.Forms.ComboBox
    Friend WithEvents IAPproduct As System.Windows.Forms.ComboBox
    Friend WithEvents Label112 As System.Windows.Forms.Label
    Friend WithEvents IAPdelDATE As System.Windows.Forms.DateTimePicker
    Friend WithEvents IAPused As System.Windows.Forms.CheckBox
    Friend WithEvents Label113 As System.Windows.Forms.Label
    Friend WithEvents btnIAPWarranty As System.Windows.Forms.Button
    Friend WithEvents IAPseals As System.Windows.Forms.CheckBox
    Friend WithEvents chkfakedate As System.Windows.Forms.CheckBox
    Friend WithEvents cmbAccidentalPlus As System.Windows.Forms.ComboBox
    Friend WithEvents Label117 As System.Windows.Forms.Label
    Friend WithEvents GroupBox20 As System.Windows.Forms.GroupBox
    Friend WithEvents btnAPCopyToClip As System.Windows.Forms.Button
    Friend WithEvents Label118 As System.Windows.Forms.Label
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents lblFFee As System.Windows.Forms.Label
    Friend WithEvents Label119 As System.Windows.Forms.Label
    Friend WithEvents GroupBox21 As System.Windows.Forms.GroupBox
    Friend WithEvents DVCalls As System.Windows.Forms.DataGridView
    Friend WithEvents btnLogACall As System.Windows.Forms.Button
    Friend WithEvents View As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents Label120 As System.Windows.Forms.Label
    Friend WithEvents txtDepDate As System.Windows.Forms.TextBox
    Friend WithEvents txtDepNum As System.Windows.Forms.TextBox
    Friend WithEvents txtDepAmount As System.Windows.Forms.TextBox
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents pnReq1 As System.Windows.Forms.Panel
    Friend WithEvents pnReq2 As System.Windows.Forms.Panel
End Class
